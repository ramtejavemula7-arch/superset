import os
import sys
from logging.config import fileConfig

from sqlalchemy import engine_from_config, pool
from alembic import context

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.core.config import settings
from app.core.database import Base

# this is the Alembic Config object, which provides access to the values in the .ini file
config = context.config

# Interpret the config file for Python logging.
config_file_name = config.config_file_name
if not config_file_name:
    config_file_name = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "alembic.ini"))
if os.path.exists(config_file_name):
    try:
        fileConfig(config_file_name, disable_existing_loggers=False)
    except KeyError:
        # If the config file is missing logger sections, ignore logging setup.
        pass

# Set the SQLAlchemy URL from app settings. configparser (which backs
# alembic.ini) treats "%" as its own interpolation syntax, so any "%" in a
# URL-encoded password (e.g. "%40" for "@") must be escaped as "%%" here,
# or set_main_option raises "invalid interpolation syntax".
config.set_main_option("sqlalchemy.url", settings.database_url.replace("%", "%%"))

# Add your model's metadata here for 'autogenerate' support
target_metadata = Base.metadata


def run_migrations_offline():
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online():
    connectable = engine_from_config(
        config.get_section(config.config_ini_section),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
        )

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
