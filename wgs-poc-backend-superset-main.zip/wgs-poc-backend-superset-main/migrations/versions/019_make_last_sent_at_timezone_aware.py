"""make scheduled_reports.last_sent_at timezone-aware

Revision ID: 019
Revises: 018
Create Date: 2026-07-16 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


revision = "019"
down_revision = "018"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.alter_column(
        "scheduled_reports",
        "last_sent_at",
        type_=sa.DateTime(timezone=True),
        postgresql_using="last_sent_at AT TIME ZONE 'UTC'",
    )


def downgrade() -> None:
    op.alter_column(
        "scheduled_reports",
        "last_sent_at",
        type_=sa.DateTime(timezone=False),
        postgresql_using="last_sent_at AT TIME ZONE 'UTC'",
    )
