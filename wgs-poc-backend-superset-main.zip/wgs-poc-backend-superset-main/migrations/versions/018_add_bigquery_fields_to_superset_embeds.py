"""add bigquery_dataset and bigquery_table to superset_embeds (per-dashboard chat scoping)

Revision ID: 018
Revises: 017
Create Date: 2026-07-08 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


revision = "018"
down_revision = "017"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("superset_embeds", sa.Column("bigquery_dataset", sa.String(), nullable=True))
    op.add_column("superset_embeds", sa.Column("bigquery_table", sa.String(), nullable=True))


def downgrade() -> None:
    op.drop_column("superset_embeds", "bigquery_table")
    op.drop_column("superset_embeds", "bigquery_dataset")
