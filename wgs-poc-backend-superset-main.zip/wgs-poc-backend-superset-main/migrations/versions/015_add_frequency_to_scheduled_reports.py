"""add frequency (once/daily/weekly) to scheduled_reports

Revision ID: 015
Revises: 014
Create Date: 2026-07-06 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


revision = "015"
down_revision = "014"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "scheduled_reports",
        sa.Column("frequency", sa.String(), nullable=False, server_default="daily"),
    )
    op.add_column("scheduled_reports", sa.Column("day_of_week", sa.String(), nullable=True))
    op.add_column("scheduled_reports", sa.Column("run_date", sa.Date(), nullable=True))
    op.alter_column("scheduled_reports", "frequency", server_default=None)


def downgrade() -> None:
    op.drop_column("scheduled_reports", "run_date")
    op.drop_column("scheduled_reports", "day_of_week")
    op.drop_column("scheduled_reports", "frequency")
