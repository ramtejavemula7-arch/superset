"""add template_type, template_color, and metrics-template fields to templates

Revision ID: 016
Revises: 015
Create Date: 2026-07-06 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


revision = "016"
down_revision = "015"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "templates",
        sa.Column("template_type", sa.String(), nullable=False, server_default="transaction"),
    )
    op.add_column("templates", sa.Column("template_color", sa.String(), nullable=True))
    op.add_column("templates", sa.Column("dimensions", sa.JSON(), nullable=True))
    op.add_column("templates", sa.Column("metrics", sa.JSON(), nullable=True))
    op.add_column("templates", sa.Column("sort", sa.JSON(), nullable=True))
    op.alter_column("templates", "template_type", server_default=None)


def downgrade() -> None:
    op.drop_column("templates", "sort")
    op.drop_column("templates", "metrics")
    op.drop_column("templates", "dimensions")
    op.drop_column("templates", "template_color")
    op.drop_column("templates", "template_type")
