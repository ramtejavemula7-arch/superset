"""rename templates.aggregates to templates.total_columns

Revision ID: 011
Revises: 010
Create Date: 2026-07-03 00:00:00.000000

"""
from alembic import op


revision = "011"
down_revision = "010"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.alter_column("templates", "aggregates", new_column_name="total_columns")


def downgrade() -> None:
    op.alter_column("templates", "total_columns", new_column_name="aggregates")
