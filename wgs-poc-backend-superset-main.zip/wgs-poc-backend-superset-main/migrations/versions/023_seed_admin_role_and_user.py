"""seed a default Admin role and Admin user, so a fresh deploy has a login
without a manual SQL step

Revision ID: 023
Revises: 022
Create Date: 2026-08-06 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


revision = "023"
down_revision = "022"
branch_labels = None
depends_on = None

# argon2 hash — password is "Admin@12345" (matches the placeholder hash
# used elsewhere in this repo's dev tooling). Change it after first login.
_ADMIN_PASSWORD_HASH = (
    "$argon2id$v=19$m=65536,t=3,p=4$MAZgTMk5RwihdM7Z21vr/Q$weXiluwifimgUPL7VF2LsdtXIVL5NsLfGAqbxgERswY"
)


def upgrade() -> None:
    conn = op.get_bind()

    conn.execute(
        sa.text(
            """
            INSERT INTO roles (id, name, created_by, created_at)
            SELECT gen_random_uuid(), 'Admin', NULL, NOW()
            WHERE NOT EXISTS (SELECT 1 FROM roles WHERE name = 'Admin')
            """
        )
    )

    conn.execute(
        sa.text(
            """
            INSERT INTO users (id, username, email, hashed_password, is_active, role_id)
            SELECT
                gen_random_uuid(),
                'Admin',
                'admin@gmail.com',
                :password_hash,
                true,
                (SELECT id FROM roles WHERE name = 'Admin' LIMIT 1)
            WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'admin@gmail.com')
            """
        ),
        {"password_hash": _ADMIN_PASSWORD_HASH},
    )


def downgrade() -> None:
    conn = op.get_bind()
    conn.execute(sa.text("DELETE FROM users WHERE email = 'admin@gmail.com'"))
    conn.execute(
        sa.text(
            "DELETE FROM roles WHERE name = 'Admin' "
            "AND NOT EXISTS (SELECT 1 FROM users WHERE role_id = roles.id)"
        )
    )
