"""add title to superset embeds

Revision ID: 003
Revises: 002
Create Date: 2026-06-25 00:00:00.000000

"""

from alembic import op
import sqlalchemy as sa


revision = '003'
down_revision = '002'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        'superset_embeds',
        sa.Column('title', sa.String(), nullable=True),
    )

    op.execute(
        "UPDATE superset_embeds SET title = dashboard_uuid WHERE title IS NULL"
    )

    op.alter_column(
        'superset_embeds',
        'title',
        nullable=False,
    )


def downgrade() -> None:
    op.drop_column('superset_embeds', 'title')