"""add superset embeds table"""

from alembic import op
import sqlalchemy as sa


revision = "002"
down_revision = "001"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "superset_embeds",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("dashboard_uuid", sa.String(), nullable=False),
        sa.Column("embed_url", sa.String(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(),
            server_default=sa.text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
        sa.PrimaryKeyConstraint("id"),
    )

    op.create_index(
        "ix_superset_embeds_id",
        "superset_embeds",
        ["id"],
        unique=False,
    )

    op.create_index(
        "ix_superset_embeds_dashboard_uuid",
        "superset_embeds",
        ["dashboard_uuid"],
        unique=True,
    )


def downgrade():
    op.drop_index("ix_superset_embeds_dashboard_uuid", table_name="superset_embeds")
    op.drop_index("ix_superset_embeds_id", table_name="superset_embeds")
    op.drop_table("superset_embeds")