"""normalize total_columns data left over from the old aggregates format

Migration 011 renamed templates.aggregates -> templates.total_columns but
did not transform the data inside it. Any row saved under the old feature
still holds [{"col": "...", "func": "..."}] objects, which no longer match
the new list[str] shape — this extracts just the column names.

Revision ID: 014
Revises: 013
Create Date: 2026-07-06 00:00:00.000000

"""
import json

from alembic import op
import sqlalchemy as sa


revision = "014"
down_revision = "013"
branch_labels = None
depends_on = None


def upgrade() -> None:
    conn = op.get_bind()
    rows = conn.execute(sa.text("SELECT id, total_columns FROM templates")).fetchall()
    for row in rows:
        raw = row.total_columns
        if isinstance(raw, str):
            try:
                raw = json.loads(raw)
            except (TypeError, ValueError):
                continue
        if not raw or not isinstance(raw, list):
            continue
        if isinstance(raw[0], dict):
            fixed = [item.get("col") for item in raw if isinstance(item, dict) and item.get("col")]
            conn.execute(
                sa.text("UPDATE templates SET total_columns = :val WHERE id = :id"),
                {"val": json.dumps(fixed), "id": row.id},
            )


def downgrade() -> None:
    pass
