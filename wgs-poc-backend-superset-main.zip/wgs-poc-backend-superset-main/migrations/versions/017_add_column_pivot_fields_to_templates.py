"""add column_field and column_sort_direction (matrix column pivot) to templates

Revision ID: 017
Revises: 016
Create Date: 2026-07-07 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


revision = "017"
down_revision = "016"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("templates", sa.Column("column_field", sa.String(), nullable=True))
    op.add_column(
        "templates",
        sa.Column("column_sort_direction", sa.String(), nullable=False, server_default="asc"),
    )
    op.alter_column("templates", "column_sort_direction", server_default=None)


def downgrade() -> None:
    op.drop_column("templates", "column_sort_direction")
    op.drop_column("templates", "column_field")
