"""
Same as list_data_agents_by_location.py, but hits each location's own
regional API endpoint instead of the default (global) endpoint — some GCP
APIs 403 on non-global locations unless you point the client at the
location-specific host.
"""
from google.api_core import client_options as client_options_lib
from google.cloud import geminidataanalytics_v1 as gda
from google.oauth2 import service_account

CREDENTIALS_PATH = "secrets/gemini-service-account.json"
PROJECT_ID = "bilvantisaimlproject"

LOCATIONS = ["global", "us", "eu"]


def _endpoint_for(location: str) -> str:
    if location == "global":
        return "geminidataanalytics.googleapis.com"
    if "-" in location:
        return f"geminidataanalytics-{location}.googleapis.com"
    return f"geminidataanalytics.{location}.rep.googleapis.com"


credentials = service_account.Credentials.from_service_account_file(CREDENTIALS_PATH)

for location in LOCATIONS:
    endpoint = _endpoint_for(location)
    print(f"\n=== location: {location}  (endpoint: {endpoint}) ===")
    opts = client_options_lib.ClientOptions(api_endpoint=endpoint)
    client = gda.DataAgentServiceClient(credentials=credentials, client_options=opts)
    parent = f"projects/{PROJECT_ID}/locations/{location}"
    try:
        for agent in client.list_data_agents(parent=parent):
            name = getattr(agent, "name", "")
            display_name = getattr(agent, "display_name", "")
            print(f"  {display_name!r}  ({name})")
    except Exception as e:
        print(f"  ERROR: {e}")
