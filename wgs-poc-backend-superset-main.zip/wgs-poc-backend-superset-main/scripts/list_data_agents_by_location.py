"""
Lists Data Agents across all known Conversational Analytics API locations
to find out where a given agent actually lives.
"""
from google.cloud import geminidataanalytics_v1 as gda
from google.oauth2 import service_account

CREDENTIALS_PATH = "secrets/gemini-service-account.json"
PROJECT_ID = "bilvantisaimlproject"

# Conversational Analytics API currently buckets agents into these locations
LOCATIONS = ["global", "us", "eu"]

credentials = service_account.Credentials.from_service_account_file(CREDENTIALS_PATH)
client = gda.DataAgentServiceClient(credentials=credentials)

for location in LOCATIONS:
    parent = f"projects/{PROJECT_ID}/locations/{location}"
    print(f"\n=== location: {location} ===")
    try:
        for agent in client.list_data_agents(parent=parent):
            name = getattr(agent, "name", "")
            display_name = getattr(agent, "display_name", "")
            print(f"  {display_name!r}  ({name})")
    except Exception as e:
        print(f"  ERROR: {e}")
