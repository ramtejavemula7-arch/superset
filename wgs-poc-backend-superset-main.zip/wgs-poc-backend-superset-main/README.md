# WGS POC

A FastAPI application with layered architecture, JWT authentication, and Superset embedding support.

## Project Structure

- `app/` - application package
- `app/core` - configuration, database, and security
- `app/api` - routes and dependencies
- `app/models` - SQLAlchemy models
- `app/schemas` - Pydantic schemas
- `app/services` - business logic
- `app/repositories` - persistence layer
- `app/utils` - helper utilities and logger
- `app/middleware` - custom middleware
- `migrations/` - Alembic database migrations
- `tests/` - unit tests

## Prerequisites

- Python 3.11+
- PostgreSQL (running and reachable)

## Setup

1. **Clone the repo and enter the project directory.**

2. **Create and activate a virtual environment.**

   ```bash
   python -m venv venv
   # Windows
   venv\Scripts\activate
   # macOS/Linux
   source venv/bin/activate
   ```

3. **Install dependencies.**

   ```bash
   pip install -r requirements.txt
   ```

4. **Configure environment variables.**

   Copy `.env.example` to `.env` and fill in real values (database URL, secret key, SMTP, Superset, etc.).

   ```bash
   cp .env.example .env
   ```

   Generate a secret key with:

   ```bash
   python -c "import secrets; print(secrets.token_hex(32))"
   ```

5. **Point Alembic at your database.**

   `alembic.ini` currently has a hardcoded `sqlalchemy.url`. Update it to match your local database (or your `DATABASE_URL` value in `.env`) before running migrations.

6. **Run database migrations.**

   ```bash
   alembic upgrade head
   ```

## Run

```bash
uvicorn app.main:app --reload
```

The API will be available at `http://localhost:8000`, with interactive docs at `http://localhost:8000/docs` (only when `DEBUG=true`).

### Run with Docker

```bash
docker compose up --build
```

> Note: `docker-compose.yml` expects a `Dockerfile` in the project root — add one if it isn't present yet.

## Health Check

```bash
curl http://localhost:8000/health
```

## Tests

```bash
pytest
```
