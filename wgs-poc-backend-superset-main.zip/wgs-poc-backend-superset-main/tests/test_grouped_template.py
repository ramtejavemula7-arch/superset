import types
from io import BytesIO

import openpyxl
import pytest
from fastapi import HTTPException
from pydantic import ValidationError
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models.template import Template
from app.schemas.template import TemplateCreate, TemplateUpdate
from app.services.template_service import TemplateService


# ------------------------------------------------------------------ #
# Schema validation                                                    #
# ------------------------------------------------------------------ #

def test_grouped_template_accepts_dimensions_that_prefix_columns():
    payload = TemplateCreate(
        name="Grouped Report",
        template_type="grouped",
        dataset_id=1,
        columns=["client", "payment_month", "payment_method", "billgo_payment_id", "total_dollars_requested"],
        dimensions=["client", "payment_month", "payment_method"],
        total_columns=["total_dollars_requested"],
    )
    assert payload.template_type == "grouped"
    assert payload.dimensions == ["client", "payment_month", "payment_method"]


def test_grouped_template_rejects_dimensions_not_prefixing_columns():
    with pytest.raises(ValidationError):
        TemplateCreate(
            name="Grouped Report",
            template_type="grouped",
            dataset_id=1,
            columns=["billgo_payment_id", "client", "payment_month"],
            dimensions=["client", "payment_month"],
        )


def test_grouped_template_rejects_empty_dimensions():
    with pytest.raises(ValidationError):
        TemplateCreate(
            name="Grouped Report",
            template_type="grouped",
            dataset_id=1,
            columns=["client", "payment_month"],
            dimensions=[],
        )


def test_non_grouped_template_ignores_dimensions_columns_relationship():
    # "transaction"/"metrics" templates are unaffected by the new constraint
    payload = TemplateCreate(
        name="Flat Report",
        dataset_id=1,
        columns=["customer", "revenue"],
    )
    assert payload.template_type == "transaction"


# ------------------------------------------------------------------ #
# _compute_merge_spans                                                 #
# ------------------------------------------------------------------ #

def test_compute_merge_spans_respects_hierarchy():
    # Same "Method" value ("LUMINOSITY") repeats under two different Clients —
    # it must NOT merge across the Client boundary even though the raw values match.
    rows = [
        {"client": "Fiserv", "method": "LUMINOSITY"},
        {"client": "Fiserv", "method": "LUMINOSITY"},
        {"client": "Corpay", "method": "LUMINOSITY"},
    ]
    spans = TemplateService._compute_merge_spans(rows, ["client", "method"])

    assert spans["client"] == [(0, 2), (2, 1)]
    # method spans must break at index 2 (the client boundary), not merge all 3
    assert spans["method"] == [(0, 2), (2, 1)]


def test_compute_merge_spans_empty_inputs():
    assert TemplateService._compute_merge_spans([], ["client"]) == {"client": []}
    assert TemplateService._compute_merge_spans([{"client": "A"}], []) == {}


# ------------------------------------------------------------------ #
# Excel export                                                         #
# ------------------------------------------------------------------ #

def _make_grouped_template(**overrides):
    defaults = dict(
        name="Payments Grouped",
        template_type="grouped",
        logo_url=None,
        logo_position="left",
        template_color=None,
        dataset_id=1,
        columns=["client", "payment_method", "billgo_payment_id", "total_dollars_requested"],
        filters=[],
        total_columns=["total_dollars_requested"],
        dimensions=["client", "payment_method"],
        metrics=None,
        sort=None,
        column_field=None,
        column_sort_direction="asc",
    )
    defaults.update(overrides)
    return types.SimpleNamespace(**defaults)


def test_build_grouped_excel_merges_dimension_columns_and_pins_grand_total(monkeypatch):
    # Client names are picked so alphabetical order (the row-sort key used by
    # _fetch_grouped_rows) matches the intended group layout: "ClientA" (3
    # rows) sorts before "ClientB" (1 row).
    template = _make_grouped_template()
    fetched_rows = [
        {"client": "ClientA", "payment_method": "LUMINOSITY", "billgo_payment_id": "p1", "total_dollars_requested": 10},
        {"client": "ClientA", "payment_method": "LUMINOSITY", "billgo_payment_id": "p2", "total_dollars_requested": 20},
        {"client": "ClientA", "payment_method": "BILLTRUST", "billgo_payment_id": "p3", "total_dollars_requested": 30},
        {"client": "ClientB", "payment_method": "BILLTRUST", "billgo_payment_id": "p4", "total_dollars_requested": 40},
    ]

    service = TemplateService()
    monkeypatch.setattr(service, "query_superset_dataset", lambda *a, **k: fetched_rows)

    excel_bytes = service.build_excel(template)
    wb = openpyxl.load_workbook(BytesIO(excel_bytes))
    sheet = wb.active

    # Grand Total row sits directly under the header row and sums total_dollars_requested
    header_row_idx = next(
        ri for ri in range(1, sheet.max_row + 1)
        if sheet.cell(row=ri, column=1).value == "client"
    )
    total_row = header_row_idx + 1
    assert sheet.cell(row=total_row, column=1).value == "Grand Total"
    assert sheet.cell(row=total_row, column=4).value == 100

    detail_start = total_row + 1  # ClientA/BILLTRUST (alphabetically first)

    merged_ranges = {str(r) for r in sheet.merged_cells.ranges}
    # client column (A) merges across the 3 ClientA detail rows
    assert f"A{detail_start}:A{detail_start + 2}" in merged_ranges
    # payment_method column (B): only the 2-row LUMINOSITY run merges — the two
    # BILLTRUST rows (one per Client) each have nothing to merge, and crucially
    # must NOT merge with each other across the Client boundary
    b_merges = [r for r in merged_ranges if r.startswith("B") and ":B" in r]
    assert b_merges == [f"B{detail_start + 1}:B{detail_start + 2}"]


def test_build_grouped_pdf_runs_without_error(monkeypatch):
    template = _make_grouped_template()
    fetched_rows = [
        {"client": "Fiserv", "payment_method": "LUMINOSITY", "billgo_payment_id": "p1", "total_dollars_requested": 10},
        {"client": "Corpay", "payment_method": "BILLTRUST", "billgo_payment_id": "p4", "total_dollars_requested": 40},
    ]
    service = TemplateService()
    monkeypatch.setattr(service, "query_superset_dataset", lambda *a, **k: fetched_rows)

    pdf_bytes = service.build_pdf(template)
    assert pdf_bytes[:4] == b"%PDF"


# ------------------------------------------------------------------ #
# "metrics" (legacy Matrix) creation is disabled — "grouped" is now the  #
# user-facing "Matrix" template                                          #
# ------------------------------------------------------------------ #

def _make_db_session():
    engine = create_engine("sqlite:///:memory:")
    Template.__table__.create(engine, checkfirst=True)
    return sessionmaker(bind=engine)()


def test_create_rejects_new_metrics_template():
    db = _make_db_session()
    service = TemplateService()
    payload = TemplateCreate(
        name="Old Style Matrix",
        template_type="metrics",
        dataset_id=1,
        dimensions=["client"],
        metrics=[{"field": "amount", "aggregation": "SUM", "label": "Amount"}],
    )
    with pytest.raises(HTTPException) as exc_info:
        service.create(db, payload)
    assert exc_info.value.status_code == 400


def test_update_rejects_switching_an_existing_template_into_metrics():
    db = _make_db_session()
    service = TemplateService()
    created = service.create(db, TemplateCreate(name="Flat Report", dataset_id=1, columns=["a"]))

    with pytest.raises(HTTPException) as exc_info:
        service.update(db, created.id, TemplateUpdate(template_type="metrics"))
    assert exc_info.value.status_code == 400


def test_update_still_allows_editing_an_already_existing_metrics_template():
    db = _make_db_session()
    template = Template(
        name="Legacy Matrix",
        template_type="metrics",
        dataset_id=1,
        dimensions=["client"],
        metrics=[{"field": "amount", "aggregation": "SUM", "label": "Amount"}],
    )
    db.add(template)
    db.commit()
    db.refresh(template)

    service = TemplateService()
    updated = service.update(db, template.id, TemplateUpdate(name="Legacy Matrix Renamed"))

    assert updated.name == "Legacy Matrix Renamed"
    assert updated.template_type == "metrics"  # untouched — resaving, not switching into it
