import types
from io import BytesIO

import openpyxl

from app.services.template_service import (
    TemplateService, _dimension_sort_key, _format_dimension_value, _humanize_dimension_label,
)


# ------------------------------------------------------------------ #
# Pure helper behavior                                                 #
# ------------------------------------------------------------------ #

def test_format_dimension_value_renders_month_and_quarter_names():
    assert _format_dimension_value("order_date__month", 1) == "Jan"
    assert _format_dimension_value("order_date__month", 12) == "Dec"
    assert _format_dimension_value("order_date__quarter", 3) == "Q3"
    # Years and plain-column pivots pass through unchanged
    assert _format_dimension_value("order_date__year", 2019) == "2019"
    assert _format_dimension_value("ship_mode", "Express") == "Express"
    assert _format_dimension_value("order_date__month", None) == "(blank)"


def test_dimension_sort_key_sorts_month_numbers_numerically():
    values = [1, 10, 11, 12, 2, 3, 4, 5, 6, 7, 8, 9]
    assert sorted(values, key=_dimension_sort_key) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    # non-numeric pivot values still sort as strings without crashing
    assert sorted(["b", "a"], key=_dimension_sort_key) == ["a", "b"]


def test_humanize_dimension_label():
    assert _humanize_dimension_label("order_date__month") == "Order Date (Month)"
    assert _humanize_dimension_label("order_date__year") == "Order Date (Year)"
    assert _humanize_dimension_label("ship_mode") == "Ship Mode"


# ------------------------------------------------------------------ #
# End-to-end: month columns render in calendar order with month names #
# ------------------------------------------------------------------ #

def _make_heatmap_template(**overrides):
    defaults = dict(
        name="Sales Heatmap",
        template_type="heatmap",
        logo_url=None,
        logo_position="left",
        template_color=None,
        dataset_id=1,
        columns=[],
        filters=[],
        total_columns=[],
        dimensions=["category"],
        metrics=[{"field": "sales", "aggregation": "SUM", "label": "Sales"}],
        sort=None,
        column_field="order_date__month",
        column_sort_direction="asc",
    )
    defaults.update(overrides)
    return types.SimpleNamespace(**defaults)


_FAKE_ROWS = {
    ("category", "order_date__month"): [
        {"category": "Furniture", "order_date__month": 1, "Sales": 100},
        {"category": "Furniture", "order_date__month": 2, "Sales": 200},
        {"category": "Furniture", "order_date__month": 10, "Sales": 1000},
        {"category": "Furniture", "order_date__month": 11, "Sales": 1100},
        {"category": "Furniture", "order_date__month": 12, "Sales": 1200},
    ],
    ("category",): [{"category": "Furniture", "Sales": 3600}],
    ("order_date__month",): [
        {"order_date__month": 1, "Sales": 100},
        {"order_date__month": 2, "Sales": 200},
        {"order_date__month": 10, "Sales": 1000},
        {"order_date__month": 11, "Sales": 1100},
        {"order_date__month": 12, "Sales": 1200},
    ],
    (): [{"Sales": 3600}],
}


def _fake_run_grouped_metrics_query(dataset_id, groupby, metric_specs, filters, sort, force):
    return _FAKE_ROWS[tuple(groupby)]


def test_build_heatmap_excel_shows_month_columns_in_calendar_order_with_names(monkeypatch):
    template = _make_heatmap_template()
    service = TemplateService()
    monkeypatch.setattr(service, "_run_grouped_metrics_query", _fake_run_grouped_metrics_query)

    excel_bytes = service.build_excel(template)
    wb = openpyxl.load_workbook(BytesIO(excel_bytes))
    sheet = wb.active

    # The row containing "Jan" is the pivot-value header row — every other
    # non-empty cell on it, left to right, must be the remaining months in
    # calendar order (not "10","11","12" sorted lexicographically before "2"),
    # each rendered as an abbreviation, ending with "Total".
    header_row = next(
        ri for ri in range(1, sheet.max_row + 1)
        if any(sheet.cell(row=ri, column=ci).value == "Jan" for ci in range(1, sheet.max_column + 1))
    )
    values = [
        sheet.cell(row=header_row, column=ci).value
        for ci in range(1, sheet.max_column + 1)
    ]
    values = [v for v in values if v]
    assert values == ["Jan", "Feb", "Oct", "Nov", "Dec", "Total"]

    # The pivot field's own header humanizes the raw dimension name
    assert any(
        sheet.cell(row=ri, column=ci).value == "Order Date (Month)"
        for ri in range(1, sheet.max_row + 1)
        for ci in range(1, sheet.max_column + 1)
    )


def test_build_heatmap_pdf_runs_without_error_with_month_pivot(monkeypatch):
    template = _make_heatmap_template()
    service = TemplateService()
    monkeypatch.setattr(service, "_run_grouped_metrics_query", _fake_run_grouped_metrics_query)

    pdf_bytes = service.build_pdf(template)
    assert pdf_bytes[:4] == b"%PDF"
