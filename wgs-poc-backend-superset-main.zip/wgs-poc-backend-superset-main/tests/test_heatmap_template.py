import types
from io import BytesIO

import openpyxl
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models.template import Template
from app.schemas.template import TemplateCreate
from app.services.template_service import TemplateService


# ------------------------------------------------------------------ #
# Schema / create-update — "heatmap" is a normal creatable type,       #
# unlike the disabled legacy "metrics" type                            #
# ------------------------------------------------------------------ #

def test_heatmap_template_type_is_accepted_by_schema():
    payload = TemplateCreate(
        name="Sales Heatmap",
        template_type="heatmap",
        dataset_id=1,
        dimensions=["category"],
        metrics=[{"field": "sales", "aggregation": "SUM", "label": "Sales"}],
        column_field="month",
    )
    assert payload.template_type == "heatmap"


def _make_db_session():
    engine = create_engine("sqlite:///:memory:")
    Template.__table__.create(engine, checkfirst=True)
    return sessionmaker(bind=engine)()


def test_create_heatmap_template_is_not_blocked():
    db = _make_db_session()
    service = TemplateService()
    payload = TemplateCreate(
        name="Sales Heatmap",
        template_type="heatmap",
        dataset_id=1,
        dimensions=["category"],
        metrics=[{"field": "sales", "aggregation": "SUM", "label": "Sales"}],
        column_field="month",
    )
    created = service.create(db, payload)
    assert created.template_type == "heatmap"


# ------------------------------------------------------------------ #
# _heatmap_color / _heatmap_leaf_range                                 #
# ------------------------------------------------------------------ #

def test_heatmap_color_interpolates_between_endpoints():
    lo = TemplateService._heatmap_color(0, 0, 100)
    mid = TemplateService._heatmap_color(50, 0, 100)
    hi = TemplateService._heatmap_color(100, 0, 100)

    assert lo == "".join(f"{c:02X}" for c in TemplateService._HEATMAP_LOW)
    assert hi == "".join(f"{c:02X}" for c in TemplateService._HEATMAP_HIGH)
    assert mid != lo and mid != hi


def test_heatmap_color_falls_back_to_low_shade_for_missing_or_degenerate_input():
    fallback = "".join(f"{c:02X}" for c in TemplateService._HEATMAP_LOW)
    assert TemplateService._heatmap_color(None, 0, 100) == fallback
    assert TemplateService._heatmap_color("n/a", 0, 100) == fallback
    assert TemplateService._heatmap_color(50, 10, 10) == fallback  # degenerate range


def test_heatmap_leaf_range_ignores_non_leaf_rows_and_non_numeric_values():
    rows = [
        {"kind": "leaf", "values": {("Jan", "Sales"): 100, ("Feb", "Sales"): 300}},
        {"kind": "leaf", "values": {("Jan", "Sales"): None, ("Feb", "Sales"): 700}},
        {"kind": "subtotal", "values": {("Jan", "Sales"): 999999}},  # must be excluded
        {"kind": "grand", "values": {("Jan", "Sales"): 999999}},     # must be excluded
    ]
    vmin, vmax = TemplateService._heatmap_leaf_range(rows, [("Jan", "Sales"), ("Feb", "Sales")])
    assert (vmin, vmax) == (100, 700)


# ------------------------------------------------------------------ #
# End-to-end render — leaf cells shaded by value, subtotal/grand kept  #
# on the existing static teal styling                                  #
# ------------------------------------------------------------------ #

def _make_heatmap_template(**overrides):
    defaults = dict(
        name="Sales Heatmap",
        template_type="heatmap",
        logo_url=None,
        logo_position="left",
        template_color=None,
        dataset_id=1,
        columns=[],
        filters=[],
        total_columns=[],
        dimensions=["category"],
        metrics=[{"field": "sales", "aggregation": "SUM", "label": "Sales"}],
        sort=None,
        column_field="month",
        column_sort_direction="asc",
    )
    defaults.update(overrides)
    return types.SimpleNamespace(**defaults)


# Keyed by the exact `groupby` list _fetch_metrics_matrix asks for at each
# rollup depth: leaf spread (category+month), leaf total (category only),
# grand spread (month only), grand total (no groupby at all).
_FAKE_ROWS = {
    ("category", "month"): [
        {"category": "Furniture", "month": "Jan", "Sales": 100},
        {"category": "Furniture", "month": "Feb", "Sales": 300},
        {"category": "Office Supplies", "month": "Jan", "Sales": 500},
        {"category": "Office Supplies", "month": "Feb", "Sales": 700},
    ],
    ("category",): [
        {"category": "Furniture", "Sales": 400},
        {"category": "Office Supplies", "Sales": 1200},
    ],
    ("month",): [
        {"month": "Jan", "Sales": 600},
        {"month": "Feb", "Sales": 1000},
    ],
    (): [{"Sales": 1600}],
}


def _fake_run_grouped_metrics_query(dataset_id, groupby, metric_specs, filters, sort, force):
    return _FAKE_ROWS[tuple(groupby)]


def test_build_heatmap_excel_shades_leaf_cells_by_value(monkeypatch):
    template = _make_heatmap_template()
    service = TemplateService()
    monkeypatch.setattr(service, "_run_grouped_metrics_query", _fake_run_grouped_metrics_query)

    excel_bytes = service.build_excel(template)
    wb = openpyxl.load_workbook(BytesIO(excel_bytes))
    sheet = wb.active

    def _fill_hex(value):
        for row in sheet.iter_rows():
            for cell in row:
                if cell.value == value:
                    return cell.fill.fgColor.rgb[-6:]  # strip openpyxl's leading alpha byte
        raise AssertionError(f"cell with value {value!r} not found")

    low_hex = "".join(f"{c:02X}" for c in TemplateService._HEATMAP_LOW)
    high_hex = "".join(f"{c:02X}" for c in TemplateService._HEATMAP_HIGH)

    # Every leaf-row value cell (each month column AND that row's own
    # column-pivot "Total") shares one global scale: min=100 (Furniture/Jan),
    # max=1200 (Office Supplies' own row Total, the largest leaf-row cell).
    assert _fill_hex(100) == low_hex
    assert _fill_hex(1200) == high_hex
    # A mid-range leaf value (Office Supplies/Feb = 700) sits strictly between
    # the two endpoints, matching the same interpolation formula directly.
    assert _fill_hex(700) == TemplateService._heatmap_color(700, 100, 1200)

    # Subtotal/grand-total cells keep the existing static teal branding,
    # not a heatmap shade in between.
    assert _fill_hex(1600).startswith("2777")  # grand total (Sales=1600) — dark teal


def test_build_heatmap_pdf_runs_without_error(monkeypatch):
    template = _make_heatmap_template()
    service = TemplateService()
    monkeypatch.setattr(service, "_run_grouped_metrics_query", _fake_run_grouped_metrics_query)

    pdf_bytes = service.build_pdf(template)
    assert pdf_bytes[:4] == b"%PDF"
