import pytest
from sqlalchemy.exc import OperationalError

import app.main as main_module


class _FakeConnection:
    def __init__(self):
        self.executed = []
        self.committed = False

    def execute(self, stmt):
        self.executed.append(stmt)

    def commit(self):
        self.committed = True

    def rollback(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False


class _FakeEngine:
    def __init__(self, results):
        # each entry is either an Exception instance to raise, or a fake
        # connection to return
        self._results = list(results)
        self.connect_calls = 0

    def connect(self):
        self.connect_calls += 1
        result = self._results.pop(0)
        if isinstance(result, Exception):
            raise result
        return result


def _no_real_sleep(monkeypatch):
    monkeypatch.setattr(main_module.time, "sleep", lambda *_: None)


def test_migrate_retries_then_succeeds(monkeypatch):
    _no_real_sleep(monkeypatch)
    fake_conn = _FakeConnection()
    fake_engine = _FakeEngine(
        [
            OperationalError("stmt", {}, Exception("boom 1")),
            OperationalError("stmt", {}, Exception("boom 2")),
            fake_conn,
        ]
    )
    monkeypatch.setattr("app.core.database.engine", fake_engine)

    main_module._migrate_superset_embeds(max_retries=5, base_delay=0)

    assert fake_engine.connect_calls == 3
    assert fake_conn.committed is True


def test_migrate_raises_after_max_retries(monkeypatch):
    _no_real_sleep(monkeypatch)
    fake_engine = _FakeEngine([OperationalError("stmt", {}, Exception("boom")) for _ in range(3)])
    monkeypatch.setattr("app.core.database.engine", fake_engine)

    with pytest.raises(OperationalError):
        main_module._migrate_superset_embeds(max_retries=3, base_delay=0)

    assert fake_engine.connect_calls == 3


def test_migrate_does_not_retry_on_success():
    fake_conn = _FakeConnection()
    fake_engine = _FakeEngine([fake_conn])

    import app.core.database as db_module

    original_engine = db_module.engine
    db_module.engine = fake_engine
    try:
        main_module._migrate_superset_embeds(max_retries=5, base_delay=0)
    finally:
        db_module.engine = original_engine

    assert fake_engine.connect_calls == 1
    assert fake_conn.committed is True


def test_on_startup_continues_if_migration_fails(monkeypatch):
    def _failing_migrate(*args, **kwargs):
        raise RuntimeError("migration boom")

    scheduler_called = []

    def _fake_start_scheduler():
        scheduler_called.append(True)

    monkeypatch.setattr(main_module, "_migrate_superset_embeds", _failing_migrate)
    monkeypatch.setattr(main_module, "start_scheduler", _fake_start_scheduler)

    main_module.on_startup()  # must not raise

    assert scheduler_called == [True]


def test_on_startup_does_not_raise_if_both_fail(monkeypatch):
    def _failing_migrate(*args, **kwargs):
        raise RuntimeError("migration boom")

    def _failing_scheduler():
        raise RuntimeError("scheduler boom")

    monkeypatch.setattr(main_module, "_migrate_superset_embeds", _failing_migrate)
    monkeypatch.setattr(main_module, "start_scheduler", _failing_scheduler)

    main_module.on_startup()  # must not raise despite both failing
