import pytest
from fastapi import HTTPException

from app.core.config import settings
from app.services import gemini_service
from app.services.gemini_service import GeminiService, _detect_chart_type


@pytest.fixture(autouse=True)
def _reset_data_agent_list_cache():
    """_list_data_agents() caches across calls (see
    gemini_service._data_agent_list_cache) — without resetting it, whichever
    of these tests runs first "wins" the cache for the rest of the suite."""
    gemini_service._data_agent_list_cache = None
    yield
    gemini_service._data_agent_list_cache = None


class _FakeGenAIResponse:
    def __init__(self, text):
        self.text = text


class _FakeGenAIClient:
    def __init__(self, sql_text="SELECT 1", error=None):
        self._sql_text = sql_text
        self._error = error
        self.last_prompt = None

    class _Models:
        def __init__(self, outer):
            self._outer = outer

        def generate_content(self, model, contents, config):
            self._outer.last_prompt = contents
            if self._outer._error:
                raise self._outer._error
            return _FakeGenAIResponse(self._outer._sql_text)

    @property
    def models(self):
        return self._Models(self)


class _FakeField:
    def __init__(self, name):
        self.name = name


class _FakeRowsIter:
    def __init__(self, columns, rows):
        self.schema = [_FakeField(c) for c in columns]
        self._rows = rows

    def __iter__(self):
        return iter(self._rows)


class _FakeQueryJob:
    def __init__(self, rows_iter, error=None):
        self._rows_iter = rows_iter
        self._error = error

    def result(self):
        if self._error:
            raise self._error
        return self._rows_iter


class _FakeBQClient:
    def __init__(self, rows_iter=None, error=None):
        self._rows_iter = rows_iter
        self._error = error
        self.last_sql = None

    def query(self, sql):
        self.last_sql = sql
        return _FakeQueryJob(self._rows_iter, error=self._error)


@pytest.fixture(autouse=True)
def _no_cache(monkeypatch):
    """Disable the SQL tool cache by default so repeated identical
    questions across tests never leak results between them."""
    monkeypatch.setattr(settings, "chat_cache_enabled", False)


def _patch_clients(monkeypatch, genai_client=None, bq_client=None):
    if genai_client is not None:
        monkeypatch.setattr(
            "app.services.gemini_service.build_vertex_ai_client", lambda: genai_client
        )
    if bq_client is not None:
        monkeypatch.setattr(
            "app.services.gemini_service._bigquery_client", lambda: bq_client
        )


def test_ask_generates_sql_and_returns_table_from_bigquery(monkeypatch):
    genai_client = _FakeGenAIClient(sql_text="```sql\nSELECT total FROM sales\n```")
    bq_client = _FakeBQClient(rows_iter=_FakeRowsIter(["total"], [{"total": 42}]))
    _patch_clients(monkeypatch, genai_client, bq_client)

    service = GeminiService()
    answer, sql, table, chart = service.ask("What is total revenue?")

    assert "Found 1 result" in answer
    assert sql == "SELECT total FROM sales"
    assert table == {"columns": ["total"], "rows": [[42]]}
    assert bq_client.last_sql == "SELECT total FROM sales"


def test_ask_strips_markdown_fences_around_generated_sql(monkeypatch):
    genai_client = _FakeGenAIClient(sql_text="```\nSELECT 1\n```")
    bq_client = _FakeBQClient(rows_iter=_FakeRowsIter([], []))
    _patch_clients(monkeypatch, genai_client, bq_client)

    service = GeminiService()
    _answer, sql, table, chart = service.ask("Anything?")

    assert sql == "SELECT 1"
    assert table is None
    assert chart is None


def test_ask_raises_http_exception_when_sql_generation_fails(monkeypatch):
    genai_client = _FakeGenAIClient(error=RuntimeError("model unavailable"))
    _patch_clients(monkeypatch, genai_client, _FakeBQClient())

    service = GeminiService()
    with pytest.raises(HTTPException) as exc_info:
        service.ask("What is total revenue?")

    assert exc_info.value.status_code == 502


def test_ask_raises_http_exception_when_bigquery_execution_fails(monkeypatch):
    genai_client = _FakeGenAIClient(sql_text="SELECT 1")
    bq_client = _FakeBQClient(error=RuntimeError("permission denied"))
    _patch_clients(monkeypatch, genai_client, bq_client)

    service = GeminiService()
    with pytest.raises(HTTPException) as exc_info:
        service.ask("What is total revenue?")

    assert exc_info.value.status_code == 502
    assert "permission denied" in exc_info.value.detail


def test_ask_raises_http_exception_when_gemini_returns_no_sql(monkeypatch):
    genai_client = _FakeGenAIClient(sql_text="   ")
    _patch_clients(monkeypatch, genai_client, _FakeBQClient())

    service = GeminiService()
    with pytest.raises(HTTPException) as exc_info:
        service.ask("What is total revenue?")

    assert exc_info.value.status_code == 502


def test_ask_uses_sql_tool_cache(monkeypatch):
    """A second identical question should hit the tool cache instead of
    calling Gemini/BigQuery again."""
    monkeypatch.setattr(settings, "chat_cache_enabled", True)
    from app.services.chat_cache import get_tool_cache

    get_tool_cache().invalidate_all()

    genai_client = _FakeGenAIClient(sql_text="SELECT 1")
    bq_client = _FakeBQClient(rows_iter=_FakeRowsIter(["n"], [{"n": 1}]))
    _patch_clients(monkeypatch, genai_client, bq_client)

    service = GeminiService()
    first = service.ask("What is total revenue?")

    _patch_clients(monkeypatch, _FakeGenAIClient(error=RuntimeError("should not be called")))
    second = service.ask("What is total revenue?")

    assert first == second


def test_detect_chart_type_returns_none_without_numeric_columns():
    assert _detect_chart_type(["name"], [{"name": "a"}]) is None


def test_detect_chart_type_returns_none_for_empty_rows():
    assert _detect_chart_type(["total"], []) is None


def test_detect_chart_type_picks_line_for_date_plus_numeric():
    rows = [{"month": "2026-01", "total": 10}, {"month": "2026-02", "total": 20}]
    chart = _detect_chart_type(["month", "total"], rows)

    assert chart["mark"] == "line"
    assert chart["encoding"]["x"]["field"] == "month"
    assert chart["encoding"]["y"]["field"] == "total"


def test_detect_chart_type_picks_pie_for_small_categorical_result():
    rows = [{"category": "A", "total": 10}, {"category": "B", "total": 20}]
    chart = _detect_chart_type(["category", "total"], rows)

    assert chart["mark"] == "arc"


def test_detect_chart_type_picks_bar_for_larger_categorical_result():
    rows = [{"category": f"cat_{i}", "total": i} for i in range(10)]
    chart = _detect_chart_type(["category", "total"], rows)

    assert chart["mark"] == "bar"


class _FakeSchemaRow:
    def __init__(self, table_name, column_name, data_type):
        self.table_name = table_name
        self.column_name = column_name
        self.data_type = data_type


def test_discover_dataset_schema_groups_columns_by_table(monkeypatch):
    from app.services.gemini_service import _discover_dataset_schema

    rows = [
        _FakeSchemaRow("sales_curated", "order_id", "STRING"),
        _FakeSchemaRow("sales_curated", "sales", "FLOAT64"),
        _FakeSchemaRow("card_transactions", "status", "STRING"),
    ]
    bq_client = _FakeBQClient(rows_iter=_FakeRowsIter([], rows))
    _patch_clients(monkeypatch, bq_client=bq_client)

    result = _discover_dataset_schema("proj", "ds")

    assert "`proj.ds.sales_curated`: columns: order_id (STRING), sales (FLOAT64)" in result
    assert "`proj.ds.card_transactions`: columns: status (STRING)" in result
    assert "INFORMATION_SCHEMA.COLUMNS" in bq_client.last_sql


def test_build_bigquery_table_context_caches_schema_within_ttl(monkeypatch):
    from app.services import gemini_service

    gemini_service._schema_cache.clear()
    monkeypatch.setattr(settings, "bigquery_datasets", '[{"project_id":"proj","dataset_id":"ds"}]')
    monkeypatch.setattr(settings, "bigquery_schema_cache_ttl_seconds", 3600)

    rows = [_FakeSchemaRow("t", "c", "STRING")]
    bq_client = _FakeBQClient(rows_iter=_FakeRowsIter([], rows))
    _patch_clients(monkeypatch, bq_client=bq_client)

    first = gemini_service._build_bigquery_table_context()

    def _explode(sql):
        raise AssertionError("should not re-query BigQuery within the cache TTL")
    bq_client.query = _explode

    second = gemini_service._build_bigquery_table_context()

    assert first == second
    assert "c (STRING)" in first


def test_build_bigquery_table_context_includes_table_notes(monkeypatch):
    from app.services import gemini_service

    gemini_service._schema_cache.clear()
    monkeypatch.setattr(
        settings, "bigquery_datasets",
        '[{"project_id":"proj","dataset_id":"ds","table_notes":{"t":"extra business context"}}]',
    )
    rows = [_FakeSchemaRow("t", "c", "STRING")]
    bq_client = _FakeBQClient(rows_iter=_FakeRowsIter([], rows))
    _patch_clients(monkeypatch, bq_client=bq_client)

    result = gemini_service._build_bigquery_table_context()

    assert "extra business context" in result


def test_build_bigquery_table_context_falls_back_to_stale_cache_on_discovery_error(monkeypatch):
    from app.services import gemini_service

    gemini_service._schema_cache.clear()
    monkeypatch.setattr(settings, "bigquery_datasets", '[{"project_id":"proj","dataset_id":"ds"}]')
    monkeypatch.setattr(settings, "bigquery_schema_cache_ttl_seconds", 0)  # force re-discovery every call

    rows = [_FakeSchemaRow("t", "c", "STRING")]
    bq_client = _FakeBQClient(rows_iter=_FakeRowsIter([], rows))
    _patch_clients(monkeypatch, bq_client=bq_client)
    first = gemini_service._build_bigquery_table_context()
    assert "c (STRING)" in first

    _patch_clients(monkeypatch, bq_client=_FakeBQClient(error=RuntimeError("bq down")))
    second = gemini_service._build_bigquery_table_context()

    assert second == first  # served stale cache instead of an empty context


class _FakeDataAgentClient:
    def __init__(self, chunks=None, error=None):
        self._chunks = chunks or []
        self._error = error
        self.last_request = None

    def chat(self, request, timeout=None):
        self.last_request = request
        if self._error:
            raise self._error
        return iter(self._chunks)


def test_resolve_data_agent_returns_none_when_nothing_configured():
    service = GeminiService()

    assert service._resolve_data_agent(None) is None


def test_resolve_data_agent_builds_resource_name_from_env_vars(monkeypatch):
    monkeypatch.setattr(settings, "gemini_data_agent_id", "agent123")
    monkeypatch.setattr(settings, "gemini_data_agent_location", "eu")
    service = GeminiService()

    resolved = service._resolve_data_agent(None)

    assert resolved == f"projects/{settings.google_cloud_project}/locations/eu/dataAgents/agent123"


def test_resolve_data_agent_prefers_explicit_agent_name_over_env_vars(monkeypatch):
    monkeypatch.setattr(settings, "gemini_data_agent_id", "agent123")
    monkeypatch.setattr(settings, "gemini_data_agent_location", "eu")
    service = GeminiService()

    resolved = service._resolve_data_agent("projects/p/locations/us/dataAgents/override")

    assert resolved == "projects/p/locations/us/dataAgents/override"


def test_ask_uses_data_agent_when_configured_and_skips_bigquery(monkeypatch):
    monkeypatch.setattr(settings, "gemini_data_agent_id", "agent123")
    monkeypatch.setattr(settings, "gemini_data_agent_location", "eu")
    service = GeminiService()
    service._clients = {
        "eu": _FakeDataAgentClient(
            chunks=[{"systemMessage": {"text": {"textType": "FINAL_RESPONSE", "parts": ["42"]}}}]
        )
    }

    def _explode(question):
        raise AssertionError("should not fall back to direct BigQuery when the Data Agent succeeds")
    monkeypatch.setattr(service, "_query_bigquery", _explode)

    answer, sql, table, chart = service.ask("What is total revenue?")

    assert answer == "42"


def test_ask_falls_back_to_bigquery_when_data_agent_call_fails(monkeypatch):
    monkeypatch.setattr(settings, "gemini_data_agent_id", "agent123")
    monkeypatch.setattr(settings, "gemini_data_agent_location", "eu")
    service = GeminiService()
    service._clients = {"eu": _FakeDataAgentClient(error=RuntimeError("boom"))}

    genai_client = _FakeGenAIClient(sql_text="SELECT 1")
    bq_client = _FakeBQClient(rows_iter=_FakeRowsIter(["n"], [{"n": 7}]))
    _patch_clients(monkeypatch, genai_client, bq_client)

    answer, sql, table, chart = service.ask("What is total revenue?")

    assert "Found 1 result" in answer
    assert table == {"columns": ["n"], "rows": [[7]]}


def test_ask_falls_back_to_bigquery_when_data_agent_returns_no_answer(monkeypatch):
    monkeypatch.setattr(settings, "gemini_data_agent_id", "agent123")
    monkeypatch.setattr(settings, "gemini_data_agent_location", "eu")
    service = GeminiService()
    service._clients = {"eu": _FakeDataAgentClient(chunks=[])}  # no FINAL_RESPONSE text

    genai_client = _FakeGenAIClient(sql_text="SELECT 1")
    bq_client = _FakeBQClient(rows_iter=_FakeRowsIter(["n"], [{"n": 7}]))
    _patch_clients(monkeypatch, genai_client, bq_client)

    answer, sql, table, chart = service.ask("What is total revenue?")

    assert "Found 1 result" in answer


def test_ask_without_agent_name_still_uses_env_var_configured_agent(monkeypatch):
    """agent_name is optional (defaults to None) — the static env-var agent
    should still be used even when the caller doesn't pass one explicitly."""
    monkeypatch.setattr(settings, "gemini_data_agent_id", "agent123")
    monkeypatch.setattr(settings, "gemini_data_agent_location", "eu")
    service = GeminiService()
    service._clients = {
        "eu": _FakeDataAgentClient(
            chunks=[{"systemMessage": {"text": {"textType": "FINAL_RESPONSE", "parts": ["answer"]}}}]
        )
    }

    answer, _sql, _table, _chart = service.ask("What is total revenue?")

    assert answer == "answer"


def test_ask_uses_explicit_agent_name_per_call(monkeypatch):
    """agent_name passed directly to ask() (e.g. from the Chat Assistant's
    per-question picker) takes precedence, with no env vars configured."""
    service = GeminiService()
    fake_client = _FakeDataAgentClient(
        chunks=[{"systemMessage": {"text": {"textType": "FINAL_RESPONSE", "parts": ["picked-agent-answer"]}}}]
    )
    service._clients = {"eu": fake_client}

    answer, _sql, _table, _chart = service.ask(
        "What is total revenue?", agent_name="projects/p/locations/eu/dataAgents/custom1"
    )

    assert answer == "picked-agent-answer"
    assert fake_client.last_request.data_agent_context.data_agent == (
        "projects/p/locations/eu/dataAgents/custom1"
    )


class _FakeDataAgent:
    def __init__(self, name, display_name, labels=None):
        self.name = name
        self.display_name = display_name
        self.labels = labels or {}


class _FakeDataAgentServiceClient:
    def __init__(self, *args, **kwargs):
        pass

    def list_data_agents(self, parent):
        # Only "global" has agents — mirrors a real project where different
        # Data Agent locations return different (often empty) results.
        if not parent.endswith("/locations/global"):
            return []
        return [
            _FakeDataAgent(
                "projects/p/locations/global/dataAgents/sample1",
                "The Look Graph",
                labels={"sample-agent-signature": "sample_agent_looker_ecommerce_graph_v2", "readonly": "true"},
            ),
            _FakeDataAgent(
                "projects/p/locations/global/dataAgents/custom1",
                "BigQuery Sales Assistant",
                labels={},
            ),
        ]


def test_list_data_agents_excludes_googles_built_in_sample_agents(monkeypatch):
    from app.services import gemini_service

    monkeypatch.setattr(
        "google.cloud.geminidataanalytics_v1.DataAgentServiceClient", _FakeDataAgentServiceClient
    )
    monkeypatch.setattr(settings, "data_agent_picker_include_samples", False)

    agents = gemini_service._list_data_agents()

    assert [a.name for a in agents] == ["projects/p/locations/global/dataAgents/custom1"]
    assert agents[0].display_name == "BigQuery Sales Assistant"


def test_list_data_agents_includes_samples_when_flag_enabled(monkeypatch):
    from app.services import gemini_service

    monkeypatch.setattr(
        "google.cloud.geminidataanalytics_v1.DataAgentServiceClient", _FakeDataAgentServiceClient
    )
    monkeypatch.setattr(settings, "data_agent_picker_include_samples", True)

    agents = gemini_service._list_data_agents()

    assert [a.name for a in agents] == [
        "projects/p/locations/global/dataAgents/sample1",
        "projects/p/locations/global/dataAgents/custom1",
    ]
