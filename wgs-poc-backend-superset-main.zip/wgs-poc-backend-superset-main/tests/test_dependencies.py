import pytest
from fastapi import HTTPException

from app.api.dependencies import require_permission
from app.schemas.role import AccessLevel, Module


class _FakePermission:
    def __init__(self, module, access_level):
        self.module = module
        self.access_level = access_level


class _FakeRole:
    def __init__(self, name, permissions=None):
        self.name = name
        self.permissions = permissions or []


class _FakeUser:
    def __init__(self, role):
        self.role = role


def test_require_permission_allows_admin_regardless_of_stored_permissions():
    """Admin has zero real role_permissions rows (see migration
    009_seed_admin_role_permissions.py) — RoleService.get_permissions()
    synthesizes EDIT for every module, so require_permission must let
    Admin through even with an empty permissions list."""
    admin = _FakeUser(_FakeRole("Admin", permissions=[]))
    dependency = require_permission(Module.API_ENDPOINTS, AccessLevel.EDIT)

    assert dependency(current_user=admin) is admin


def test_require_permission_allows_when_role_has_sufficient_access():
    dev = _FakeUser(_FakeRole("Developer", permissions=[_FakePermission("rest_endpoints", "read")]))
    dependency = require_permission(Module.API_ENDPOINTS, AccessLevel.READ)

    assert dependency(current_user=dev) is dev


def test_require_permission_allows_edit_role_for_read_requirement():
    dev = _FakeUser(_FakeRole("Developer", permissions=[_FakePermission("rest_endpoints", "edit")]))
    dependency = require_permission(Module.API_ENDPOINTS, AccessLevel.READ)

    assert dependency(current_user=dev) is dev


def test_require_permission_rejects_when_role_has_insufficient_access():
    dev = _FakeUser(_FakeRole("Developer", permissions=[_FakePermission("rest_endpoints", "read")]))
    dependency = require_permission(Module.API_ENDPOINTS, AccessLevel.EDIT)

    with pytest.raises(HTTPException) as exc_info:
        dependency(current_user=dev)
    assert exc_info.value.status_code == 403


def test_require_permission_rejects_when_module_has_no_permission_row():
    dev = _FakeUser(_FakeRole("Developer", permissions=[]))
    dependency = require_permission(Module.API_ENDPOINTS, AccessLevel.READ)

    with pytest.raises(HTTPException) as exc_info:
        dependency(current_user=dev)
    assert exc_info.value.status_code == 403


def test_require_permission_rejects_when_role_permission_is_explicitly_none():
    dev = _FakeUser(_FakeRole("Developer", permissions=[_FakePermission("rest_endpoints", "none")]))
    dependency = require_permission(Module.API_ENDPOINTS, AccessLevel.READ)

    with pytest.raises(HTTPException) as exc_info:
        dependency(current_user=dev)
    assert exc_info.value.status_code == 403


def test_require_permission_rejects_when_user_has_no_role():
    user = _FakeUser(role=None)
    dependency = require_permission(Module.API_ENDPOINTS, AccessLevel.READ)

    with pytest.raises(HTTPException) as exc_info:
        dependency(current_user=user)
    assert exc_info.value.status_code == 403


def test_require_permission_is_scoped_per_module():
    """Read access to Reports shouldn't grant access to API Endpoints."""
    dev = _FakeUser(_FakeRole("Developer", permissions=[_FakePermission("reports", "edit")]))
    dependency = require_permission(Module.API_ENDPOINTS, AccessLevel.READ)

    with pytest.raises(HTTPException) as exc_info:
        dependency(current_user=dev)
    assert exc_info.value.status_code == 403


def test_require_permission_original_bug_scenario():
    """Regression test: Developer role with API Endpoints=Read should be
    able to satisfy list_endpoint_registrations' READ requirement — this
    is the exact scenario that used to 403 with 'Admin privileges
    required' before require_permission replaced require_admin."""
    dev = _FakeUser(_FakeRole("Developer", permissions=[_FakePermission("rest_endpoints", "read")]))
    dependency = require_permission(Module.API_ENDPOINTS, AccessLevel.READ)

    assert dependency(current_user=dev) is dev
