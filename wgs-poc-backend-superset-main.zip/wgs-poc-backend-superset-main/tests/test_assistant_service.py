import pytest

from app.core.config import settings
from app.services.assistant_service import AssistantService
from app.services.router_service import IntentClassification


class _FakeGeminiService:
    def __init__(self, answer="42", sql="SELECT 1", table=None, chart=None):
        self._answer = answer
        self._sql = sql
        self._table = table
        self._chart = chart
        self.calls = []
        self.agent_names = []

    def ask(self, question, agent_name=None):
        self.calls.append(question)
        self.agent_names.append(agent_name)
        return self._answer, self._sql, self._table, self._chart


@pytest.fixture(autouse=True)
def _no_cache_no_quality_loop(monkeypatch):
    """Keep these unit tests deterministic and fast — no caching leaking
    across tests, no live Gemini calls for the self-critique loop."""
    monkeypatch.setattr(settings, "chat_cache_enabled", False)
    monkeypatch.setattr(settings, "quality_loop_enabled", False)


@pytest.fixture(autouse=True)
def _sql_intent(monkeypatch):
    """Route every question straight to SQL — isolates these tests from the
    live intent-classification model call."""
    monkeypatch.setattr(
        "app.services.assistant_service.classify_intent",
        lambda question, conversation_context="": IntentClassification(
            intent="SQL", sql_question=question, confidence=0.9
        ),
    )


@pytest.fixture(autouse=True)
def _stub_synthesis(monkeypatch):
    """Skip the live synthesis model call — just echo the SQL Data Agent's
    own answer, isolating these tests from the live model call."""
    monkeypatch.setattr(
        "app.services.assistant_service.synthesize_answer",
        lambda question, intent, sql_result, rag_result, conversation_context="": sql_result["answer"],
    )


def test_ask_delegates_straight_to_gemini_service():
    fake_gemini = _FakeGeminiService(
        answer="Total revenue is $1M",
        sql="SELECT SUM(sales) FROM t",
        table={"columns": ["total"], "rows": [["1000000"]]},
        chart={"mark": "bar"},
    )
    service = AssistantService(data_service=fake_gemini)

    result = service.ask("What is total revenue?", db=None, session_id="s1")

    assert result.answer == "Total revenue is $1M"
    assert result.sql == "SELECT SUM(sales) FROM t"
    assert result.table == {"columns": ["total"], "rows": [["1000000"]]}
    assert result.chart == {"mark": "bar"}
    assert result.session_id == "s1"
    assert fake_gemini.calls == ["What is total revenue?"]


def test_ask_forwards_agent_name_to_gemini_service():
    fake_gemini = _FakeGeminiService()
    service = AssistantService(data_service=fake_gemini)

    service.ask("What is total revenue?", db=None, session_id="s1", agent_name="projects/p/locations/eu/dataAgents/a")

    assert fake_gemini.agent_names == ["projects/p/locations/eu/dataAgents/a"]


def test_ask_defaults_to_a_real_gemini_service_when_none_given():
    from app.services.gemini_service import GeminiService

    service = AssistantService()

    assert isinstance(service._data_service, GeminiService)
