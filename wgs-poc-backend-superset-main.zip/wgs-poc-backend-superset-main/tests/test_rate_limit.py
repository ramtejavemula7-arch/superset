import pytest
from fastapi import HTTPException

import app.core.rate_limit as rate_limit_module
from app.core.rate_limit import InMemoryRateLimiter


def test_allows_requests_under_the_limit():
    limiter = InMemoryRateLimiter(max_requests=3, window_seconds=60)
    for _ in range(3):
        limiter.check("user-1")  # should not raise


def test_blocks_requests_over_the_limit():
    limiter = InMemoryRateLimiter(max_requests=2, window_seconds=60)
    limiter.check("user-1")
    limiter.check("user-1")

    with pytest.raises(HTTPException) as exc_info:
        limiter.check("user-1")

    assert exc_info.value.status_code == 429


def test_limits_are_independent_per_key():
    limiter = InMemoryRateLimiter(max_requests=1, window_seconds=60)
    limiter.check("user-1")
    limiter.check("user-2")  # different key, should not raise


def test_old_hits_expire_out_of_the_window(monkeypatch):
    limiter = InMemoryRateLimiter(max_requests=1, window_seconds=60)
    current_time = [1000.0]
    monkeypatch.setattr(rate_limit_module.time, "monotonic", lambda: current_time[0])

    limiter.check("user-1")
    with pytest.raises(HTTPException):
        limiter.check("user-1")

    current_time[0] += 61  # move past the window
    limiter.check("user-1")  # should not raise now
