import types
from unittest.mock import patch

import pytest
from fastapi import HTTPException
from pydantic import ValidationError
from sqlalchemy import create_engine
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import sessionmaker

from app.models.endpoint_registration import EndpointRegistration
from app.schemas.endpoint_registration import (
    EndpointRegistrationCreate,
    EndpointRegistrationTestDraft,
    EndpointRegistrationUpdate,
)
from app.services.endpoint_auth_handlers import (
    ApiKeyAuthHandler,
    BasicAuthHandler,
    BearerTokenAuthHandler,
    NoneAuthHandler,
    OutboundRequestSpec,
    get_auth_handler,
)
from app.services.endpoint_registration_service import EndpointRegistrationService
from app.services.endpoint_test_connection_service import EndpointTestConnectionService


# ------------------------------------------------------------------ #
# Auth handlers — pure, no mocking needed                             #
# ------------------------------------------------------------------ #

def test_none_auth_handler_is_a_no_op():
    spec = OutboundRequestSpec()
    NoneAuthHandler().apply(spec, {}, None)
    assert spec == OutboundRequestSpec()


def test_api_key_auth_handler_sends_in_header_by_default():
    spec = OutboundRequestSpec()
    ApiKeyAuthHandler().apply(spec, {"api_key_name": "X-Api-Key", "send_in": "header"}, "secret123")
    assert spec.headers == {"X-Api-Key": "secret123"}
    assert spec.params == {}
    assert spec.cookies == {}


def test_api_key_auth_handler_sends_in_query():
    spec = OutboundRequestSpec()
    ApiKeyAuthHandler().apply(spec, {"api_key_name": "api_key", "send_in": "query"}, "secret123")
    assert spec.params == {"api_key": "secret123"}
    assert spec.headers == {}


def test_api_key_auth_handler_sends_in_cookie():
    spec = OutboundRequestSpec()
    ApiKeyAuthHandler().apply(spec, {"api_key_name": "session", "send_in": "cookie"}, "secret123")
    assert spec.cookies == {"session": "secret123"}


def test_basic_auth_handler_sets_auth_tuple():
    spec = OutboundRequestSpec()
    BasicAuthHandler().apply(spec, {"username": "alice"}, "hunter2")
    assert spec.auth == ("alice", "hunter2")


def test_bearer_token_auth_handler_sets_authorization_header():
    spec = OutboundRequestSpec()
    BearerTokenAuthHandler().apply(spec, {}, "abc.def.ghi")
    assert spec.headers == {"Authorization": "Bearer abc.def.ghi"}


def test_get_auth_handler_unknown_type_raises_400():
    with pytest.raises(HTTPException) as exc_info:
        get_auth_handler("oauth2")
    assert exc_info.value.status_code == 400


# ------------------------------------------------------------------ #
# Schema validation                                                    #
# ------------------------------------------------------------------ #

def test_create_requires_secret_value_for_non_none_auth_type():
    with pytest.raises(ValidationError):
        EndpointRegistrationCreate(
            name="X", base_url="https://example.com", auth_type="bearer_token", auth_config={},
        )


def test_create_allows_missing_secret_value_for_none_auth_type():
    payload = EndpointRegistrationCreate(name="X", base_url="https://example.com", auth_type="none")
    assert payload.secret_value is None


def test_create_validates_auth_config_shape_for_api_key():
    with pytest.raises(ValidationError):
        EndpointRegistrationCreate(
            name="X", base_url="https://example.com", auth_type="api_key",
            auth_config={}, secret_value="k",  # missing required api_key_name
        )


# ------------------------------------------------------------------ #
# CRUD service + secret lifecycle, against a fake Secret Manager      #
# ------------------------------------------------------------------ #

class _FakeSecretManagerService:
    """In-memory stand-in — GCP Secret Manager isn't provisioned yet, so
    this is how create/rotate/delete lifecycle rules get exercised."""

    def __init__(self):
        self.secrets: dict[str, str] = {}
        self.calls: list[tuple] = []

    def create_secret(self, secret_id: str, secret_value: str) -> str:
        resource_name = f"projects/fake-project/secrets/{secret_id}"
        self.secrets[resource_name] = secret_value
        self.calls.append(("create", resource_name, secret_value))
        return resource_name

    def add_secret_version(self, secret_reference: str, secret_value: str) -> str:
        self.secrets[secret_reference] = secret_value
        self.calls.append(("rotate", secret_reference, secret_value))
        return f"{secret_reference}/versions/2"

    def access_secret_value(self, secret_reference: str, version: str = "latest") -> str:
        return self.secrets[secret_reference]

    def delete_secret(self, secret_reference: str) -> None:
        self.secrets.pop(secret_reference, None)
        self.calls.append(("delete", secret_reference))


def _make_db_session():
    engine = create_engine("sqlite:///:memory:")
    EndpointRegistration.__table__.create(engine, checkfirst=True)
    return sessionmaker(bind=engine)()


def test_create_with_secret_stores_reference_not_raw_value():
    db = _make_db_session()
    secrets = _FakeSecretManagerService()
    service = EndpointRegistrationService(secret_manager=secrets)

    payload = EndpointRegistrationCreate(
        name="Employee API", base_url="https://example.com", auth_type="bearer_token",
        secret_value="super-secret-token",
    )
    endpoint = service.create(db, payload)

    assert endpoint.secret_reference is not None
    assert endpoint.secret_reference in secrets.secrets
    assert secrets.secrets[endpoint.secret_reference] == "super-secret-token"
    # the raw value never lands on the model/row itself
    assert "super-secret-token" not in [
        getattr(endpoint, c.name) for c in EndpointRegistration.__table__.columns if c.name != "secret_reference"
    ]


def test_create_with_none_auth_type_never_calls_secret_manager():
    db = _make_db_session()
    secrets = _FakeSecretManagerService()
    service = EndpointRegistrationService(secret_manager=secrets)

    payload = EndpointRegistrationCreate(name="Public API", base_url="https://example.com", auth_type="none")
    endpoint = service.create(db, payload)

    assert endpoint.secret_reference is None
    assert secrets.calls == []


def test_create_failure_rolls_back_the_just_created_secret():
    db = _make_db_session()
    secrets = _FakeSecretManagerService()
    service = EndpointRegistrationService(secret_manager=secrets)

    # First insert succeeds and takes the name "Dup".
    service.create(db, EndpointRegistrationCreate(name="Dup", base_url="https://example.com", auth_type="none"))

    # Second insert with the same unique `name` fails at db.commit() —
    # simulates any DB-side failure after the secret was already created.
    payload = EndpointRegistrationCreate(
        name="Dup", base_url="https://example.com", auth_type="bearer_token", secret_value="token-2",
    )
    with pytest.raises(IntegrityError):
        service.create(db, payload)

    # Secret Manager and Postgres aren't one transaction — the compensating
    # delete must have happened, so no orphaned secret is left behind.
    assert secrets.secrets == {}


def test_update_without_secret_value_leaves_existing_secret_untouched():
    db = _make_db_session()
    secrets = _FakeSecretManagerService()
    service = EndpointRegistrationService(secret_manager=secrets)

    endpoint = service.create(db, EndpointRegistrationCreate(
        name="X", base_url="https://example.com", auth_type="bearer_token", secret_value="v1",
    ))
    secrets.calls.clear()

    service.update(db, endpoint.id, EndpointRegistrationUpdate(description="just a note"))

    assert secrets.calls == []  # no create/rotate/delete calls at all
    assert secrets.secrets[endpoint.secret_reference] == "v1"


def test_update_with_secret_value_same_auth_type_rotates_in_place():
    db = _make_db_session()
    secrets = _FakeSecretManagerService()
    service = EndpointRegistrationService(secret_manager=secrets)

    endpoint = service.create(db, EndpointRegistrationCreate(
        name="X", base_url="https://example.com", auth_type="bearer_token", secret_value="v1",
    ))
    original_reference = endpoint.secret_reference
    secrets.calls.clear()

    updated = service.update(db, endpoint.id, EndpointRegistrationUpdate(secret_value="v2"))

    assert updated.secret_reference == original_reference  # same reference, rotated version
    assert secrets.secrets[original_reference] == "v2"
    assert secrets.calls == [("rotate", original_reference, "v2")]


def test_update_changing_auth_type_deletes_old_secret_and_creates_new():
    db = _make_db_session()
    secrets = _FakeSecretManagerService()
    service = EndpointRegistrationService(secret_manager=secrets)

    endpoint = service.create(db, EndpointRegistrationCreate(
        name="X", base_url="https://example.com", auth_type="bearer_token", secret_value="v1",
    ))
    old_reference = endpoint.secret_reference

    updated = service.update(db, endpoint.id, EndpointRegistrationUpdate(
        auth_type="basic_auth", auth_config={"username": "alice"}, secret_value="password1",
    ))

    assert old_reference not in secrets.secrets
    assert updated.secret_reference != old_reference
    assert secrets.secrets[updated.secret_reference] == "password1"


def test_update_changing_auth_type_to_none_deletes_secret():
    db = _make_db_session()
    secrets = _FakeSecretManagerService()
    service = EndpointRegistrationService(secret_manager=secrets)

    endpoint = service.create(db, EndpointRegistrationCreate(
        name="X", base_url="https://example.com", auth_type="bearer_token", secret_value="v1",
    ))
    old_reference = endpoint.secret_reference

    updated = service.update(db, endpoint.id, EndpointRegistrationUpdate(auth_type="none"))

    assert old_reference not in secrets.secrets
    assert updated.secret_reference is None


def test_delete_is_best_effort_cleanup_of_the_secret():
    db = _make_db_session()
    secrets = _FakeSecretManagerService()
    service = EndpointRegistrationService(secret_manager=secrets)

    endpoint = service.create(db, EndpointRegistrationCreate(
        name="X", base_url="https://example.com", auth_type="bearer_token", secret_value="v1",
    ))
    reference = endpoint.secret_reference

    assert service.delete(db, endpoint.id) is True
    assert reference not in secrets.secrets
    assert service.get_by_id(db, endpoint.id) is None


def test_delete_missing_endpoint_returns_false():
    db = _make_db_session()
    service = EndpointRegistrationService(secret_manager=_FakeSecretManagerService())
    assert service.delete(db, 999) is False


# ------------------------------------------------------------------ #
# Test-connection service — requests mocked                           #
# ------------------------------------------------------------------ #

def _fake_response(status_code=200, text='{"ok": true}'):
    resp = types.SimpleNamespace(status_code=status_code, text=text)
    resp.ok = 200 <= status_code < 400
    return resp


def test_test_draft_bearer_token_sends_authorization_header():
    with patch("app.services.endpoint_test_connection_service.requests.request") as mock_request:
        mock_request.return_value = _fake_response()
        service = EndpointTestConnectionService()
        payload = EndpointRegistrationTestDraft(
            name="X", base_url="https://example.com", endpoint_path="/v1/ping",
            auth_type="bearer_token", secret_value="tok123",
        )
        result = service.test_draft(payload)

        assert result.success is True
        assert result.status_code == 200
        _, kwargs = mock_request.call_args
        assert kwargs["headers"]["Authorization"] == "Bearer tok123"
        assert kwargs["url"] == "https://example.com/v1/ping"


def test_test_draft_api_key_in_query():
    with patch("app.services.endpoint_test_connection_service.requests.request") as mock_request:
        mock_request.return_value = _fake_response()
        service = EndpointTestConnectionService()
        payload = EndpointRegistrationTestDraft(
            name="X", base_url="https://example.com", auth_type="api_key",
            auth_config={"api_key_name": "api_key", "send_in": "query"}, secret_value="k1",
        )
        service.test_draft(payload)

        _, kwargs = mock_request.call_args
        assert kwargs["params"] == {"api_key": "k1"}


def test_test_draft_reports_http_error_status_as_unsuccessful():
    with patch("app.services.endpoint_test_connection_service.requests.request") as mock_request:
        mock_request.return_value = _fake_response(status_code=500, text="server error")
        service = EndpointTestConnectionService()
        payload = EndpointRegistrationTestDraft(name="X", base_url="https://example.com", auth_type="none")
        result = service.test_draft(payload)

        assert result.success is False
        assert result.status_code == 500


def test_test_draft_reports_connection_error_without_raising():
    import requests as requests_module

    with patch("app.services.endpoint_test_connection_service.requests.request") as mock_request:
        mock_request.side_effect = requests_module.ConnectionError("boom")
        service = EndpointTestConnectionService()
        payload = EndpointRegistrationTestDraft(name="X", base_url="https://example.com", auth_type="none")
        result = service.test_draft(payload)

        assert result.success is False
        assert result.status_code is None
        assert "boom" in result.message


def test_test_saved_resolves_secret_from_secret_manager():
    db = _make_db_session()
    secrets = _FakeSecretManagerService()
    registration_service = EndpointRegistrationService(secret_manager=secrets)
    endpoint = registration_service.create(db, EndpointRegistrationCreate(
        name="X", base_url="https://example.com", auth_type="bearer_token", secret_value="real-token",
    ))

    with patch("app.services.endpoint_test_connection_service.requests.request") as mock_request:
        mock_request.return_value = _fake_response()
        test_service = EndpointTestConnectionService(registration_service)
        test_service.test_saved(endpoint)

        _, kwargs = mock_request.call_args
        assert kwargs["headers"]["Authorization"] == "Bearer real-token"
