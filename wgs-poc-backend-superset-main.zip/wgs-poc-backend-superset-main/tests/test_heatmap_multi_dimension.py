import types
from io import BytesIO

import openpyxl

from app.services.template_service import TemplateService


def _make_heatmap_template(**overrides):
    defaults = dict(
        name="Sales by Category",
        template_type="heatmap",
        logo_url=None,
        logo_position="left",
        template_color=None,
        dataset_id=1,
        columns=[],
        filters=[],
        total_columns=[],
        dimensions=["category", "subcategory"],
        metrics=[{"field": "sales", "aggregation": "SUM", "label": "Sales"}],
        sort=None,
        column_field=None,
        column_sort_direction="asc",
    )
    defaults.update(overrides)
    return types.SimpleNamespace(**defaults)


# Depth 2 (leaf) query has no column_field, so groupby == prefix at every
# depth — only one query per depth is needed (no separate "total" query).
_FAKE_ROWS = {
    ("category", "subcategory"): [
        {"category": "Furniture", "subcategory": "Chairs", "Sales": 100},
        {"category": "Furniture", "subcategory": "Tables", "Sales": 200},
        {"category": "Office", "subcategory": "Pens", "Sales": 50},
    ],
    ("category",): [
        {"category": "Furniture", "Sales": 300},
        {"category": "Office", "Sales": 50},
    ],
    (): [{"Sales": 350}],
}


def _fake_run_grouped_metrics_query(dataset_id, groupby, metric_specs, filters, sort, force):
    return _FAKE_ROWS[tuple(groupby)]


def test_matrix_label_merge_spans_groups_ancestor_plus_descendants():
    service = TemplateService()
    monkeypatch_rows = [
        {"label": "Furniture", "depth": 0, "kind": "subtotal"},
        {"label": "Chairs", "depth": 1, "kind": "leaf"},
        {"label": "Tables", "depth": 1, "kind": "leaf"},
        {"label": "Office", "depth": 0, "kind": "subtotal"},
        {"label": "Pens", "depth": 1, "kind": "leaf"},
        {"label": "Grand Total", "depth": 0, "kind": "grand"},
    ]
    spans = service._matrix_label_merge_spans(monkeypatch_rows, num_dims=2)
    # Only depth 0 (Category) merges — depth 1 (Subcategory, the leaf level)
    # is one distinct value per row and never spans multiple rows.
    assert spans == {0: [(0, 3), (3, 2)]}


def test_build_heatmap_excel_has_one_column_per_dimension_with_merges(monkeypatch):
    template = _make_heatmap_template()
    service = TemplateService()
    monkeypatch.setattr(service, "_run_grouped_metrics_query", _fake_run_grouped_metrics_query)

    excel_bytes = service.build_excel(template)
    wb = openpyxl.load_workbook(BytesIO(excel_bytes))
    sheet = wb.active

    # Two distinct header cells for the two dimensions, not one combined column
    header_row = next(
        ri for ri in range(1, sheet.max_row + 1)
        if sheet.cell(row=ri, column=1).value == "Category"
    )
    assert sheet.cell(row=header_row, column=2).value == "Subcategory"
    assert sheet.cell(row=header_row, column=3).value == "Sales"

    furniture_row = next(
        ri for ri in range(1, sheet.max_row + 1)
        if sheet.cell(row=ri, column=1).value == "Furniture"
    )
    # Furniture's own subtotal row: Subcategory column is blank (no
    # subcategory at this level), and it carries its own aggregate (300).
    assert sheet.cell(row=furniture_row, column=2).value is None
    assert sheet.cell(row=furniture_row, column=3).value == 300
    # "Chairs"/"Tables" sit in the Subcategory column on the following rows,
    # with Category left blank there (visually merged from the row above).
    assert sheet.cell(row=furniture_row + 1, column=1).value is None
    assert sheet.cell(row=furniture_row + 1, column=2).value == "Chairs"
    assert sheet.cell(row=furniture_row + 1, column=3).value == 100
    assert sheet.cell(row=furniture_row + 2, column=1).value is None
    assert sheet.cell(row=furniture_row + 2, column=2).value == "Tables"
    assert sheet.cell(row=furniture_row + 2, column=3).value == 200

    # The Category column is actually merged (not just visually blanked) across
    # its own row + both descendant rows.
    merged_ranges = {str(r) for r in sheet.merged_cells.ranges}
    assert f"A{furniture_row}:A{furniture_row + 2}" in merged_ranges

    office_row = furniture_row + 3
    assert sheet.cell(row=office_row, column=1).value == "Office"
    assert sheet.cell(row=office_row, column=3).value == 50
    assert sheet.cell(row=office_row + 1, column=2).value == "Pens"
    assert f"A{office_row}:A{office_row + 1}" in merged_ranges

    # Grand Total's label spans the whole row-header area (both columns)
    grand_row = office_row + 2
    assert sheet.cell(row=grand_row, column=1).value == "Grand Total"
    assert sheet.cell(row=grand_row, column=3).value == 350
    assert f"A{grand_row}:B{grand_row}" in merged_ranges


def test_build_heatmap_pdf_runs_without_error_with_multiple_dimensions(monkeypatch):
    template = _make_heatmap_template()
    service = TemplateService()
    monkeypatch.setattr(service, "_run_grouped_metrics_query", _fake_run_grouped_metrics_query)

    pdf_bytes = service.build_pdf(template)
    assert pdf_bytes[:4] == b"%PDF"
