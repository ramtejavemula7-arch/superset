import types

from app.api.routes import superset as superset_routes


class _FakeResponse:
    def __init__(self, status_code, payload=None):
        self.status_code = status_code
        self.ok = 200 <= status_code < 300
        self._payload = payload or {}

    def json(self):
        return self._payload

    def raise_for_status(self):
        if not self.ok:
            raise AssertionError(f"unexpected status {self.status_code}")


def _dashboard_list_response(items):
    return _FakeResponse(200, {"result": items})


def test_list_superset_dashboards_uses_embed_specific_uuid(monkeypatch):
    # Dashboard's own "uuid" (from /api/v1/dashboard/) must NOT be what's
    # returned — the embed-specific uuid (from /embedded) is what actually
    # works with Superset's /embedded/<uuid> route and guest tokens. Already
    # carries our own origin in allowed_domains, so no PUT should fire.
    monkeypatch.setattr(superset_routes, "get_superset_admin_token", lambda: "fake-token")
    monkeypatch.setattr(superset_routes.settings, "cors_origins", "http://localhost:5173")

    def fake_get(url, **kwargs):
        if url.endswith("/api/v1/dashboard/"):
            return _dashboard_list_response([
                {"id": 1, "dashboard_title": "Sales Dashboard", "uuid": "regular-uuid"},
            ])
        if url.endswith("/api/v1/dashboard/1/embedded"):
            return _FakeResponse(200, {"result": {
                "uuid": "embed-uuid-1", "allowed_domains": ["http://localhost:5173"],
            }})
        raise AssertionError(f"unexpected GET {url}")

    def fake_put(url, **kwargs):
        raise AssertionError("PUT should not be called when allowed_domains already satisfied")

    monkeypatch.setattr(superset_routes.requests, "get", fake_get)
    monkeypatch.setattr(superset_routes.requests, "put", fake_put)

    results = superset_routes.list_superset_dashboards()

    assert results == [{"id": 1, "dashboard_title": "Sales Dashboard", "uuid": "embed-uuid-1"}]


def test_list_superset_dashboards_merges_missing_allowed_domains(monkeypatch):
    # Embedding already enabled but with a stale/wrong allowed_domains (e.g.
    # left over from manual setup) — our origin gets merged in via PUT
    # instead of silently failing to embed, and the existing domain survives.
    monkeypatch.setattr(superset_routes, "get_superset_admin_token", lambda: "fake-token")
    monkeypatch.setattr(superset_routes.settings, "cors_origins", "http://localhost:5173")

    def fake_get(url, **kwargs):
        if url.endswith("/api/v1/dashboard/"):
            return _dashboard_list_response([
                {"id": 4, "dashboard_title": "Retail Sales Overview", "uuid": "regular-uuid-4"},
            ])
        if url.endswith("/api/v1/dashboard/4/embedded"):
            return _FakeResponse(200, {"result": {
                "uuid": "embed-uuid-4", "allowed_domains": ["http://localhost:8000"],
            }})
        raise AssertionError(f"unexpected GET {url}")

    put_calls = {}

    def fake_put(url, **kwargs):
        assert url.endswith("/api/v1/dashboard/4/embedded")
        put_calls["json"] = kwargs.get("json")
        return _FakeResponse(200, {"result": {"uuid": "embed-uuid-4-updated"}})

    monkeypatch.setattr(superset_routes.requests, "get", fake_get)
    monkeypatch.setattr(superset_routes.requests, "put", fake_put)

    results = superset_routes.list_superset_dashboards()

    assert results[0]["uuid"] == "embed-uuid-4-updated"
    assert put_calls["json"] == {"allowed_domains": ["http://localhost:5173", "http://localhost:8000"]}


def test_list_superset_dashboards_auto_enables_embedding_when_missing(monkeypatch):
    monkeypatch.setattr(superset_routes, "get_superset_admin_token", lambda: "fake-token")
    monkeypatch.setattr(superset_routes.settings, "cors_origins", "http://localhost:5173")

    def fake_get(url, **kwargs):
        if url.endswith("/api/v1/dashboard/"):
            return _dashboard_list_response([
                {"id": 4, "dashboard_title": "Retail Sales Overview", "uuid": "regular-uuid-4"},
            ])
        if url.endswith("/api/v1/dashboard/4/embedded"):
            return _FakeResponse(404)
        raise AssertionError(f"unexpected GET {url}")

    posted = {}

    def fake_post(url, **kwargs):
        assert url.endswith("/api/v1/dashboard/4/embedded")
        posted["json"] = kwargs.get("json")
        return _FakeResponse(200, {"result": {"uuid": "embed-uuid-4"}})

    monkeypatch.setattr(superset_routes.requests, "get", fake_get)
    monkeypatch.setattr(superset_routes.requests, "post", fake_post)

    results = superset_routes.list_superset_dashboards()

    assert results[0]["uuid"] == "embed-uuid-4"
    assert posted["json"] == {"allowed_domains": ["http://localhost:5173"]}


def test_list_superset_dashboards_keeps_original_uuid_when_resolution_fails(monkeypatch):
    monkeypatch.setattr(superset_routes, "get_superset_admin_token", lambda: "fake-token")

    def fake_get(url, **kwargs):
        if url.endswith("/api/v1/dashboard/"):
            return _dashboard_list_response([
                {"id": 7, "dashboard_title": "Broken", "uuid": "regular-uuid-7"},
            ])
        if url.endswith("/api/v1/dashboard/7/embedded"):
            return _FakeResponse(404)
        raise AssertionError(f"unexpected GET {url}")

    def fake_post(url, **kwargs):
        return _FakeResponse(500)

    monkeypatch.setattr(superset_routes.requests, "get", fake_get)
    monkeypatch.setattr(superset_routes.requests, "post", fake_post)

    results = superset_routes.list_superset_dashboards()

    # Resolution failed entirely — original (wrong-for-embedding, but not
    # fabricated) uuid is left untouched rather than crashing the whole list.
    assert results[0]["uuid"] == "regular-uuid-7"
