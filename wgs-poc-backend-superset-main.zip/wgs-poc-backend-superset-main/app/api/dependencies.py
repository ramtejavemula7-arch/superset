from uuid import UUID

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import get_db
from app.models.user import User
from app.schemas.role import AccessLevel, Module
from app.services.role_service import RoleService

bearer_scheme = HTTPBearer()
_role_service = RoleService()
_LEVEL_RANK = {AccessLevel.NONE: 0, AccessLevel.READ: 1, AccessLevel.EDIT: 2}


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
    db: Session = Depends(get_db),
) -> User:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )

    token = credentials.credentials

    try:
        payload = jwt.decode(token, settings.secret_key, algorithms=[settings.algorithm])
        user_id = payload.get("sub")
        if user_id is None:
            raise credentials_exception
        user_uuid = UUID(user_id)
    except (JWTError, ValueError):
        raise credentials_exception

    user = db.query(User).filter(User.id == user_uuid).first()
    if user is None or not user.is_active or user.is_deleted:
        raise credentials_exception

    return user


def require_permission(module: Module, min_level: AccessLevel):
    """Dependency factory: the current user's role must have at least
    `min_level` access to `module` (per the role_permissions table). Admin
    roles have no real permission rows (see migration
    009_seed_admin_role_permissions.py — "admin access is now computed in
    code") — RoleService.get_permissions() already synthesizes EDIT for
    every module in that case, so no separate admin bypass is needed here.
    """

    def dependency(current_user: User = Depends(get_current_user)) -> User:
        if not current_user.role:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"No role assigned; cannot access {module.value}",
            )
        perms = _role_service.get_permissions(current_user.role)
        level = next((p.access_level for p in perms if p.module == module), AccessLevel.NONE)
        if _LEVEL_RANK[level] < _LEVEL_RANK[min_level]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Insufficient permissions for {module.value} (requires {min_level.value})",
            )
        return current_user

    return dependency