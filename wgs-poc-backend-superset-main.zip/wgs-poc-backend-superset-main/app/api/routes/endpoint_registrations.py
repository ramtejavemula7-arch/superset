from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.dependencies import require_permission
from app.core.database import get_db
from app.core.endpoints import EndpointRegistrationRoutes
from app.models.user import User
from app.schemas.role import AccessLevel, Module
from app.schemas.endpoint_registration import (
    EndpointRegistrationCreate,
    EndpointRegistrationRead,
    EndpointRegistrationTestDraft,
    EndpointRegistrationUpdate,
    EndpointStatusUpdate,
    TestConnectionResult,
)
from app.services.endpoint_registration_service import EndpointRegistrationService
from app.services.endpoint_test_connection_service import EndpointTestConnectionService

router = APIRouter(prefix=EndpointRegistrationRoutes.PREFIX, tags=["endpoint-registrations"])
service = EndpointRegistrationService()
test_connection_service = EndpointTestConnectionService(service)


@router.get(EndpointRegistrationRoutes.LIST_CREATE, response_model=list[EndpointRegistrationRead])
def list_endpoint_registrations(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permission(Module.API_ENDPOINTS, AccessLevel.READ)),
):
    return service.get_all(db)


@router.post(
    EndpointRegistrationRoutes.LIST_CREATE,
    response_model=EndpointRegistrationRead,
    status_code=status.HTTP_201_CREATED,
)
def create_endpoint_registration(
    payload: EndpointRegistrationCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permission(Module.API_ENDPOINTS, AccessLevel.EDIT)),
):
    if service.get_by_name(db, payload.name):
        raise HTTPException(status_code=400, detail="Endpoint registration already exists")
    return service.create(db, payload)


# NOTE: this literal route must be registered BEFORE the "/{endpoint_registration_id}"
# routes below — otherwise "POST /test-connection" would be swallowed by the
# "/{endpoint_registration_id}" pattern (matching "test-connection" as the id)
# and 422 on int conversion instead of reaching this handler.
@router.post(EndpointRegistrationRoutes.TEST_CONNECTION_DRAFT, response_model=TestConnectionResult)
def test_draft_endpoint_registration(
    payload: EndpointRegistrationTestDraft,
    current_user: User = Depends(require_permission(Module.API_ENDPOINTS, AccessLevel.EDIT)),
):
    return test_connection_service.test_draft(payload)


@router.get(EndpointRegistrationRoutes.BY_ID, response_model=EndpointRegistrationRead)
def get_endpoint_registration(
    endpoint_registration_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permission(Module.API_ENDPOINTS, AccessLevel.READ)),
):
    endpoint = service.get_by_id(db, endpoint_registration_id)
    if not endpoint:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Endpoint registration not found")
    return endpoint


@router.put(EndpointRegistrationRoutes.BY_ID, response_model=EndpointRegistrationRead)
def update_endpoint_registration(
    endpoint_registration_id: int,
    payload: EndpointRegistrationUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permission(Module.API_ENDPOINTS, AccessLevel.EDIT)),
):
    if payload.name:
        duplicate = service.get_by_name(db, payload.name)
        if duplicate and duplicate.id != endpoint_registration_id:
            raise HTTPException(status_code=400, detail="Endpoint registration already exists")

    endpoint = service.update(db, endpoint_registration_id, payload)
    if not endpoint:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Endpoint registration not found")
    return endpoint


@router.delete(EndpointRegistrationRoutes.BY_ID, status_code=status.HTTP_204_NO_CONTENT)
def delete_endpoint_registration(
    endpoint_registration_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permission(Module.API_ENDPOINTS, AccessLevel.EDIT)),
):
    deleted = service.delete(db, endpoint_registration_id)
    if not deleted:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Endpoint registration not found")
    return None


@router.patch(EndpointRegistrationRoutes.STATUS, response_model=EndpointRegistrationRead)
def set_endpoint_registration_status(
    endpoint_registration_id: int,
    payload: EndpointStatusUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permission(Module.API_ENDPOINTS, AccessLevel.EDIT)),
):
    endpoint = service.set_status(db, endpoint_registration_id, payload.status)
    if not endpoint:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Endpoint registration not found")
    return endpoint


@router.post(EndpointRegistrationRoutes.TEST_CONNECTION_SAVED, response_model=TestConnectionResult)
def test_saved_endpoint_registration(
    endpoint_registration_id: int,
    db: Session = Depends(get_db),
    # READ, not EDIT — this is also what Transaction Search calls to fetch
    # live preview data from an already-registered endpoint, which is a
    # read/"use this data source" action from that page's perspective, not
    # an admin action on the registration itself (unlike the draft variant
    # above, which really is part of building/editing a registration).
    current_user: User = Depends(require_permission(Module.API_ENDPOINTS, AccessLevel.READ)),
):
    endpoint = service.get_by_id(db, endpoint_registration_id)
    if not endpoint:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Endpoint registration not found")
    return test_connection_service.test_saved(endpoint)
