from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.dependencies import require_permission
from app.core.database import get_db
from app.core.endpoints import ScheduledReportRoutes
from app.core.scheduler import remove_job, sync_job
from app.models.user import User
from app.schemas.role import AccessLevel, Module
from app.schemas.scheduled_report import ScheduledReportCreate, ScheduledReportRead, ScheduledReportUpdate
from app.services.scheduled_report_service import ScheduledReportService

router = APIRouter(prefix=ScheduledReportRoutes.PREFIX, tags=["scheduled-reports"])
service = ScheduledReportService()

_reports_read = Depends(require_permission(Module.REPORTS, AccessLevel.READ))
_reports_edit = Depends(require_permission(Module.REPORTS, AccessLevel.EDIT))


@router.get(ScheduledReportRoutes.LIST_CREATE, response_model=list[ScheduledReportRead])
def list_schedules(db: Session = Depends(get_db), current_user: User = _reports_read):
    return service.get_all(db)


@router.post(ScheduledReportRoutes.LIST_CREATE, response_model=ScheduledReportRead, status_code=status.HTTP_201_CREATED)
def create_schedule(payload: ScheduledReportCreate, db: Session = Depends(get_db), current_user: User = _reports_edit):
    schedule = service.create(db, payload)
    sync_job(schedule)
    return schedule


@router.get(ScheduledReportRoutes.BY_ID, response_model=ScheduledReportRead)
def get_schedule(schedule_id: int, db: Session = Depends(get_db), current_user: User = _reports_read):
    schedule = service.get_by_id(db, schedule_id)
    if not schedule:
        raise HTTPException(status_code=404, detail="Scheduled report not found")
    return schedule


@router.put(ScheduledReportRoutes.BY_ID, response_model=ScheduledReportRead)
def update_schedule(
    schedule_id: int, payload: ScheduledReportUpdate, db: Session = Depends(get_db), current_user: User = _reports_edit
):
    schedule = service.update(db, schedule_id, payload)
    if not schedule:
        raise HTTPException(status_code=404, detail="Scheduled report not found")
    sync_job(schedule)
    return schedule


@router.delete(ScheduledReportRoutes.BY_ID, status_code=status.HTTP_204_NO_CONTENT)
def delete_schedule(schedule_id: int, db: Session = Depends(get_db), current_user: User = _reports_edit):
    deleted = service.delete(db, schedule_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Scheduled report not found")
    remove_job(schedule_id)
    return None


@router.post(ScheduledReportRoutes.SEND_NOW, response_model=ScheduledReportRead)
def send_schedule_now(schedule_id: int, db: Session = Depends(get_db), current_user: User = _reports_edit):
    """Manually trigger a scheduled report immediately — for testing without waiting for the daily run."""
    schedule = service.get_by_id(db, schedule_id)
    if not schedule:
        raise HTTPException(status_code=404, detail="Scheduled report not found")
    service.send_report(db, schedule)
    return schedule
