import logging
import re
import threading
from typing import Any, Literal
from uuid import uuid4

import requests
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel, field_validator, model_validator
from sqlalchemy.orm import Session

from app.api.dependencies import require_permission
from app.core.config import settings
from app.core.database import get_db
from app.core.endpoints import SupersetRoutes
from app.core.export_jobs import (
    cleanup_old_jobs, complete_job, create_job, fail_job, get_job, pop_job,
)
from app.models.superset_ids import SupersetEmbed
from app.models.user import User
from app.schemas.role import AccessLevel, Module
from app.services.template_service import TemplateService, expand_dimension_column

logger = logging.getLogger(__name__)

router = APIRouter(prefix=SupersetRoutes.PREFIX, tags=["superset"])
_svc = TemplateService()

# Reused across the many read-only endpoints below — all of Superset's
# dashboard/dataset/query/export surface is gated by the single "dashboard"
# module (it also backs the Transaction Search page, which has no dedicated
# backend route of its own — both share these same generic endpoints).
_dashboard_read = Depends(require_permission(Module.DASHBOARD, AccessLevel.READ))
_dashboard_edit = Depends(require_permission(Module.DASHBOARD, AccessLevel.EDIT))


class SupersetEmbedPayload(BaseModel):
    title: str
    dashboard_uuid: str
    superset_dashboard_id: int | None = None  # numeric ID visible in Superset URL
    guest_id: str | None = None
    # BigQuery table this dashboard's chat questions should be scoped to.
    # Falls back to the global BIGQUERY_DATASET/BIGQUERY_TABLE settings when unset.
    bigquery_dataset: str | None = None
    bigquery_table: str | None = None


def get_superset_admin_token() -> str:
    """Return a cached Superset admin token (delegates to TemplateService for token caching)."""
    base = settings.superset_base.rstrip("/")
    return TemplateService._superset_login(base)


def _fetch_superset_csrf_token(base: str, access_token: str) -> tuple[str, requests.Session]:
    """Fetch a CSRF token, returning it alongside the session that holds its matching cookie.

    Superset's guest_token endpoint (unlike login/chart-data) enforces CSRF
    protection, so the token and its session cookie must both accompany the
    follow-up POST.
    """
    session = requests.Session()
    resp = session.get(
        f"{base}/api/v1/security/csrf_token/",
        headers={"Authorization": f"Bearer {access_token}"},
        verify=False,
        timeout=10,
    )
    resp.raise_for_status()
    return resp.json()["result"], session


def create_superset_guest_token(dashboard_uuid: str, guest_id: str | None = None) -> str:
    base = settings.superset_base.rstrip("/")
    access_token = get_superset_admin_token()

    try:
        csrf_token, session = _fetch_superset_csrf_token(base, access_token)
        guest_resp = session.post(
            f"{base}/api/v1/security/guest_token/",
            verify=False,
            json={
                "resources": [
                    {
                        "type": "dashboard",
                        "id": dashboard_uuid,
                    }
                ],
                "rls": [],
                "user": {
                    "username": guest_id or "guest",
                    "first_name": "Guest",
                    "last_name": "User",
                },
            },
            headers={
                "Authorization": f"Bearer {access_token}",
                "Content-Type": "application/json",
                "X-CSRFToken": csrf_token,
                "Referer": base,
            },
            timeout=20,
        )

        if not guest_resp.ok:
            try:
                error_detail = guest_resp.json()
            except ValueError:
                error_detail = guest_resp.text
            raise HTTPException(
                status_code=502,
                detail=f"Superset guest_token request failed ({guest_resp.status_code}): {error_detail}",
            )

        guest_token = guest_resp.json().get("token")
        if not guest_token:
            raise HTTPException(status_code=502, detail="Superset guest token missing from response")

        return guest_token

    except requests.RequestException as exc:
        raise HTTPException(status_code=502, detail=f"Superset request failed: {exc}") from exc


def _resolve_embed_uuid(base: str, token: str, dashboard_id: int) -> str | None:
    """Return this dashboard's EMBED-specific uuid — the id Superset's
    `/embedded/<uuid>` iframe route and guest tokens actually require. This is
    a DIFFERENT uuid from the dashboard's own `uuid` field returned by
    `/api/v1/dashboard/` (that one only identifies the dashboard for regular
    API/export calls); mixing the two up 404s the embedded view.

    Also keeps `allowed_domains` in sync with this app's own frontend origins
    (`settings.cors_origins_list`) — Superset's embedded SDK rejects the
    iframe with a 403 if the embedding page's origin isn't in that list.
    Enables embedding from scratch if it isn't configured yet (404); if it's
    already configured but missing one of our origins (e.g. left over from a
    manual/stale setup), merges ours in via PUT rather than overwriting —
    any other origin already allowed for this dashboard is preserved."""
    headers = {"Authorization": f"Bearer {token}"}
    required_domains = set(settings.cors_origins_list)
    resp = requests.get(f"{base}/api/v1/dashboard/{dashboard_id}/embedded",
                         headers=headers, timeout=15, verify=False)
    if resp.ok:
        result = resp.json()["result"]
        current_domains = set(result.get("allowed_domains") or [])
        if required_domains.issubset(current_domains):
            return result["uuid"]
        put_resp = requests.put(
            f"{base}/api/v1/dashboard/{dashboard_id}/embedded",
            headers={**headers, "Content-Type": "application/json"},
            json={"allowed_domains": sorted(current_domains | required_domains)},
            timeout=15, verify=False,
        )
        if put_resp.ok:
            return put_resp.json()["result"]["uuid"]
        logger.warning(
            "Failed to update allowed_domains for dashboard id=%s (%s) — "
            "embedding may still 403 from this app's origin",
            dashboard_id, put_resp.status_code,
        )
        return result["uuid"]
    if resp.status_code == 404:
        enable_resp = requests.post(
            f"{base}/api/v1/dashboard/{dashboard_id}/embedded",
            headers={**headers, "Content-Type": "application/json"},
            json={"allowed_domains": settings.cors_origins_list},
            timeout=15, verify=False,
        )
        if enable_resp.ok:
            return enable_resp.json()["result"]["uuid"]
    return None


def list_superset_dashboards() -> list[dict]:
    """Fetch every dashboard Superset knows about, paginated, passed through in
    Superset's own native shape (id, dashboard_title, uuid, ...) so the caller
    can feed dashboard_uuid straight into the existing /embed flow — except
    `uuid` is overwritten with each dashboard's EMBED-specific uuid (see
    _resolve_embed_uuid) so it's actually usable for embedding as-is.
    """
    base = settings.superset_base.rstrip("/")
    token = get_superset_admin_token()

    results: list[dict] = []
    page = 0
    page_size = 100

    try:
        while True:
            params = {"q": f"(page:{page},page_size:{page_size})"}
            resp = requests.get(
                f"{base}/api/v1/dashboard/",
                headers={"Authorization": f"Bearer {token}"},
                params=params,
                timeout=20,
                verify=False,
            )
            resp.raise_for_status()
            data = resp.json()

            results.extend(data["result"])

            if len(data["result"]) < page_size:
                break
            page += 1

    except requests.RequestException as exc:
        raise HTTPException(status_code=502, detail=f"Superset dashboard list failed: {exc}") from exc

    for item in results:
        try:
            embed_uuid = _resolve_embed_uuid(base, token, item["id"])
        except requests.RequestException:
            embed_uuid = None
        if embed_uuid:
            item["uuid"] = embed_uuid
        else:
            logger.warning(
                "Could not resolve/enable embed uuid for dashboard id=%s (%r) — "
                "embedding this dashboard will 404 until enabled in Superset directly",
                item.get("id"), item.get("dashboard_title"),
            )

    return results


def list_superset_datasets() -> list[dict]:
    """Fetch all datasets Superset exposes, paginated."""
    base = settings.superset_base.rstrip("/")
    token = get_superset_admin_token()

    results = []
    page = 0
    page_size = 100

    try:
        while True:
            params = {"q": f"(page:{page},page_size:{page_size})"}
            resp = requests.get(
                f"{base}/api/v1/dataset/",
                headers={"Authorization": f"Bearer {token}"},
                params=params,
                timeout=20,
                verify=False,
            )
            resp.raise_for_status()
            data = resp.json()

            for item in data["result"]:
                results.append({
                    "id": item["id"],
                    "table_name": item["table_name"],
                    "schema": item.get("schema"),
                    "database_name": item.get("database", {}).get("database_name"),
                })

            if len(data["result"]) < page_size:
                break
            page += 1

    except requests.RequestException as exc:
        raise HTTPException(status_code=502, detail=f"Superset dataset list failed: {exc}") from exc

    return results


def get_superset_dataset_columns(dataset_id: int) -> list[dict]:
    """Fetch column metadata for a single dataset."""
    base = settings.superset_base.rstrip("/")
    token = get_superset_admin_token()

    try:
        resp = requests.get(
            f"{base}/api/v1/dataset/{dataset_id}",
            headers={"Authorization": f"Bearer {token}"},
            timeout=20,
            verify=False,
        )
        resp.raise_for_status()
    except requests.RequestException as exc:
        raise HTTPException(status_code=502, detail=f"Superset dataset detail failed: {exc}") from exc

    result = resp.json()["result"]

    return [
        {
            "column_name": col["column_name"],
            "verbose_name": col.get("verbose_name") or col["column_name"],
            "type": col.get("type"),
            "is_dttm": col.get("is_dttm", False),
            "groupby": col.get("groupby", True),
            "filterable": col.get("filterable", True),
        }
        for col in result.get("columns", [])
    ]


@router.post(SupersetRoutes.EMBED)
def save_superset_embed(
    payload: SupersetEmbedPayload, db: Session = Depends(get_db), current_user: User = _dashboard_edit
):
    base = settings.superset_base.rstrip("/")
    embed_url = f"{base}/embedded/{payload.dashboard_uuid}"

    existing = (
        db.query(SupersetEmbed)
        .filter(SupersetEmbed.dashboard_uuid == payload.dashboard_uuid)
        .first()
    )

    if existing:
        existing.title = payload.title
        existing.embed_url = embed_url
        if payload.superset_dashboard_id is not None:
            existing.superset_dashboard_id = payload.superset_dashboard_id
        if payload.bigquery_dataset is not None:
            existing.bigquery_dataset = payload.bigquery_dataset
        if payload.bigquery_table is not None:
            existing.bigquery_table = payload.bigquery_table
        db.commit()
        db.refresh(existing)
        record = existing
    else:
        record = SupersetEmbed(
            title=payload.title,
            dashboard_uuid=payload.dashboard_uuid,
            superset_dashboard_id=payload.superset_dashboard_id,
            embed_url=embed_url,
            bigquery_dataset=payload.bigquery_dataset,
            bigquery_table=payload.bigquery_table,
        )
        db.add(record)
        db.commit()
        db.refresh(record)

    guest_token = create_superset_guest_token(
        dashboard_uuid=payload.dashboard_uuid,
        guest_id=payload.guest_id,
    )

    return {
        "id": record.id,
        "dashboard_uuid": record.dashboard_uuid,
        "superset_dashboard_id": record.superset_dashboard_id,
        "embed_url": record.embed_url,
        "bigquery_dataset": record.bigquery_dataset,
        "bigquery_table": record.bigquery_table,
        "guest_token": guest_token,
    }


@router.get(SupersetRoutes.EMBED)
def get_saved_superset_embeds(db: Session = Depends(get_db), current_user: User = _dashboard_read):
    records = db.query(SupersetEmbed).order_by(SupersetEmbed.created_at.desc()).all()

    results = []
    for record in records:
        try:
            guest_token = create_superset_guest_token(record.dashboard_uuid)
        except HTTPException as exc:
            logger.warning(
                "Guest token failed for dashboard_uuid=%s: %s",
                record.dashboard_uuid, exc.detail,
            )
            guest_token = None
        results.append({
            "id": record.id,
            "title": record.title,
            "dashboard_uuid": record.dashboard_uuid,
            "superset_dashboard_id": record.superset_dashboard_id,
            "embed_url": record.embed_url,
            "bigquery_dataset": record.bigquery_dataset,
            "bigquery_table": record.bigquery_table,
            "guest_token": guest_token,
        })

    return results


@router.get(SupersetRoutes.EMBED_BY_UUID)
def get_saved_superset_embed_with_token(
    dashboard_uuid: str,
    guest_id: str | None = None,
    db: Session = Depends(get_db),
    current_user: User = _dashboard_read,
):
    record = (
        db.query(SupersetEmbed)
        .filter(SupersetEmbed.dashboard_uuid == dashboard_uuid)
        .first()
    )

    if not record:
        raise HTTPException(status_code=404, detail="Dashboard UUID not found")

    guest_token = create_superset_guest_token(
        dashboard_uuid=dashboard_uuid,
        guest_id=guest_id,
    )

    return {
        "id": record.id,
        "dashboard_uuid": record.dashboard_uuid,
        "superset_dashboard_id": record.superset_dashboard_id,
        "embed_url": record.embed_url,
        "bigquery_dataset": record.bigquery_dataset,
        "bigquery_table": record.bigquery_table,
        "guest_token": guest_token,
    }


@router.get(SupersetRoutes.DASHBOARDS)
def get_dashboards(current_user: User = _dashboard_read):
    """List every dashboard that exists in Superset, so an admin can pick
    one to embed without needing to know its UUID upfront.
    """
    return {"result": list_superset_dashboards()}


@router.get(SupersetRoutes.DATASETS)
def get_datasets(current_user: User = _dashboard_read):
    return list_superset_datasets()


@router.get(SupersetRoutes.DATASET_COLUMNS)
def get_dataset_columns(dataset_id: int, current_user: User = _dashboard_read):
    return get_superset_dataset_columns(dataset_id)



def get_superset_column_data(
    dataset_id: int,
    column_name: str,
    row_limit: int = 100,
    row_offset: int = 0,
    sort_by: str | None = None,
    sort_desc: bool = False,
) -> list[dict]:
    """Fetch distinct values (with counts) for a single column on a dataset."""
    base = settings.superset_base.rstrip("/")
    token = get_superset_admin_token()

    # Only allow sorting by the grouped column itself or "count".
    # Any other sort_by would reference a column not in the query and fail on BigQuery.
    valid_sort_by = {column_name, "count"}
    effective_sort = sort_by if sort_by in valid_sort_by else "count"
    orderby = [[effective_sort, not sort_desc]]

    query_payload = {
        "datasource": {"id": dataset_id, "type": "table"},
        "queries": [
            {
                "columns": [column_name],
                "metrics": ["count"],
                "groupby": [column_name],
                "row_limit": row_limit,
                "row_offset": row_offset,
                "orderby": orderby,
            }
        ],
        "result_format": "json",
        "result_type": "full",
    }

    try:
        resp = requests.post(
            f"{base}/api/v1/chart/data",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            json=query_payload,
            timeout=30,
            verify=False,
        )

        if not resp.ok:
            try:
                error_detail = resp.json()
            except ValueError:
                error_detail = resp.text
            raise HTTPException(
                status_code=502,
                detail=f"Superset chart/data request failed ({resp.status_code}): {error_detail}",
            )

    except requests.RequestException as exc:
        raise HTTPException(status_code=502, detail=f"Superset chart/data request failed: {exc}") from exc

    data = resp.json()
    try:
        rows = data["result"][0]["data"]
    except (KeyError, IndexError):
        rows = []

    return TemplateService._convert_rows(rows)


@router.get(SupersetRoutes.DATASET_COLUMN_DATA)
def get_dataset_column_data(
    dataset_id: int,
    column_name: str,
    row_limit: int = 100,
    row_offset: int = 0,
    sort_by: str | None = None,
    sort_desc: bool = False,
    current_user: User = _dashboard_read,
):
    return get_superset_column_data(dataset_id, column_name, row_limit, row_offset, sort_by, sort_desc)


class BatchColumnsRequest(BaseModel):
    columns: list[str]
    page: int = 1
    page_size: int = 100
    sort_desc: bool = False


@router.post(SupersetRoutes.DATASET_COLUMNS_BATCH)
def get_batch_columns_data(dataset_id: int, payload: BatchColumnsRequest, current_user: User = _dashboard_read):
    """Fetch distinct values + counts for multiple columns in a single request.
    Returns a dict keyed by column name.
    """
    row_offset = (payload.page - 1) * payload.page_size
    result = {}
    for column_name in payload.columns:
        result[column_name] = get_superset_column_data(
            dataset_id=dataset_id,
            column_name=column_name,
            row_limit=payload.page_size,
            row_offset=row_offset,
            sort_by=column_name,
            sort_desc=payload.sort_desc,
        )
    return result




def get_superset_dataset_preview(dataset_id: int, row_limit: int = 100) -> dict:
    """Fetch a raw row-level data preview for a dataset, across all its columns."""
    base = settings.superset_base.rstrip("/")
    token = get_superset_admin_token()

    # Reuse existing helper to know which columns exist
    columns = get_superset_dataset_columns(dataset_id)
    column_names = [col["column_name"] for col in columns]

    query_payload = {
        "datasource": {"id": dataset_id, "type": "table"},
        "queries": [
            {
                "columns": column_names,
                "row_limit": row_limit,
            }
        ],
        "result_format": "json",
        "result_type": "full",
    }

    try:
        resp = requests.post(
            f"{base}/api/v1/chart/data",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            json=query_payload,
            timeout=30,
            verify=False,
        )

        if not resp.ok:
            try:
                error_detail = resp.json()
            except ValueError:
                error_detail = resp.text
            raise HTTPException(
                status_code=502,
                detail=f"Superset chart/data request failed ({resp.status_code}): {error_detail}",
            )

    except requests.RequestException as exc:
        raise HTTPException(status_code=502, detail=f"Superset chart/data request failed: {exc}") from exc

    data = resp.json()
    try:
        result = data["result"][0]
        rows = result["data"]
        colnames = result.get("colnames", column_names)
    except (KeyError, IndexError):
        rows = []
        colnames = column_names

    return {
        "columns": colnames,
        "rows": rows,
    }



class ColumnFilter(BaseModel):
    col: str
    op: Literal["==", "!=", ">", "<", ">=", "<=", "IN", "NOT IN", "LIKE", "IS NULL", "IS NOT NULL", "BETWEEN"]
    val: Any | None = None

    @field_validator("op", mode="before")
    @classmethod
    def _normalize_op(cls, v):
        # "EQ" is a common symbolic alias for "==" — accept it rather than 422ing
        return {"EQ": "=="}.get(v, v)

    @model_validator(mode="after")
    def _check_between_val(self):
        if self.op == "BETWEEN":
            if not isinstance(self.val, (list, tuple)) or len(self.val) != 2:
                raise ValueError('"val" must be a 2-item [start, end] list when op is "BETWEEN"')
        return self


class DatasetQueryPayload(BaseModel):
    columns: list[str] | None = None       # None = all columns
    filters: list[ColumnFilter] = []
    sort_by: str | None = None
    sort_desc: bool = False
    row_limit: int = 100
    row_offset: int = 0


def _get_total_row_count(dataset_id: int, filters: list[dict]) -> int:
    """Count rows matching `filters` across the whole table, ignoring row_limit/row_offset."""
    base = settings.superset_base.rstrip("/")
    token = get_superset_admin_token()

    query_payload = {
        "datasource": {"id": dataset_id, "type": "table"},
        "queries": [{"metrics": ["count"], "filters": filters, "row_limit": 1}],
        "result_format": "json",
        "result_type": "full",
    }

    try:
        resp = requests.post(
            f"{base}/api/v1/chart/data",
            headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
            json=query_payload,
            timeout=30,
            verify=False,
        )
        if not resp.ok:
            logger.warning("Total count query failed (%s): %s", resp.status_code, resp.text)
            return 0
        data = resp.json()
        return int(data["result"][0]["data"][0]["count"])
    except (requests.RequestException, KeyError, IndexError, ValueError, TypeError) as exc:
        logger.warning("Total count query failed: %s", exc)
        return 0


def query_superset_dataset(dataset_id: int, payload: DatasetQueryPayload) -> dict:
    """Fetch filtered, sorted, paginated row-level data for a dataset."""
    base = settings.superset_base.rstrip("/")
    token = get_superset_admin_token()

    columns = payload.columns
    if not columns:
        meta = get_superset_dataset_columns(dataset_id)
        columns = [col["column_name"] for col in meta]

    # Superset's adhoc filters have no native BETWEEN operator — expand it into
    # two AND-ed filters (>= start, <= end) on the same column instead.
    filters: list[dict[str, Any]] = []
    for f in payload.filters:
        if f.op == "BETWEEN":
            start, end = f.val
            filters.append({"col": f.col, "op": ">=", "val": start})
            filters.append({"col": f.col, "op": "<=", "val": end})
        else:
            filters.append({"col": f.col, "op": f.op, **({} if f.val is None else {"val": f.val})})

    query: dict[str, Any] = {
        "columns": columns,
        "filters": filters,
        "row_limit": payload.row_limit,
        "row_offset": payload.row_offset,
    }

    if payload.sort_by:
        query["orderby"] = [[payload.sort_by, not payload.sort_desc]]

    query_payload = {
        "datasource": {"id": dataset_id, "type": "table"},
        "queries": [query],
        "result_format": "json",
        "result_type": "full",
    }

    try:
        resp = requests.post(
            f"{base}/api/v1/chart/data",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            json=query_payload,
            timeout=30,
            verify=False,
        )

        if not resp.ok:
            try:
                error_detail = resp.json()
            except ValueError:
                error_detail = resp.text
            raise HTTPException(
                status_code=502,
                detail=f"Superset chart/data request failed ({resp.status_code}): {error_detail}",
            )

    except requests.RequestException as exc:
        raise HTTPException(status_code=502, detail=f"Superset chart/data request failed: {exc}") from exc

    data = resp.json()
    try:
        result = data["result"][0]
        rows = TemplateService._convert_rows(result["data"])
        colnames = result.get("colnames", columns)
        rowcount = result.get("rowcount", len(rows))
    except (KeyError, IndexError):
        rows, colnames, rowcount = [], columns, 0

    total = _get_total_row_count(dataset_id, filters)

    return {
        "columns": colnames,
        "rows": rows,
        "rowcount": rowcount,
        "total": total,
        "row_offset": payload.row_offset,
        "row_limit": payload.row_limit,
    }


@router.post(SupersetRoutes.DATASET_QUERY)
def query_dataset(dataset_id: int, payload: DatasetQueryPayload, current_user: User = _dashboard_read):
    return query_superset_dataset(dataset_id, payload)


# ------------------------------------------------------------------ #
# Metrics templates — grouped/aggregated queries (dimensions + metrics) #
# ------------------------------------------------------------------ #

class MetricQuerySpec(BaseModel):
    field: str  # or the sentinel "__order_count__" for COUNT(*) with no real column
    aggregation: Literal["SUM", "AVG", "MIN", "MAX", "COUNT"]
    label: str


class SortQuerySpec(BaseModel):
    field: str
    direction: Literal["asc", "desc"]


class MetricsQueryPayload(BaseModel):
    dimensions: list[str] = []
    metrics: list[MetricQuerySpec] = []
    filters: list[ColumnFilter] = []
    sort: SortQuerySpec | None = None
    row_limit: int = 100
    row_offset: int = 0


def _build_superset_metric(spec: MetricQuerySpec) -> dict | str:
    if spec.field == "__order_count__" and spec.aggregation == "COUNT":
        return "count"  # Superset's built-in row-count metric — no real column involved
    return {
        "expressionType": "SIMPLE",
        "column": {"column_name": spec.field},
        "aggregate": spec.aggregation,
        "label": spec.label,
    }


@router.post(SupersetRoutes.DATASET_METRICS_QUERY)
def query_dataset_metrics(dataset_id: int, payload: MetricsQueryPayload, current_user: User = _dashboard_read):
    """Run a grouped/aggregated query for a metrics-type template: GROUP BY
    `dimensions`, computing each entry in `metrics` (SUM/AVG/MIN/MAX/COUNT)."""
    if not payload.metrics:
        raise HTTPException(status_code=400, detail="At least one metric is required")

    base = settings.superset_base.rstrip("/")
    token = get_superset_admin_token()

    # Same BETWEEN-expansion + col/op/val handling as the row-level /query endpoint
    filters: list[dict[str, Any]] = []
    for f in payload.filters:
        if f.op == "BETWEEN":
            start, end = f.val
            filters.append({"col": f.col, "op": ">=", "val": start})
            filters.append({"col": f.col, "op": "<=", "val": end})
        else:
            filters.append({"col": f.col, "op": f.op, **({} if f.val is None else {"val": f.val})})

    metrics = [_build_superset_metric(m) for m in payload.metrics]

    # A dimension named "{column}__year"/"__month"/"__quarter" (e.g.
    # "order_date__year" for a Matrix Report's "Order Year") isn't a real
    # column — expand it into an adhoc SQL column instead of sending it to
    # Superset as a plain groupby string, which would just 400. Rows still
    # come back keyed by the original name, since that's the adhoc column's label.
    expanded_dimensions = [expand_dimension_column(d) for d in payload.dimensions]

    query: dict[str, Any] = {
        "columns": expanded_dimensions,
        "metrics": metrics,
        "groupby": expanded_dimensions,
        "filters": filters,
        "row_limit": payload.row_limit,
        "row_offset": payload.row_offset,
    }

    # A sort field must be one of the dimensions or a metric's own label —
    # anything else references a column not in this query and fails on the DB side.
    # A dimension sort must reuse its EXPANDED adhoc-column form (matching
    # "columns"/"groupby" above) rather than the bare dimension name — ordering
    # by e.g. "order_date__year" as a plain string 400s with "Unknown column
    # used in orderby" since Superset has no real column by that name, only
    # the adhoc SQL one.
    if payload.sort:
        if payload.sort.field in payload.dimensions:
            sort_col = expanded_dimensions[payload.dimensions.index(payload.sort.field)]
            query["orderby"] = [[sort_col, payload.sort.direction == "asc"]]
        elif payload.sort.field in {m.label for m in payload.metrics}:
            query["orderby"] = [[payload.sort.field, payload.sort.direction == "asc"]]

    query_payload = {
        "datasource": {"id": dataset_id, "type": "table"},
        "queries": [query],
        "result_format": "json",
        "result_type": "full",
    }

    try:
        resp = requests.post(
            f"{base}/api/v1/chart/data",
            headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
            json=query_payload,
            timeout=30,
            verify=False,
        )
        if not resp.ok:
            try:
                error_detail = resp.json()
            except ValueError:
                error_detail = resp.text
            raise HTTPException(
                status_code=502,
                detail=f"Superset chart/data failed ({resp.status_code}): {error_detail}",
            )
    except requests.RequestException as exc:
        raise HTTPException(status_code=502, detail=f"Superset request failed: {exc}") from exc

    data = resp.json()
    expected_cols = payload.dimensions + [m.label for m in payload.metrics]
    try:
        result = data["result"][0]
        rows = TemplateService._convert_rows(result["data"])
        colnames = result.get("colnames", expected_cols)
        rowcount = result.get("rowcount", len(rows))
    except (KeyError, IndexError):
        rows, colnames, rowcount = [], expected_cols, 0

    return {
        "columns": colnames,
        "rows": rows,
        "rowcount": rowcount,
        "row_offset": payload.row_offset,
        "row_limit": payload.row_limit,
    }


# ------------------------------------------------------------------ #
# Dashboard data & export                                              #
# ------------------------------------------------------------------ #

@router.get(SupersetRoutes.DASHBOARD_DATA)
def get_dashboard_data(
    dashboard_uuid: str,
    dashboard_id: int | None = None,
    db: Session = Depends(get_db),
    current_user: User = _dashboard_read,
):
    """Return all chart data for a dashboard as JSON (title + per-chart rows).

    Pass `?dashboard_id=<N>` (numeric ID visible in the Superset URL) to skip
    UUID resolution when the admin lacks 'can_read on Dashboard'.
    """
    _prime_dashboard_id_cache(dashboard_uuid, dashboard_id, db)
    title, charts = _svc.get_dashboard_charts_data(dashboard_uuid)
    return {"title": title, "charts": charts}


def _dashboard_filename_stem(dashboard_uuid: str) -> str:
    """Build a safe filename stem from the dashboard's resolved title.

    Call this AFTER _svc.build_dashboard_pdf/build_dashboard_excel has run —
    that call resolves and caches the real dashboard title as a side effect,
    so no extra Superset round-trip is needed here.
    """
    _, title = _svc._dashboard_id_cache.get(dashboard_uuid, (None, f"dashboard_{dashboard_uuid[:8]}"))
    # Content-Disposition filenames are sent as a raw HTTP header value,
    # which must be Latin-1-encodable — a dashboard title with e.g. an
    # em-dash (as pasted from Word/PowerPoint) crashes uvicorn while writing
    # the response headers, AFTER the export already succeeded (reproduced
    # directly: "Card Transactions — Executive Overview" 500s every time on
    # download despite the PDF/Excel/PNG build itself completing fine).
    ascii_title = (title or "").encode("ascii", "ignore").decode("ascii")
    stem = re.sub(r'[<>:"/\\|?*]', "", ascii_title.strip())
    stem = re.sub(r"\s+", "_", stem)
    return stem or f"dashboard_{dashboard_uuid[:8]}"


def _run_dashboard_export(job_id: str, build_fn, dashboard_uuid: str) -> None:
    try:
        content, media_type, filename = build_fn(dashboard_uuid)
        complete_job(job_id, content, media_type, filename)
    except Exception as exc:
        logger.exception("Dashboard export job %s failed", job_id)
        fail_job(job_id, str(exc))


def _prime_dashboard_id_cache(
    dashboard_uuid: str,
    dashboard_id: int | None,
    db: Session,
) -> None:
    """
    Pre-populate TemplateService._dashboard_id_cache from two sources
    (in priority order):
      1. The `dashboard_id` query param provided by the caller.
      2. The `superset_dashboard_id` stored in the SupersetEmbed table.
    If found, future resolution strategies are skipped entirely.
    """
    numeric_id = dashboard_id
    title = "Dashboard"

    if numeric_id is None:
        embed = (
            db.query(SupersetEmbed)
            .filter(SupersetEmbed.dashboard_uuid == dashboard_uuid)
            .first()
        )
        if embed and embed.superset_dashboard_id:
            numeric_id = embed.superset_dashboard_id
            title = embed.title

    if numeric_id and dashboard_uuid not in _svc._dashboard_id_cache:
        _svc._dashboard_id_cache[dashboard_uuid] = (numeric_id, title)
        logger.debug(
            "Pre-populated dashboard cache: %s → id=%d", dashboard_uuid, numeric_id
        )


@router.post(SupersetRoutes.DASHBOARD_EXPORT_PDF_ASYNC, status_code=202)
def start_dashboard_pdf_export(
    dashboard_uuid: str,
    dashboard_id: int | None = None,
    db: Session = Depends(get_db),
    current_user: User = _dashboard_read,
):
    """Start a background PDF export for an embedded dashboard.

    Pass `?dashboard_id=<N>` (numeric ID visible in the Superset URL) to skip
    UUID resolution when the admin lacks 'can_read on Dashboard'.
    """
    _prime_dashboard_id_cache(dashboard_uuid, dashboard_id, db)
    cleanup_old_jobs()
    job_id = uuid4().hex
    create_job(job_id)

    def build(uuid: str):
        pdf_bytes = _svc.build_dashboard_pdf(uuid)
        filename = f"{_dashboard_filename_stem(uuid)}.pdf"
        return pdf_bytes, "application/pdf", filename

    threading.Thread(
        target=_run_dashboard_export, args=(job_id, build, dashboard_uuid), daemon=True
    ).start()
    logger.info("Async dashboard PDF export started: job=%s uuid=%s", job_id, dashboard_uuid)
    return {"job_id": job_id, "status": "pending"}


@router.post(SupersetRoutes.DASHBOARD_EXPORT_EXCEL_ASYNC, status_code=202)
def start_dashboard_excel_export(
    dashboard_uuid: str,
    dashboard_id: int | None = None,
    db: Session = Depends(get_db),
    current_user: User = _dashboard_read,
):
    """Start a background Excel export for an embedded dashboard.

    Pass `?dashboard_id=<N>` (numeric ID visible in the Superset URL) to skip
    UUID resolution when the admin lacks 'can_read on Dashboard'.
    """
    _prime_dashboard_id_cache(dashboard_uuid, dashboard_id, db)
    cleanup_old_jobs()
    job_id = uuid4().hex
    create_job(job_id)

    def build(uuid: str):
        excel_bytes = _svc.build_dashboard_excel(uuid)
        filename = f"{_dashboard_filename_stem(uuid)}.xlsx"
        return (
            excel_bytes,
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            filename,
        )

    threading.Thread(
        target=_run_dashboard_export, args=(job_id, build, dashboard_uuid), daemon=True
    ).start()
    logger.info("Async dashboard Excel export started: job=%s uuid=%s", job_id, dashboard_uuid)
    return {"job_id": job_id, "status": "pending"}


@router.post(SupersetRoutes.DASHBOARD_EXPORT_VISUAL_IMAGE_ASYNC, status_code=202)
def start_dashboard_visual_image_export(
    dashboard_uuid: str,
    dashboard_id: int | None = None,
    db: Session = Depends(get_db),
    current_user: User = _dashboard_read,
):
    """Start a background PNG screenshot export for an embedded dashboard —
    a real rendered image of the dashboard's charts+layout via a headless
    browser we drive ourselves (Playwright), unlike the pdf/excel formats
    which re-render the underlying chart data into our own layout.

    Pass `?dashboard_id=<N>` (numeric ID visible in the Superset URL) to skip
    UUID resolution when the admin lacks 'can_read on Dashboard'.
    """
    _prime_dashboard_id_cache(dashboard_uuid, dashboard_id, db)
    cleanup_old_jobs()
    job_id = uuid4().hex
    create_job(job_id)

    def build(uuid: str):
        png_bytes = _svc.build_dashboard_image(uuid, dashboard_id)
        filename = f"{_dashboard_filename_stem(uuid)}.png"
        return png_bytes, "image/png", filename

    threading.Thread(
        target=_run_dashboard_export, args=(job_id, build, dashboard_uuid), daemon=True
    ).start()
    logger.info("Async dashboard visual-image export started: job=%s uuid=%s", job_id, dashboard_uuid)
    return {"job_id": job_id, "status": "pending"}


@router.get(SupersetRoutes.DASHBOARD_EXPORT_JOB_STATUS)
def get_dashboard_export_status(job_id: str, current_user: User = _dashboard_read):
    """Poll until status is 'done' or 'error'."""
    job = get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    resp = {"job_id": job_id, "status": job.status}
    if job.status == "error":
        resp["error"] = job.error
    return resp


@router.get(SupersetRoutes.DASHBOARD_EXPORT_JOB_DOWNLOAD)
def download_dashboard_export(job_id: str, current_user: User = _dashboard_read):
    """Download the file once the job is done."""
    job = get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    if job.status == "pending":
        raise HTTPException(status_code=400, detail="Export not ready yet")
    if job.status == "error":
        raise HTTPException(status_code=500, detail=job.error)

    content, media_type, filename = job.content, job.media_type, job.filename
    pop_job(job_id)

    return Response(
        content=content,
        media_type=media_type,
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Content-Length": str(len(content)),
        },
    )