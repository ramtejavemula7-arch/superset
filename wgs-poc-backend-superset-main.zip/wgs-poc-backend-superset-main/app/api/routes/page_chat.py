from fastapi import APIRouter, Depends

from app.api.dependencies import get_current_user
from app.core.config import settings
from app.core.endpoints import PageChatRoutes
from app.core.rate_limit import InMemoryRateLimiter
from app.models.user import User
from app.schemas.page_chat import PageChatRequest, PageChatResponse
from app.services.page_chat_service import PageChatService

router = APIRouter(prefix=PageChatRoutes.PREFIX, tags=["page-chat"])
service = PageChatService()
_rate_limiter = InMemoryRateLimiter(max_requests=settings.chat_rate_limit_per_minute, window_seconds=60)


@router.post(PageChatRoutes.ASK, response_model=PageChatResponse)
def ask_page_chat(payload: PageChatRequest, current_user: User = Depends(get_current_user)):
    _rate_limiter.check(str(current_user.id))
    return service.ask(payload.agent_type, payload.page_data, payload.question)
