from datetime import datetime
from sqlalchemy import Column, DateTime, Integer, String, JSON
from app.core.database import Base


class Template(Base):
    __tablename__ = "templates"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False, unique=True, index=True)
    template_type = Column(String, nullable=False, default="transaction")
    # "transaction" | "metrics" (legacy aggregated pivot, new creation disabled — see
    # TemplateService.create/update) | "grouped" (current user-facing "Matrix" template)
    logo_url = Column(String, nullable=True)
    logo_position = Column(String, nullable=False, default="left")
    template_color = Column(String, nullable=True)
    dataset_id = Column(Integer, nullable=False)
    columns = Column(JSON, nullable=False, default=list)
    filters = Column(JSON, nullable=False, default=list)
    total_columns = Column(JSON, nullable=False, default=list)
    column_formats = Column(JSON, nullable=False, default=dict)  # {column_name: currency_code}
    dimensions = Column(JSON, nullable=True)   # metrics templates: group-by columns (row hierarchy);
                                                # grouped templates: row-merge columns, must prefix `columns`
    metrics = Column(JSON, nullable=True)      # metrics templates: [{field, aggregation, label}]
    sort = Column(JSON, nullable=True)         # metrics templates: {field, direction} | null
    column_field = Column(String, nullable=True)               # metrics templates: optional pivot dimension
    column_sort_direction = Column(String, nullable=False, default="asc")  # order of pivoted column headers
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
