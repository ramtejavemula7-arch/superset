from datetime import datetime
from sqlalchemy import Boolean, Column, Date, DateTime, ForeignKey, Integer, JSON, String
from app.core.database import Base


class ScheduledReport(Base):
    __tablename__ = "scheduled_reports"

    id = Column(Integer, primary_key=True, index=True)
    template_id = Column(Integer, ForeignKey("templates.id", ondelete="CASCADE"), nullable=False)
    recipients = Column(JSON, nullable=False, default=list)
    is_active = Column(Boolean, nullable=False, default=True)
    hour = Column(Integer, nullable=False, default=10)
    minute = Column(Integer, nullable=False, default=0)
    frequency = Column(String, nullable=False, default="daily")  # "once" | "daily" | "weekly"
    day_of_week = Column(String, nullable=True)  # "mon".."sun" — used when frequency == "weekly"
    run_date = Column(Date, nullable=True)  # used when frequency == "once"
    last_sent_at = Column(DateTime(timezone=True), nullable=True)
    last_error = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
