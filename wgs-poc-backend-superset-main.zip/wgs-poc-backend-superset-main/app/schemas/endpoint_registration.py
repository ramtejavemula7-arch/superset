from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator

AuthType = Literal["none", "api_key", "basic_auth", "bearer_token"]
HttpMethod = Literal["GET", "POST", "PUT", "PATCH", "DELETE"]


class HeaderParam(BaseModel):
    name: str = Field(..., min_length=1)
    value: str


# ------------------------------------------------------------------ #
# Non-secret auth_config shape per auth_type — the actual secret     #
# value (API key/password/token) never appears in these.             #
# ------------------------------------------------------------------ #

class _NoneAuthConfig(BaseModel):
    pass


class _ApiKeyAuthConfig(BaseModel):
    api_key_name: str = Field(..., min_length=1)
    send_in: Literal["header", "query", "cookie"] = "header"


class _BasicAuthConfig(BaseModel):
    username: str = Field(..., min_length=1)


class _BearerTokenAuthConfig(BaseModel):
    pass


_AUTH_CONFIG_MODELS: dict[str, type[BaseModel]] = {
    "none": _NoneAuthConfig,
    "api_key": _ApiKeyAuthConfig,
    "basic_auth": _BasicAuthConfig,
    "bearer_token": _BearerTokenAuthConfig,
}


def _validate_auth_config(auth_type: str, auth_config: dict[str, Any] | None) -> dict[str, Any]:
    model_cls = _AUTH_CONFIG_MODELS.get(auth_type)
    if model_cls is None:
        raise ValueError(f"Unsupported auth_type: {auth_type!r}")
    return model_cls.model_validate(auth_config or {}).model_dump()


class EndpointRegistrationBase(BaseModel):
    name: str = Field(..., min_length=1)
    description: str | None = None
    base_url: str = Field(..., min_length=1)
    endpoint_path: str | None = None
    http_method: HttpMethod = "GET"
    timeout: int = Field(default=30, gt=0, le=300)
    custom_headers: list[HeaderParam] = Field(default_factory=list)
    query_params: list[HeaderParam] = Field(default_factory=list)
    auth_type: AuthType = "none"
    auth_config: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _check_auth_config_shape(self):
        self.auth_config = _validate_auth_config(self.auth_type, self.auth_config)
        return self


class EndpointRegistrationCreate(EndpointRegistrationBase):
    secret_value: str | None = Field(
        default=None,
        description=(
            "Required when auth_type is not 'none'; ignored for 'none'. "
            "Never persisted as-is — stored in GCP Secret Manager, only a "
            "reference is kept in the database."
        ),
    )

    @model_validator(mode="after")
    def _check_secret_required(self):
        if self.auth_type != "none" and not self.secret_value:
            raise ValueError(f"secret_value is required for auth_type={self.auth_type!r}")
        return self


class EndpointRegistrationUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    base_url: str | None = None
    endpoint_path: str | None = None
    http_method: HttpMethod | None = None
    timeout: int | None = Field(default=None, gt=0, le=300)
    custom_headers: list[HeaderParam] | None = None
    query_params: list[HeaderParam] | None = None
    auth_type: AuthType | None = None
    auth_config: dict[str, Any] | None = None
    secret_value: str | None = Field(
        default=None,
        description="Provide to rotate/replace the stored secret. Omit to leave the existing secret untouched.",
    )

    @model_validator(mode="after")
    def _check_auth_config_shape(self):
        if self.auth_type is not None and self.auth_config is not None:
            self.auth_config = _validate_auth_config(self.auth_type, self.auth_config)
        return self


class EndpointStatusUpdate(BaseModel):
    status: Literal["enabled", "disabled"]


class EndpointRegistrationRead(BaseModel):
    """Never includes secret_reference — the raw GCP Secret Manager resource
    path is internal-only and never returned to API consumers."""
    id: int
    name: str
    description: str | None
    base_url: str
    endpoint_path: str | None
    http_method: str
    timeout: int
    custom_headers: list[HeaderParam]
    query_params: list[HeaderParam]
    status: str
    auth_type: str
    auth_config: dict[str, Any]
    has_secret: bool
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class EndpointRegistrationTestDraft(EndpointRegistrationBase):
    """Full draft config for testing BEFORE the endpoint is saved. The
    secret value (if any) is used only for this one outbound call and is
    never written to the database or Secret Manager."""
    secret_value: str | None = None

    @model_validator(mode="after")
    def _check_secret_required(self):
        if self.auth_type != "none" and not self.secret_value:
            raise ValueError(f"secret_value is required for auth_type={self.auth_type!r}")
        return self


class TestConnectionResult(BaseModel):
    status_code: int | None = None
    elapsed_ms: int
    success: bool
    message: str
    raw_response: str | None = None
