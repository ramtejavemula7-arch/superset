from datetime import date, datetime
from typing import Literal
from pydantic import BaseModel, EmailStr, Field, model_validator

Frequency = Literal["once", "daily", "weekly"]
DayOfWeek = Literal["mon", "tue", "wed", "thu", "fri", "sat", "sun"]


class ScheduledReportBase(BaseModel):
    template_id: int
    recipients: list[EmailStr] = Field(default_factory=list)
    is_active: bool = True
    hour: int = Field(default=10, ge=0, le=23)
    minute: int = Field(default=0, ge=0, le=59)
    frequency: Frequency = "daily"
    day_of_week: DayOfWeek | None = None  # required when frequency == "weekly"
    run_date: date | None = None  # required when frequency == "once"


class ScheduledReportCreate(ScheduledReportBase):
    @model_validator(mode="after")
    def _check_frequency_fields(self):
        if self.frequency == "weekly" and not self.day_of_week:
            raise ValueError("day_of_week is required when frequency is 'weekly'")
        if self.frequency == "once" and not self.run_date:
            raise ValueError("run_date is required when frequency is 'once'")
        return self


class ScheduledReportUpdate(BaseModel):
    template_id: int | None = None
    recipients: list[EmailStr] | None = None
    is_active: bool | None = None
    hour: int | None = Field(default=None, ge=0, le=23)
    minute: int | None = Field(default=None, ge=0, le=59)
    frequency: Frequency | None = None
    day_of_week: DayOfWeek | None = None
    run_date: date | None = None


class ScheduledReportRead(ScheduledReportBase):
    id: int
    last_sent_at: datetime | None = None
    last_error: str | None = None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}
