from typing import Optional
from uuid import UUID

from pydantic import BaseModel, EmailStr


class UserBase(BaseModel):
    username: str
    email: EmailStr
    role_id: Optional[UUID] = None


class UserCreate(UserBase):
    pass


class UserRead(UserBase):
    id: UUID
    is_active: bool

    class Config:
        from_attributes = True


class UserInviteResponse(UserRead):
    activation_url: str