from email.message import EmailMessage
import smtplib

from app.core.config import settings
from app.utils.logger import logger


def send_activation_email(to_email: str, username: str, activation_url: str) -> bool:
    if not settings.smtp_host or not settings.smtp_from_email:
        logger.info("SMTP not configured; activation link for %s: %s", to_email, activation_url)
        return False

    message = EmailMessage()
    message["Subject"] = "Activate your account"
    message["From"] = settings.smtp_from_email
    message["To"] = to_email
    message.set_content(
        f"Hi {username},\n\n"
        f"Use this link to activate your account and set your password:\n{activation_url}\n\n"
        "If you did not expect this email, you can ignore it."
    )

    try:
        with smtplib.SMTP(settings.smtp_host, settings.smtp_port) as smtp:
            if settings.smtp_use_tls:
                smtp.starttls()
            if settings.smtp_username and settings.smtp_password:
                smtp.login(settings.smtp_username, settings.smtp_password)
            smtp.send_message(message)
        return True
    except smtplib.SMTPAuthenticationError:
        logger.exception("SMTP authentication failed for %s. Check tenant/mailbox SMTP AUTH settings.", to_email)
    except smtplib.SMTPException:
        logger.exception("SMTP error while sending activation email to %s", to_email)

    return False


def send_report_email(
    to_email: str,
    subject: str,
    body: str,
    attachments: list[tuple[bytes, str, str, str]],
) -> bool:
    """attachments: list of (content_bytes, filename, maintype, subtype), e.g.
    (pdf_bytes, "report.pdf", "application", "pdf")."""
    if not settings.smtp_host or not settings.smtp_from_email:
        logger.info("SMTP not configured; skipping report email to %s (%s)", to_email, subject)
        return False

    message = EmailMessage()
    message["Subject"] = subject
    message["From"] = settings.smtp_from_email
    message["To"] = to_email
    message.set_content(body)

    for content, filename, maintype, subtype in attachments:
        message.add_attachment(content, maintype=maintype, subtype=subtype, filename=filename)

    try:
        with smtplib.SMTP(settings.smtp_host, settings.smtp_port) as smtp:
            if settings.smtp_use_tls:
                smtp.starttls()
            if settings.smtp_username and settings.smtp_password:
                smtp.login(settings.smtp_username, settings.smtp_password)
            smtp.send_message(message)
        return True
    except smtplib.SMTPAuthenticationError:
        logger.exception("SMTP authentication failed for %s. Check tenant/mailbox SMTP AUTH settings.", to_email)
    except smtplib.SMTPException:
        logger.exception("SMTP error while sending report email to %s", to_email)

    return False
