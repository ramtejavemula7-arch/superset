def build_response(message: str, data=None):
    return {"message": message, "data": data}
