import json
import secrets
import warnings

from pydantic import field_validator
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    app_name: str = "WGS_POC"
    debug: bool = False

    # Database
    database_url: str = "postgresql+psycopg://postgres:password@localhost:5432/WGS_POC"

    # Auth
    secret_key: str = "change-me"
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    activation_token_expire_hours: int = 24

    # CORS — comma-separated list of allowed origins
    cors_origins: str = "http://localhost:5173"

    # Frontend
    frontend_url: str = "http://localhost:5173"

    # SMTP
    smtp_host: str | None = None
    smtp_port: int = 587
    smtp_username: str | None = None
    smtp_password: str | None = None
    smtp_from_email: str | None = None
    smtp_use_tls: bool = True

    # Superset
    superset_base: str = "http://localhost:8088"
    superset_user: str | None = None
    superset_pass: str | None = None
    superset_provider: str = "db"

    # Scheduled reports — each schedule sets its own send time (hour/minute)
    scheduler_enabled: bool = True
    scheduler_timezone: str = "Asia/Kolkata"

    # Google Cloud / Gemini
    google_cloud_project: str = "bilvantis-internal-project"
    google_application_credentials: str | None = None  # path to local service-account JSON key
    # If set, Gemini calls (page-chat, and the Chat Assistant's intent
    # routing/SQL-generation/synthesis) use the plain Gemini Developer API
    # (API key, from https://aistudio.google.com) instead of Vertex AI —
    # bypasses GCP project/IAM/Model-Garden access entirely.
    gemini_api_key: str | None = None
    gemini_chat_timeout_seconds: float = 120.0
    chat_rate_limit_per_minute: int = 10
    # Vertex AI model used for page-chat and the Chat Assistant's intent
    # routing/SQL-generation/synthesis calls. gemini-2.0-flash* was retired
    # 2026-06-01 (404 in every region) — gemini-3.5-flash is the current
    # GA/stable Flash model as of 2026-07. Verify against Model Garden if
    # this ever 404s again; model names get retired on a rolling basis.
    gemini_chat_model: str = "gemini-3.5-flash"
    # us-central1 has the broadest Gemini model availability on Vertex AI —
    # version-pinned models are often NOT deployed to the "global" endpoint.
    gemini_chat_location: str = "us-central1"
    # Published BigQuery Data Agent the Chat Assistant tries FIRST, if
    # configured — falls back to direct Gemini-SQL-generation (see
    # gemini_service.py) when unset or when the Agent call fails. Only used
    # when a question doesn't specify its own agent_name (see the Chat
    # Assistant's per-question agent picker, GET /api/chat/agents).
    gemini_data_agent_location: str | None = None
    gemini_data_agent_id: str | None = None
    # Temporary escape hatch to verify the agent-picker UI end-to-end before
    # a real custom Data Agent is shared with the service account — remove
    # once a real agent shows up normally.
    data_agent_picker_include_samples: bool = False

    # Chat Assistant orchestration — intent routing (SQL/RAG/CONTEXT/CLARIFY)
    # and multi-source synthesis on top of the BQ Data Agent above.
    # RAG is optional: leave rag_corpus_name unset to run SQL/CONTEXT-only
    # (the router will never classify RAG/HYBRID without a corpus configured).
    rag_corpus_name: str | None = None  # Vertex AI RAG Engine corpus resource name
    rag_location: str = "europe-west1"  # us-central1 requires RAG Engine allowlist
    rag_similarity_top_k: int = 5
    rag_relevance_threshold: float = 0.6
    chat_session_context_messages: int = 6  # prior turns kept for CONTEXT/follow-ups

    # Which BigQuery dataset(s) the Chat Assistant can query. Table/column
    # schema is auto-discovered from BigQuery's own INFORMATION_SCHEMA at
    # runtime (see gemini_service.py) — nothing to hand-maintain here as
    # tables/columns change. JSON string:
    # [{"project_id","dataset_id","table_notes":{"table_id":"optional extra
    # business-context note appended to that table's auto-discovered schema"}}]
    bigquery_datasets: str | None = None
    # How long auto-discovered schema is cached before re-querying
    # INFORMATION_SCHEMA (schema changes rarely; avoids a BigQuery round
    # trip on every single chat message).
    bigquery_schema_cache_ttl_seconds: int = 3600

    # How long the Data Agent picker's list (GET /api/chat/agents) is cached
    # before re-listing from GCP. That call fans out to 3 regions
    # (global/us/eu) — without caching, every single Chat Assistant page
    # load pays that full round-trip latency, which is why the picker used
    # to only appear several seconds after the page loaded. Agents are
    # created/published rarely, so a long TTL is safe.
    data_agent_list_cache_ttl_seconds: int = 300

    # Smart HYBRID routing — how many SQL rows (or what RAG top score, via
    # rag_relevance_threshold above) count as a "strong enough" primary
    # result to skip the optional secondary source.
    sql_strong_min_rows: int = 2

    # Synthesis self-critique loop — draft, critique, refine before returning.
    # Off by default: each pass is an extra sequential Gemini call (on top of
    # intent classification + SQL generation), and stacking several of these
    # pushed total chat latency past 30s — long enough to trip the
    # frontend's request timeout. Turn on once base latency is acceptable.
    quality_loop_enabled: bool = False
    quality_loop_max_iterations: int = 2

    # In-memory semantic cache for chat responses and SQL/RAG tool results.
    # Fine for this app's single-uvicorn-worker deployment; would need a
    # shared backend (e.g. Redis) if ever run with multiple workers.
    chat_cache_enabled: bool = True
    chat_cache_ttl_seconds: int = 300
    chat_sql_cache_ttl_seconds: int = 1800
    chat_rag_cache_ttl_seconds: int = 3600

    # Logo/asset uploads — stored in this GCS bucket rather than local disk,
    # which doesn't persist: the VM deploy workflow recreates the backend
    # container (docker rm + docker run) on every push to main, wiping any
    # local uploads/ directory that isn't an explicitly mounted volume.
    gcs_uploads_bucket: str | None = None

    @property
    def rag_enabled(self) -> bool:
        return bool(self.rag_corpus_name)

    @property
    def bigquery_datasets_list(self) -> list[dict]:
        """Parsed `bigquery_datasets` JSON, or [] if unset/invalid."""
        if not self.bigquery_datasets:
            return []
        try:
            parsed = json.loads(self.bigquery_datasets)
            return parsed if isinstance(parsed, list) else []
        except (json.JSONDecodeError, TypeError):
            warnings.warn("BIGQUERY_DATASETS is not valid JSON; ignoring it.", stacklevel=2)
            return []

    @field_validator("secret_key")
    @classmethod
    def validate_secret_key(cls, v: str) -> str:
        if v == "change-me":
            warnings.warn(
                "SECRET_KEY is set to the insecure default 'change-me'. "
                "Set a strong random value via the SECRET_KEY environment variable.",
                stacklevel=2,
            )
        return v

    @property
    def cors_origins_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8",
    }


settings = Settings()
