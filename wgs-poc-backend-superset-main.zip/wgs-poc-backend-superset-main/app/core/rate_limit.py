import threading
import time
from collections import defaultdict, deque

from fastapi import HTTPException


class InMemoryRateLimiter:
    """Sliding-window rate limiter, keyed by an arbitrary string (e.g. user id).

    Per-process only — resets on restart and doesn't coordinate across
    multiple app instances. That's an intentional tradeoff for this app,
    which has no Redis/shared store; fine for a single-instance deployment,
    but swap for a shared store if this ever runs multi-instance.
    """

    def __init__(self, max_requests: int, window_seconds: float):
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self._hits: dict[str, deque] = defaultdict(deque)
        self._lock = threading.Lock()

    def check(self, key: str) -> None:
        now = time.monotonic()
        with self._lock:
            hits = self._hits[key]
            while hits and now - hits[0] > self.window_seconds:
                hits.popleft()
            if len(hits) >= self.max_requests:
                raise HTTPException(
                    status_code=429,
                    detail=f"Rate limit exceeded — max {self.max_requests} requests per "
                    f"{self.window_seconds:.0f}s. Please slow down.",
                )
            hits.append(now)
