import logging
import threading
import time
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

_JOB_TTL_SECONDS = 3600  # jobs older than this are discarded


@dataclass
class ExportJob:
    status: str                  # "pending" | "done" | "error"
    content: bytes | None = None
    media_type: str = ""
    filename: str = ""
    error: str = ""
    created_at: float = field(default_factory=time.monotonic)


_jobs: dict[str, ExportJob] = {}
_lock = threading.Lock()


def cleanup_old_jobs() -> None:
    cutoff = time.monotonic() - _JOB_TTL_SECONDS
    with _lock:
        stale = [jid for jid, j in _jobs.items() if j.created_at < cutoff]
        for jid in stale:
            del _jobs[jid]
    if stale:
        logger.debug("Cleaned up %d stale export jobs", len(stale))


def create_job(job_id: str) -> None:
    with _lock:
        _jobs[job_id] = ExportJob(status="pending")


def complete_job(job_id: str, content: bytes, media_type: str, filename: str) -> None:
    with _lock:
        if job_id in _jobs:
            job = _jobs[job_id]
            job.status = "done"
            job.content = content
            job.media_type = media_type
            job.filename = filename


def fail_job(job_id: str, error: str) -> None:
    with _lock:
        if job_id in _jobs:
            _jobs[job_id].status = "error"
            _jobs[job_id].error = error


def get_job(job_id: str) -> ExportJob | None:
    with _lock:
        return _jobs.get(job_id)


def pop_job(job_id: str) -> ExportJob | None:
    with _lock:
        return _jobs.pop(job_id, None)
