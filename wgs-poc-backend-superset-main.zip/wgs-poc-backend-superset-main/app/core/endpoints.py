API_PREFIX = "/api"


class AuthRoutes:
    PREFIX = "/auth"
    SIGNUP = "/signup"
    LOGIN = "/login"
    ACTIVATE = "/activate"
    LOGOUT = "/logout"


class UserRoutes:
    PREFIX = "/users"
    LIST_CREATE = "/"
    ME = "/me"
    BY_ID = "/{user_id}"


class RoleRoutes:
    PREFIX = "/roles"
    LIST_CREATE = "/"
    BY_ID = "/{role_id}"
    PERMISSIONS = "/{role_id}/permissions"


class TemplateRoutes:
    PREFIX = "/templates"
    LIST_CREATE = "/"
    BY_ID = "/{template_id}"
    UPLOAD_LOGO = "/upload-logo"
    EXPORT_PDF = "/{template_id}/export/pdf"
    EXPORT_EXCEL = "/{template_id}/export/excel"
    EXPORT_PDF_ASYNC = "/{template_id}/export/pdf/async"
    EXPORT_EXCEL_ASYNC = "/{template_id}/export/excel/async"
    EXPORT_JOB_STATUS = "/export/jobs/{job_id}/status"
    EXPORT_JOB_DOWNLOAD = "/export/jobs/{job_id}/download"


class ScheduledReportRoutes:
    PREFIX = "/scheduled-reports"
    LIST_CREATE = "/"
    BY_ID = "/{schedule_id}"
    SEND_NOW = "/{schedule_id}/send-now"


class ChatRoutes:
    PREFIX = "/chat"
    ASK = "/"
    AGENTS = "/agents"


class PageChatRoutes:
    PREFIX = "/page-chat"
    ASK = "/"


class EndpointRegistrationRoutes:
    PREFIX = "/endpoint-registrations"
    LIST_CREATE = "/"
    BY_ID = "/{endpoint_registration_id}"
    STATUS = "/{endpoint_registration_id}/status"
    TEST_CONNECTION_SAVED = "/{endpoint_registration_id}/test-connection"
    TEST_CONNECTION_DRAFT = "/test-connection"


class SupersetRoutes:
    PREFIX = "/superset"
    EMBED = "/embed"
    EMBED_BY_UUID = "/embed/{dashboard_uuid}"
    DASHBOARDS = "/dashboards"
    DATASETS = "/datasets"
    DATASET_COLUMNS = "/datasets/{dataset_id}/columns"
    DATASET_COLUMN_DATA = "/datasets/{dataset_id}/columns/{column_name}/data"
    DATASET_COLUMNS_BATCH = "/datasets/{dataset_id}/columns/batch-data"
    DATASET_QUERY = "/datasets/{dataset_id}/query"
    DATASET_METRICS_QUERY = "/datasets/{dataset_id}/metrics-query"
    # Dashboard data & export
    DASHBOARD_DATA = "/dashboard/{dashboard_uuid}/data"
    DASHBOARD_EXPORT_PDF_ASYNC = "/dashboard/{dashboard_uuid}/export/pdf/async"
    DASHBOARD_EXPORT_EXCEL_ASYNC = "/dashboard/{dashboard_uuid}/export/excel/async"
    DASHBOARD_EXPORT_VISUAL_IMAGE_ASYNC = "/dashboard/{dashboard_uuid}/export/visual-image/async"
    DASHBOARD_EXPORT_JOB_STATUS = "/dashboard/export/jobs/{job_id}/status"
    DASHBOARD_EXPORT_JOB_DOWNLOAD = "/dashboard/export/jobs/{job_id}/download"
