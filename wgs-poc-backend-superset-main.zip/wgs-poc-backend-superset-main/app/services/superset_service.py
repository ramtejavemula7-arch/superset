import requests
from typing import Optional, Dict, List
from app.core.config import settings


class SupersetService:
    def __init__(self):
        self.base_url = settings.superset_url.rstrip('/')
        self.username = settings.superset_username
        self.password = settings.superset_password
        self.provider = settings.superset_provider
        self._access_token: Optional[str] = None
        self.session = requests.Session()

    def login(self) -> str:
        """Authenticate with Superset and get access token."""
        try:
            login_url = f"{self.base_url}/api/v1/security/login"
            login_response = self.session.post(
                login_url,
                json={
                    "username": self.username,
                    "password": self.password,
                    "provider": self.provider,
                    "refresh": True
                },
                timeout=10
            )
            login_response.raise_for_status()
            self._access_token = login_response.json().get("access_token")
            if not self._access_token:
                raise ValueError("No access token in login response")
            return self._access_token
        except requests.exceptions.RequestException as e:
            raise Exception(f"Failed to login to Superset: {str(e)}")

    def get_headers(self) -> Dict[str, str]:
        """Get authorization headers with access token."""
        if not self._access_token:
            self.login()
        return {"Authorization": f"Bearer {self._access_token}"}

    def get_guest_token(
        self,
        dashboard_uuid: str,
        username: str = "guest",
        guest_id: Optional[str] = None,
        rls_rules: Optional[List[Dict]] = None
    ) -> str:
        """Get guest token for dashboard access."""
        try:
            guest_url = f"{self.base_url}/api/v1/security/guest_token"
            payload = {
                "resources": [
                    {
                        "type": "dashboard",
                        "id": dashboard_uuid
                    }
                ],
                "rls": rls_rules or [],
                "user": {
                    "username": username
                }
            }
            if guest_id:
                payload["user"]["id"] = guest_id

            guest_token_response = self.session.post(
                guest_url,
                headers=self.get_headers(),
                json=payload,
                timeout=10
            )
            guest_token_response.raise_for_status()
            token = guest_token_response.json().get("token")
            if not token:
                raise ValueError("No token in guest token response")
            return token
        except requests.exceptions.RequestException as e:
            raise Exception(f"Failed to get guest token: {str(e)}")

    def get_embed_url(
        self,
        dashboard_uuid: str,
        guest_token: str,
        standalone: bool = True
    ) -> str:
        """Generate embedded dashboard URL with guest token."""
        url = f"{self.base_url}/superset/dashboard/{dashboard_uuid}"
        params = []
        if standalone:
            params.append("standalone=1")
        params.append(f"guest_token={guest_token}")
        return f"{url}/?{'&'.join(params)}"

    def get_embed_url_with_iframe(
        self,
        dashboard_uuid: str,
        username: str = "guest",
        guest_id: Optional[str] = None,
        standalone: bool = True
    ) -> str:
        """Get complete embedded dashboard URL (login + guest token + URL)."""
        try:
            guest_token = self.get_guest_token(
                dashboard_uuid=dashboard_uuid,
                username=username,
                guest_id=guest_id
            )
            return self.get_embed_url(
                dashboard_uuid=dashboard_uuid,
                guest_token=guest_token,
                standalone=standalone
            )
        except Exception as e:
            raise Exception(f"Failed to generate embed URL: {str(e)}")

    def get_dashboards(self) -> Dict:
        """Get list of all dashboards."""
        try:
            response = self.session.get(
                f"{self.base_url}/api/v1/dashboard/",
                headers=self.get_headers(),
                timeout=10
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            raise Exception(f"Failed to get dashboards: {str(e)}")

    def get_dashboard(self, dashboard_uuid: str) -> Dict:
        """Get specific dashboard details."""
        try:
            response = self.session.get(
                f"{self.base_url}/api/v1/dashboard/{dashboard_uuid}",
                headers=self.get_headers(),
                timeout=10
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            raise Exception(f"Failed to get dashboard: {str(e)}")


superset_service = SupersetService()
