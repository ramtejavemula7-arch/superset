from fastapi import HTTPException
from google import genai
from google.oauth2 import service_account

from app.core.config import settings


def build_vertex_ai_client() -> genai.Client:
    """Build a genai.Client for calling Gemini.

    If GEMINI_API_KEY is set, uses the plain Gemini Developer API (a simple
    API key, no GCP project/IAM/Model-Garden access involved at all — bypasses
    Vertex AI entirely). Otherwise falls back to Vertex AI using this app's
    configured service-account credentials.

    Shared by every service that calls Gemini this way (as opposed to
    GeminiService, which uses the separate Gemini Data Analytics
    SDK/product and is unaffected by this setting either way).
    """
    if settings.gemini_api_key:
        return genai.Client(api_key=settings.gemini_api_key)

    kwargs = {
        "vertexai": True,
        "project": settings.google_cloud_project,
        "location": settings.gemini_chat_location,
    }
    if settings.google_application_credentials:
        try:
            kwargs["credentials"] = service_account.Credentials.from_service_account_file(
                settings.google_application_credentials,
                scopes=["https://www.googleapis.com/auth/cloud-platform"],
            )
        except (OSError, ValueError) as exc:
            raise HTTPException(
                status_code=502,
                detail=f"Failed to load Vertex AI service-account credentials: {exc}",
            ) from exc
    return genai.Client(**kwargs)
