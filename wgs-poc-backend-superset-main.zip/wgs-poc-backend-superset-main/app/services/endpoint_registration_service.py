from uuid import uuid4

from fastapi import HTTPException
from sqlalchemy.orm import Session

from app.models.endpoint_registration import EndpointRegistration
from app.schemas.endpoint_registration import EndpointRegistrationCreate, EndpointRegistrationUpdate
from app.services.secret_manager_service import SecretManagerService


def _new_secret_id() -> str:
    return f"endpoint-registration-{uuid4().hex}"


class EndpointRegistrationService:
    def __init__(self, secret_manager: SecretManagerService | None = None) -> None:
        # Injectable so tests can substitute a fake Secret Manager client —
        # GCP Secret Manager isn't provisioned yet, so this is the only way
        # to exercise create/rotate/delete-on-auth-type-change without real
        # GCP access.
        self._secrets = secret_manager or SecretManagerService()

    # ------------------------------------------------------------------ #
    # Reads                                                                #
    # ------------------------------------------------------------------ #

    def get_all(self, db: Session) -> list[EndpointRegistration]:
        return db.query(EndpointRegistration).order_by(EndpointRegistration.created_at.desc()).all()

    def get_by_id(self, db: Session, endpoint_registration_id: int) -> EndpointRegistration | None:
        return db.query(EndpointRegistration).filter(EndpointRegistration.id == endpoint_registration_id).first()

    def get_by_name(self, db: Session, name: str) -> EndpointRegistration | None:
        return db.query(EndpointRegistration).filter(EndpointRegistration.name == name).first()

    # ------------------------------------------------------------------ #
    # Writes                                                               #
    # ------------------------------------------------------------------ #

    def create(self, db: Session, payload: EndpointRegistrationCreate) -> EndpointRegistration:
        data = payload.model_dump(exclude={"secret_value"})

        secret_reference = None
        if payload.auth_type != "none":
            secret_reference = self._secrets.create_secret(_new_secret_id(), payload.secret_value)

        endpoint = EndpointRegistration(**data, secret_reference=secret_reference)
        try:
            db.add(endpoint)
            db.commit()
            db.refresh(endpoint)
        except Exception:
            # Postgres and GCP aren't one transaction — compensate for a
            # DB-side failure by removing the secret we just created.
            if secret_reference:
                self._secrets.delete_secret(secret_reference)
            raise
        return endpoint

    def update(
        self, db: Session, endpoint_registration_id: int, payload: EndpointRegistrationUpdate
    ) -> EndpointRegistration | None:
        endpoint = self.get_by_id(db, endpoint_registration_id)
        if not endpoint:
            return None

        updates = payload.model_dump(exclude_unset=True, exclude={"secret_value"})
        effective_auth_type = updates.get("auth_type", endpoint.auth_type)
        auth_type_changed = "auth_type" in updates and effective_auth_type != endpoint.auth_type

        if payload.secret_value and effective_auth_type == "none":
            raise HTTPException(
                status_code=400,
                detail="secret_value was provided but auth_type is 'none' — nothing to store it for",
            )

        if auth_type_changed:
            # Identity of the auth changed — the old secret (if any) no
            # longer applies, and a new one (if the new type needs it)
            # must be created fresh rather than rotated.
            if endpoint.secret_reference:
                self._secrets.delete_secret(endpoint.secret_reference)
            if effective_auth_type != "none":
                if not payload.secret_value:
                    raise HTTPException(
                        status_code=400,
                        detail=f"secret_value is required when changing auth_type to {effective_auth_type!r}",
                    )
                updates["secret_reference"] = self._secrets.create_secret(_new_secret_id(), payload.secret_value)
            else:
                updates["secret_reference"] = None
        elif payload.secret_value:
            # Same auth_type, rotating the credential in place.
            if endpoint.secret_reference:
                self._secrets.add_secret_version(endpoint.secret_reference, payload.secret_value)
            else:
                updates["secret_reference"] = self._secrets.create_secret(_new_secret_id(), payload.secret_value)
        # else: no secret_value provided and auth_type unchanged — leave the
        # existing secret untouched; only Section-1/auth_config fields change.

        for field, value in updates.items():
            setattr(endpoint, field, value)
        db.commit()
        db.refresh(endpoint)
        return endpoint

    def set_status(self, db: Session, endpoint_registration_id: int, status: str) -> EndpointRegistration | None:
        endpoint = self.get_by_id(db, endpoint_registration_id)
        if not endpoint:
            return None
        endpoint.status = status
        db.commit()
        db.refresh(endpoint)
        return endpoint

    def delete(self, db: Session, endpoint_registration_id: int) -> bool:
        endpoint = self.get_by_id(db, endpoint_registration_id)
        if not endpoint:
            return False
        if endpoint.secret_reference:
            # Best-effort: a GCP outage must not block deleting the DB row.
            self._secrets.delete_secret(endpoint.secret_reference)
        db.delete(endpoint)
        db.commit()
        return True

    # ------------------------------------------------------------------ #
    # Secret resolution (used by the test-connection service)              #
    # ------------------------------------------------------------------ #

    def resolve_secret(self, endpoint: EndpointRegistration) -> str | None:
        if not endpoint.secret_reference:
            return None
        return self._secrets.access_secret_value(endpoint.secret_reference)
