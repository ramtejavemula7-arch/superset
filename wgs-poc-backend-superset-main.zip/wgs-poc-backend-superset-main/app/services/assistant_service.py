import logging
from dataclasses import dataclass, field, replace
from typing import Any

from fastapi import HTTPException
from sqlalchemy.orm import Session

from app.core.config import settings
from app.services import session_service
from app.services.chat_cache import get_response_cache
from app.services.gemini_service import GeminiService
from app.services.quality_loop import synthesize_with_quality_loop
from app.services.rag_service import search_documents
from app.services.router_service import IntentClassification, classify_intent
from app.services.synthesis_service import (
    calculate_confidence,
    clean_synthesis,
    extract_confidence,
    extract_follow_ups,
    synthesize_answer,
)

logger = logging.getLogger(__name__)

_CLARIFY_MESSAGE = (
    "I'd like to help, but I need a bit more context. Could you rephrase your question? "
    'For example: "What were total sales last quarter?" or "How many active users do we have?"'
)


@dataclass
class AssistantResult:
    answer: str
    sql: str | None = None
    table: dict[str, Any] | None = None
    chart: dict[str, Any] | None = None
    intent: str = "SQL"
    confidence: float = 0.7
    follow_ups: list[str] = field(default_factory=list)
    session_id: str = ""


class AssistantService:
    """Chat Assistant entry point.

    Classifies the question's intent (SQL / RAG / HYBRID / CONTEXT / CLARIFY),
    queries BigQuery via GeminiService (Gemini-generated SQL executed
    directly against BigQuery) and/or the RAG corpus as needed, then
    synthesizes one answer — with a self-critique/refine pass — with dual
    citations, a confidence score, and follow-up suggestions. Mirrors
    Tensor's orchestration pattern (smart HYBRID routing, synthesis quality
    loop, response caching), adapted to this app's synchronous
    request/response contract (no SSE) and Postgres-backed auth, rather than
    calling Tensor as a separate service.

    `db` is accepted for interface compatibility with the /api/chat route
    (e.g. future audit logging) and is otherwise unused.
    """

    def __init__(self, data_service: GeminiService | None = None) -> None:
        self._data_service = data_service or GeminiService()

    def ask(
        self, question: str, db: Session, session_id: str, agent_name: str | None = None
    ) -> AssistantResult:
        response_cache = get_response_cache() if settings.chat_cache_enabled else None
        if response_cache:
            cached = response_cache.get(question, user_scope=session_id)
            if cached:
                session_service.add_message(session_id, "user", question)
                session_service.add_message(session_id, "assistant", cached.answer)
                return replace(cached, session_id=session_id)

        conversation_context = session_service.get_context(session_id)
        intent = classify_intent(question, conversation_context)

        if intent.intent == "CLARIFY":
            session_service.add_message(session_id, "user", question)
            session_service.add_message(session_id, "assistant", _CLARIFY_MESSAGE)
            return AssistantResult(
                answer=_CLARIFY_MESSAGE,
                intent="CLARIFY",
                confidence=0.9,
                session_id=session_id,
            )

        sql_result, rag_result, table, chart = self._gather_sources(question, intent, agent_name)

        if settings.quality_loop_enabled:
            synthesis_text, _quality_score = synthesize_with_quality_loop(
                question,
                intent.intent,
                sql_result,
                rag_result,
                conversation_context=conversation_context,
            )
        else:
            synthesis_text = synthesize_answer(
                question,
                intent.intent,
                sql_result,
                rag_result,
                conversation_context=conversation_context,
            )
        clean_text = clean_synthesis(synthesis_text)

        calculated_confidence = calculate_confidence(
            intent.confidence,
            sql_result,
            rag_result.get("chunks") if rag_result else None,
        )
        final_confidence = max(extract_confidence(synthesis_text), calculated_confidence)

        session_service.add_message(session_id, "user", question)
        session_service.add_message(session_id, "assistant", clean_text)

        result = AssistantResult(
            answer=clean_text,
            sql=sql_result.get("sql") if sql_result else None,
            table=table,
            chart=chart,
            intent=intent.intent,
            confidence=round(final_confidence, 2),
            follow_ups=extract_follow_ups(synthesis_text)[:3],
            session_id=session_id,
        )

        if response_cache:
            response_cache.set(question, result, user_scope=session_id)
        return result

    def _gather_sources(
        self, question: str, intent: IntentClassification, agent_name: str | None
    ) -> tuple[
        dict[str, Any] | None,
        dict[str, Any] | None,
        dict[str, Any] | None,
        dict[str, Any] | None,
    ]:
        """Run the SQL/RAG source(s) the intent calls for.

        For HYBRID with a specific primary source, runs that first and only
        falls through to the optional source if the primary result turns out
        weak (mirrors Tensor's smart-routing pipeline — skips a redundant
        second call when the primary source already answered well). For
        SQL-only, RAG-only, or HYBRID with primary="both", runs whichever
        sources the intent calls for (unchanged from before).
        """
        sql_result: dict[str, Any] | None = None
        rag_result: dict[str, Any] | None = None
        table: dict[str, Any] | None = None
        chart: dict[str, Any] | None = None

        def _run_sql() -> None:
            nonlocal sql_result, table, chart
            try:
                answer, sql, table, chart = self._data_service.ask(
                    intent.sql_question or question, agent_name=agent_name
                )
                sql_result = {"answer": answer, "sql": sql}
                # GeminiService no longer talks to a Data Agent that already
                # summarizes the data in `answer` — synthesis needs the raw
                # rows themselves to actually reason about the numbers.
                if table and table.get("columns"):
                    sql_result["rows"] = [dict(zip(table["columns"], row)) for row in table["rows"]]
            except HTTPException as exc:
                # Degrade gracefully — HYBRID can still answer from RAG alone,
                # and SQL-only surfaces the error via the synthesized answer
                # instead of a hard 502 for the whole request.
                logger.error("BigQuery query failed: %s", exc.detail)
                sql_result = {"error": str(exc.detail)}

        def _run_rag() -> None:
            nonlocal rag_result
            rag_result = search_documents(intent.rag_question or question)

        def _sql_strong() -> bool:
            if not sql_result or sql_result.get("error") or not sql_result.get("sql"):
                return False
            if table is None:
                return True  # a narrative answer backed by SQL, just no tabular rows
            return len(table.get("rows", [])) >= settings.sql_strong_min_rows

        def _rag_strong() -> bool:
            return bool(
                rag_result
                and rag_result.get("chunks")
                and rag_result["chunks"][0].get("score", 0) > settings.rag_relevance_threshold
            )

        if intent.intent == "HYBRID" and intent.primary in ("sql", "rag"):
            if intent.primary == "sql":
                _run_sql()
                primary_strong = _sql_strong()
            else:
                _run_rag()
                primary_strong = _rag_strong()

            if not primary_strong:
                if intent.optional == "sql" and sql_result is None:
                    _run_sql()
                elif intent.optional == "rag" and rag_result is None:
                    _run_rag()
        else:
            if intent.intent in ("SQL", "HYBRID"):
                _run_sql()
            if intent.intent in ("RAG", "HYBRID"):
                _run_rag()

        return sql_result, rag_result, table, chart
