import logging
import mimetypes
import re
import threading
from datetime import datetime, timedelta, timezone
from io import BytesIO
from pathlib import Path
from typing import Any
from urllib.parse import urlparse
from uuid import uuid4

import requests
import urllib3
from fastapi import HTTPException, UploadFile
from google.oauth2 import service_account

ROOT_DIR = Path(__file__).resolve().parents[2]
UPLOADS_DIR = ROOT_DIR / "uploads"
DEFAULT_SUPERSET_ROW_LIMIT = 10000
DEFAULT_DASHBOARD_LOGO_PATH = ROOT_DIR / "app" / "assets" / "dashboardlogo.png"

# PDF/Excel export only support raster images (PIL/ReportLab can't embed SVG).
ALLOWED_LOGO_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".bmp"}

# Suppress SSL warnings when verify=False is used
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

import tempfile

from openpyxl import Workbook
from openpyxl.drawing.image import Image as XLImage
from openpyxl.styles import Alignment, Border, Font, PatternFill, Protection, Side
from openpyxl.utils import get_column_letter
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas as pdfcanvas
from reportlab.platypus import (
    BaseDocTemplate, Frame, Image, NextPageTemplate, PageTemplate, Paragraph,
    SimpleDocTemplate, Spacer, Table, TableStyle,
)
from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)

from app.core.config import settings
from app.models.template import Template
from app.schemas.template import TemplateCreate, TemplateUpdate
from app.services.superset_visuals import capture_dashboard_screenshot

# Epoch-ms range: any integer in this range is treated as a date
# 100000000000  = 1973-03-03  (lower bound — nothing older matters)
# 9999999999999 = 2286-11-20  (upper bound — safely far future)
_EPOCH_MS_MIN = 100_000_000_000
_EPOCH_MS_MAX = 9_999_999_999_999


def _gcs_client():
    from google.cloud import storage

    if settings.google_application_credentials:
        credentials = service_account.Credentials.from_service_account_file(
            settings.google_application_credentials
        )
        return storage.Client(project=settings.google_cloud_project, credentials=credentials)
    return storage.Client(project=settings.google_cloud_project)

_BLACK_THIN = Side(style="thin", color="000000")
CELL_BORDER = Border(left=_BLACK_THIN, right=_BLACK_THIN, top=_BLACK_THIN, bottom=_BLACK_THIN)
UNLOCKED = Protection(locked=False)

# Report header/footer content — static for now, not yet per-template configurable
REPORT_COMPANY = "Worldline"
REPORT_CONTACT = "reports@worldline.com"
REPORT_CONFIDENTIALITY = "Confidential"
REPORT_TEAL = colors.HexColor("#277777")

# Derived date-part dimensions: a dimension/column-pivot field named
# "{real_column}__year" / "__month" / "__quarter" (e.g. "order_date__year" for
# a Matrix Report's "Order Year") is not a real column, so it can't be sent to
# Superset as a plain groupby string. Expand it into an adhoc SQL column
# instead, keeping the original name as its label so returned rows are still
# keyed exactly the way callers already expect (row.get("order_date__year")).
_DERIVED_DIM_RE = re.compile(r"^(?P<col>.+)__(?P<part>year|month|quarter)$")
_DERIVED_DIM_SQL_PART = {"year": "YEAR", "month": "MONTH", "quarter": "QUARTER"}


def expand_dimension_column(dim: str) -> str | dict[str, Any]:
    """Return `dim` unchanged if it's a plain column name, or a Superset adhoc
    SQL column (EXTRACT(...)) if it matches the derived date-part convention."""
    match = _DERIVED_DIM_RE.match(dim)
    if not match:
        return dim
    col, part = match.group("col"), match.group("part")
    sql_part = _DERIVED_DIM_SQL_PART[part]
    return {
        "label": dim,
        "sqlExpression": f"EXTRACT({sql_part} FROM {col})",
        "expressionType": "SQL",
    }


_MONTH_ABBR = {
    1: "Jan", 2: "Feb", 3: "Mar", 4: "Apr", 5: "May", 6: "Jun",
    7: "Jul", 8: "Aug", 9: "Sep", 10: "Oct", 11: "Nov", 12: "Dec",
}


def _derived_dim_part(dim: str) -> str | None:
    match = _DERIVED_DIM_RE.match(dim or "")
    return match.group("part") if match else None


def _format_dimension_value(dim: str, value: Any) -> str:
    """Display text for a row/column-pivot value. A "month"/"quarter" derived
    dimension's raw EXTRACT(...) result (a plain 1-12 / 1-4 int) renders as
    "Jan".."Dec" / "Q1".."Q4" — reading a bare month number isn't how a human
    scans a calendar-shaped report. Everything else (years, plain-column
    pivots like ship_mode) renders as-is."""
    if value is None:
        return "(blank)"
    part = _derived_dim_part(dim)
    try:
        if part == "month":
            return _MONTH_ABBR.get(int(value), str(value))
        if part == "quarter":
            return f"Q{int(value)}"
    except (TypeError, ValueError):
        pass
    return str(value)


def _humanize_dimension_label(dim: str) -> str:
    """Human-readable heading for a dimension/column-pivot field name — e.g.
    "order_date__month" -> "Order Date (Month)", "ship_mode" -> "Ship Mode"."""
    match = _DERIVED_DIM_RE.match(dim or "")
    if match:
        base = match.group("col").replace("_", " ").title()
        return f"{base} ({match.group('part').title()})"
    return (dim or "").replace("_", " ").title()


def _dimension_sort_key(value: Any):
    """Numeric pivot values (month/quarter/year, from expand_dimension_column's
    EXTRACT(...)) must sort numerically — string-sorting "1","10","11","12",
    "2",... scrambles calendar order. Falls back to string sort for a
    genuinely non-numeric pivot (e.g. a plain text dimension like ship_mode)."""
    try:
        return (0, float(value))
    except (TypeError, ValueError):
        return (1, str(value))


class _NumberedCanvas(pdfcanvas.Canvas):
    """Buffers every page so the footer can show 'Page X of Y' — the total
    page count isn't known until all pages have been drawn once."""

    def __init__(self, *args, **kwargs):
        pdfcanvas.Canvas.__init__(self, *args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        total_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.setFont("Helvetica", 8)
            self.setFillColor(colors.HexColor("#555555"))
            self.drawCentredString(letter[0] / 2, 30, f"Page {self._pageNumber} of {total_pages}")
            pdfcanvas.Canvas.showPage(self)
        pdfcanvas.Canvas.save(self)


def _lock_logo_in_place(sheet) -> None:
    """Protect the sheet just enough to stop the logo image from being dragged/resized,
    without restricting cell editing, sorting, or the autofilter — those stay unlocked."""
    sheet.protection.sheet = True
    sheet.protection.objects = True  # locks pictures/shapes so they can't be moved or resized
    sheet.protection.selectLockedCells = False
    sheet.protection.selectUnlockedCells = False
    sheet.protection.formatCells = False
    sheet.protection.formatColumns = False
    sheet.protection.formatRows = False
    sheet.protection.sort = False
    sheet.protection.autoFilter = False
    sheet.protection.insertRows = False
    sheet.protection.insertColumns = False
    sheet.protection.deleteRows = False
    sheet.protection.deleteColumns = False
    sheet.protection.pivotTables = False
    sheet.protection.insertHyperlinks = False


class TemplateService:

    # token cache: {base_url: {"token": str, "expires_at": datetime}}
    _token_cache: dict[str, dict] = {}
    _token_lock = threading.Lock()

    # dashboard id cache: {uuid: (numeric_id, title)}
    _dashboard_id_cache: dict[str, tuple] = {}

    _WATERMARK_PATH = Path(__file__).resolve().parent.parent / "assets" / "wgslogo.png"
    _watermark_reader: ImageReader | None | bool = False  # False = not loaded yet, None = load failed

    # ------------------------------------------------------------------ #
    # Helpers                                                              #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _dump_model(payload: Any, exclude_unset: bool = False) -> dict[str, Any]:
        if hasattr(payload, "model_dump"):
            return payload.model_dump(exclude_unset=exclude_unset)
        return payload.dict(exclude_unset=exclude_unset)

    @classmethod
    def _superset_login(cls, base_url: str) -> str:
        """Return a cached Superset token, refreshing only when it nears expiry."""
        with cls._token_lock:
            cached = cls._token_cache.get(base_url)
            if cached and cached["expires_at"] > datetime.now(tz=timezone.utc):
                return cached["token"]

        # fetch a fresh token outside the lock so other threads can proceed
        try:
            resp = requests.post(
                f"{base_url}/api/v1/security/login",
                json={
                    "username": settings.superset_user,
                    "password": settings.superset_pass,
                    "provider": settings.superset_provider,
                    "refresh": True,
                },
                timeout=10,
                verify=False,
            )
        except requests.RequestException as exc:
            raise HTTPException(status_code=502, detail=f"Superset login failed: {exc}") from exc

        if resp.status_code in (401, 403):
            raise HTTPException(
                status_code=502,
                detail=f"Superset login rejected (check credentials): {resp.text[:200]}",
            )
        if not resp.ok:
            raise HTTPException(
                status_code=502,
                detail=f"Superset login error {resp.status_code}: {resp.text[:200]}",
            )

        token = resp.json().get("access_token")
        if not token:
            raise HTTPException(status_code=502, detail="Superset access token missing in response")

        # cache for 50 minutes (Superset JWTs are usually valid for 1 hour)
        with cls._token_lock:
            cls._token_cache[base_url] = {
                "token": token,
                "expires_at": datetime.now(tz=timezone.utc) + timedelta(minutes=50),
            }

        logger.debug("Superset token refreshed for %s", base_url)
        return token

    @staticmethod
    def _fetch_dataset_meta(base_url: str, token: str, dataset_id: int) -> dict:
        try:
            resp = requests.get(
                f"{base_url}/api/v1/dataset/{dataset_id}",
                headers={"Authorization": f"Bearer {token}"},
                timeout=15,
                verify=False,
            )
        except requests.RequestException as exc:
            raise HTTPException(status_code=502, detail=f"Superset dataset fetch failed: {exc}") from exc

        if not resp.ok:
            raise HTTPException(
                status_code=502,
                detail=f"Superset dataset {dataset_id} error {resp.status_code}: {resp.text[:200]}",
            )
        return resp.json().get("result", {})

    @staticmethod
    def _convert_value(value: Any) -> Any:
        """
        Convert epoch-ms integers/floats/strings to YYYY-MM-DD.
        Recursively converts nested dict/list values too.
        Everything else is returned unchanged.
        """
        if value is None:
            return value

        if isinstance(value, dict):
            # if the dict holds a single epoch-ms value, convert it directly
            if "value" in value and len(value) == 1:
                return TemplateService._convert_value(value["value"])
            if "__timestamp" in value and len(value) == 1:
                return TemplateService._convert_value(value["__timestamp"])
            return {k: TemplateService._convert_value(v) for k, v in value.items()}

        if isinstance(value, (list, tuple)):
            converted = [TemplateService._convert_value(v) for v in value]
            return type(value)(converted)

        # integer or float epoch ms
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            if _EPOCH_MS_MIN <= value <= _EPOCH_MS_MAX:
                try:
                    return datetime.fromtimestamp(
                        value / 1000, tz=timezone.utc
                    ).strftime("%Y-%m-%d")
                except Exception:
                    pass
            return value

        # string that is purely digits (e.g. "1473033600000")
        if isinstance(value, str):
            stripped = value.strip()
            if stripped.lstrip("-").isdigit():
                numeric = int(stripped)
                if _EPOCH_MS_MIN <= numeric <= _EPOCH_MS_MAX:
                    try:
                        return datetime.fromtimestamp(
                            numeric / 1000, tz=timezone.utc
                        ).strftime("%Y-%m-%d")
                    except Exception:
                        pass

        return value

    @staticmethod
    def _convert_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Apply _convert_value to every value in every row."""
        return [
            {k: TemplateService._convert_value(v) for k, v in row.items()}
            for row in rows
        ]

    @staticmethod
    def _format_filter(f: dict[str, Any]) -> str:
        """Render one {col/field, op/operator, val/value} filter in plain words,
        e.g. 'Region is one of East, West' or 'Sales is between 100 and 500' —
        not SQL syntax, so it reads naturally for a non-technical reader."""
        col = f.get("col", f.get("field", "?"))
        label = str(col).replace("_", " ").title()
        op = f.get("op", f.get("operator", "?"))
        op = {"EQ": "=="}.get(op, op)
        val = f.get("val", f.get("value"))

        if op == "IS NULL":
            return f"{label} is empty"
        if op == "IS NOT NULL":
            return f"{label} is not empty"
        if op == "BETWEEN" and isinstance(val, (list, tuple)) and len(val) == 2:
            return f"{label} is between {val[0]} and {val[1]}"
        if op == "IN" and isinstance(val, (list, tuple)):
            return f"{label} is one of {', '.join(str(v) for v in val)}"
        if op == "NOT IN" and isinstance(val, (list, tuple)):
            return f"{label} is not one of {', '.join(str(v) for v in val)}"
        if op == "LIKE":
            return f"{label} contains {str(val).strip('%')}"
        if op == "==":
            return f"{label} is {val}"
        if op == "!=":
            return f"{label} is not {val}"
        if op == ">":
            return f"{label} is greater than {val}"
        if op == "<":
            return f"{label} is less than {val}"
        if op == ">=":
            return f"{label} is at least {val}"
        if op == "<=":
            return f"{label} is at most {val}"
        return f"{label} {op} {val}"

    @staticmethod
    def _format_filters_summary(filters: list[dict[str, Any]] | None) -> str:
        if not filters:
            return ""
        return " and ".join(TemplateService._format_filter(f) for f in filters)

    @staticmethod
    def _excel_cell_value(raw: Any) -> Any:
        """Normalize a raw dataset value for an Excel cell: numeric-looking values
        (real numbers or numeric strings from the data source) become an actual
        int/float so Excel's own SUM/AVERAGE match the backend-computed Total —
        otherwise they'd sit as text and be silently skipped by Excel's SUM.
        None/empty becomes a blank cell instead of the literal text "None"."""
        if raw is None or raw == "":
            return None
        if isinstance(raw, (int, float)):
            return raw
        if isinstance(raw, str):
            try:
                f = float(raw.strip())
                return int(f) if f.is_integer() else f
            except ValueError:
                return raw
        return str(raw)

    @staticmethod
    def _compute_totals_row(
        rows: list[dict[str, Any]], headers: list[str], total_columns: list[str] | None
    ) -> dict[str, Any]:
        """Sum only the columns the user checked (`total_columns`) — no Total
        row at all if nothing's selected. A selected column with no numeric
        values (text, or all blank) is simply left out of the result."""
        if not total_columns:
            return {}
        wanted = set(total_columns) & set(headers)
        totals: dict[str, Any] = {}
        for h in wanted:
            values = []
            for r in rows:
                v = r.get(h)
                if v is None or v == "":
                    continue
                try:
                    values.append(float(v))
                except (TypeError, ValueError):
                    continue
            if values:
                totals[h] = sum(values)
        return totals

    # Symbol/decimals/grouping match each currency's Intl.NumberFormat locale
    # on the frontend (see CURRENCY_LOCALES there) so exports read the same
    # as the on-screen table. "western_dot" swaps the "," (thousands) and
    # "." (decimal) roles western grouping normally uses — matching de-DE's
    # "123.456,78" convention for EUR.
    _CURRENCY_META = {
        "INR": {"symbol": "₹", "decimals": 2, "grouping": "indian", "symbol_after": False},
        "USD": {"symbol": "$", "decimals": 2, "grouping": "western", "symbol_after": False},
        "EUR": {"symbol": "€", "decimals": 2, "grouping": "western_dot", "symbol_after": True},
        "GBP": {"symbol": "£", "decimals": 2, "grouping": "western", "symbol_after": False},
        "JPY": {"symbol": "¥", "decimals": 0, "grouping": "western", "symbol_after": False},
    }

    # openpyxl number_format codes for the same currencies — keeps the cell
    # numeric (Excel's own SUM/AVERAGE still work) while displaying the
    # symbol/decimals/grouping. "##,##,##0" is Excel's literal Indian
    # (lakh/crore) grouping pattern; the "," vs "." separator glyphs
    # themselves render per the viewing Excel's own regional settings.
    _EXCEL_CURRENCY_FORMATS = {
        "INR": '"₹"#,##,##0.00',
        "USD": '"$"#,##0.00',
        "EUR": '#,##0.00" €"',
        "GBP": '"£"#,##0.00',
        "JPY": '"¥"#,##0',
    }

    @staticmethod
    def _format_indian_number(abs_value: float, decimals: int) -> str:
        """Format a non-negative `abs_value` with Indian (lakh/crore) digit
        grouping — the last 3 digits, then groups of 2 for the rest (e.g.
        1234567.8 -> "12,34,567.80")."""
        text = f"{abs_value:.{decimals}f}"
        intpart, _, frac = text.partition(".")
        if len(intpart) > 3:
            last3 = intpart[-3:]
            rest = intpart[:-3]
            groups = []
            while len(rest) > 2:
                groups.insert(0, rest[-2:])
                rest = rest[:-2]
            if rest:
                groups.insert(0, rest)
            intpart = ",".join(groups) + "," + last3
        return f"{intpart}.{frac}" if decimals else intpart

    @classmethod
    def _format_currency(cls, value: float, currency_code: str | None) -> str | None:
        """Render `value` as currency text for a PDF cell, matching the
        frontend's Intl.NumberFormat output for `currency_code`. Returns None
        for an unset/unrecognized code so the caller falls back to plain
        number formatting instead of erroring."""
        meta = cls._CURRENCY_META.get(currency_code) if currency_code else None
        if meta is None:
            return None
        sign = "-" if value < 0 else ""
        abs_value = abs(value)
        if meta["grouping"] == "indian":
            number = cls._format_indian_number(abs_value, meta["decimals"])
        else:
            number = f"{abs_value:,.{meta['decimals']}f}"
            if meta["grouping"] == "western_dot":
                number = number.translate(str.maketrans(",.", ".,"))
        if meta["symbol_after"]:
            return f"{sign}{number} {meta['symbol']}"
        return f"{sign}{meta['symbol']}{number}"

    @classmethod
    def _format_pdf_cell(cls, value: Any, currency_code: str | None) -> str:
        """Render one row's PDF cell text — currency-formatted if `currency_code`
        is set and `value` is numeric, otherwise the plain str() used before
        this formatting existed (preserved as-is for non-currency columns)."""
        if currency_code:
            try:
                num = float(value)
            except (TypeError, ValueError):
                num = None
            if num is not None:
                text = cls._format_currency(num, currency_code)
                if text is not None:
                    return text
        return str(value)

    @classmethod
    def _apply_excel_currency_format(cls, cell, value: Any, currency_code: str | None) -> None:
        """Set `cell.number_format` for currency display, leaving the cell's
        underlying numeric value untouched so Excel's own SUM/AVERAGE still
        work. No-op for non-numeric values or an unrecognized currency code."""
        if not currency_code or not isinstance(value, (int, float)):
            return
        number_format = cls._EXCEL_CURRENCY_FORMATS.get(currency_code)
        if number_format:
            cell.number_format = number_format

    @staticmethod
    def _compute_merge_spans(rows: list[dict[str, Any]], dimensions: list[str]) -> dict[str, list[tuple[int, int]]]:
        """For a 'grouped' template's row-level export, compute the vertical
        merge runs for each dimension column — assumes `rows` is already
        sorted by `dimensions` in order, so equal values are contiguous. A
        run in an outer dimension bounds every inner dimension's own runs
        (e.g. two different Clients sharing the same Payment Method must NOT
        merge across the Client boundary), so each dimension's runs are
        computed against the full prefix up to and including itself, not
        just its own column in isolation."""
        spans: dict[str, list[tuple[int, int]]] = {d: [] for d in dimensions}
        n = len(rows)
        if not n or not dimensions:
            return spans
        for depth, dim in enumerate(dimensions):
            prefix = dimensions[: depth + 1]
            start = 0
            for i in range(1, n + 1):
                if i == n or any(rows[i].get(p) != rows[start].get(p) for p in prefix):
                    spans[dim].append((start, i - start))
                    start = i
        return spans

    def _fetch_grouped_rows(self, template, force: bool = False) -> list[dict[str, Any]]:
        """Fetch a 'grouped' template's row-level data — same flat/unaggregated
        query the transaction template uses (every underlying row stays its
        own row), sorted by `dimensions` in order so equal group values become
        contiguous ahead of the merge-span computation."""
        rows = self.query_superset_dataset(
            template.dataset_id, template.columns, template.filters, force=force
        )
        dims = template.dimensions or []
        if dims:
            rows = sorted(rows, key=lambda r: tuple(str(r.get(d)) for d in dims))
        return rows

    # ------------------------------------------------------------------ #
    # CRUD                                                                 #
    # ------------------------------------------------------------------ #

    def get_all(self, db: Session) -> list[Template]:
        return db.query(Template).order_by(Template.created_at.desc()).all()

    def get_by_id(self, db: Session, template_id: int) -> Template | None:
        return db.query(Template).filter(Template.id == template_id).first()

    def get_by_name(self, db: Session, name: str) -> Template | None:
        return db.query(Template).filter(Template.name == name).first()

    def create(self, db: Session, payload: TemplateCreate) -> Template:
        # New template_type="metrics" (the old aggregated pivot) templates are
        # disabled for creation — that report is superseded by "grouped" (the
        # user-facing "Matrix" template today). Existing "metrics" rows already
        # in the database are untouched and keep reading/exporting normally.
        if payload.template_type == "metrics":
            raise HTTPException(
                status_code=400,
                detail=(
                    "Creating new Matrix (aggregated) templates is currently disabled. "
                    "Use template_type='grouped' — the current \"Matrix\" template — instead."
                ),
            )
        template = Template(**self._dump_model(payload))
        db.add(template)
        db.commit()
        db.refresh(template)
        return template

    def update(self, db: Session, template_id: int, payload: TemplateUpdate) -> Template | None:
        template = self.get_by_id(db, template_id)
        if not template:
            return None
        updates = self._dump_model(payload, exclude_unset=True)
        # Switching an existing non-"metrics" template INTO "metrics" is
        # equivalent to creating a new one — blocked for the same reason as
        # create(). A template that's already "metrics" can still be edited
        # (renamed, filters changed, etc.) without tripping this.
        if updates.get("template_type") == "metrics" and template.template_type != "metrics":
            raise HTTPException(
                status_code=400,
                detail=(
                    "Switching a template to Matrix (aggregated) is currently disabled. "
                    "Use template_type='grouped' — the current \"Matrix\" template — instead."
                ),
            )
        for field, value in updates.items():
            setattr(template, field, value)
        db.commit()
        db.refresh(template)
        return template

    def delete(self, db: Session, template_id: int) -> bool:
        template = self.get_by_id(db, template_id)
        if not template:
            return False
        db.delete(template)
        db.commit()
        return True

    # ------------------------------------------------------------------ #
    # Logo upload                                                          #
    # ------------------------------------------------------------------ #

    async def upload_logo(self, file: UploadFile) -> str:
        extension = Path(file.filename or "file").suffix.lower() or ".png"
        if extension not in ALLOWED_LOGO_EXTENSIONS:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"Unsupported logo format '{extension}'. PDF/Excel exports can only embed "
                    f"raster images: {', '.join(sorted(ALLOWED_LOGO_EXTENSIONS))}. "
                    "SVG is not supported — please upload a PNG or JPEG version of the logo."
                ),
            )
        if not settings.gcs_uploads_bucket:
            raise HTTPException(status_code=500, detail="GCS_UPLOADS_BUCKET is not configured")

        file_name = f"{uuid4().hex}{extension}"
        contents = await file.read()
        content_type = mimetypes.guess_type(file_name)[0] or "application/octet-stream"

        try:
            bucket = _gcs_client().bucket(settings.gcs_uploads_bucket)
            blob = bucket.blob(file_name)
            blob.upload_from_string(contents, content_type=content_type)
        except Exception as exc:
            raise HTTPException(status_code=502, detail=f"Logo upload to GCS failed: {exc}") from exc

        return f"https://storage.googleapis.com/{settings.gcs_uploads_bucket}/{file_name}"

    # ------------------------------------------------------------------ #
    # Superset data fetch                                                  #
    # ------------------------------------------------------------------ #

    def query_superset_dataset(
        self,
        dataset_id: int,
        columns: list[str] | None = None,
        filters: list[dict[str, Any]] | None = None,
        row_limit: int | None = None,
        force: bool = False,
    ) -> list[dict[str, Any]]:
        """Fetch every row matching `filters` — paginates past Superset's own
        per-request row cap so exports are never silently truncated. Pass an
        explicit `row_limit` to cap the result instead (e.g. for a preview).
        Pass `force=True` to bypass Superset's query cache and hit the live
        database — used for scheduled sends so they never mail stale data."""
        if not settings.superset_base or not settings.superset_user or not settings.superset_pass:
            raise HTTPException(
                status_code=500, detail="Superset credentials are not configured"
            )

        base_url = settings.superset_base.rstrip("/")
        token = self._superset_login(base_url)

        # fetch metadata only to discover column names when none given
        if not columns:
            meta = self._fetch_dataset_meta(base_url, token, dataset_id)
            columns = [col["column_name"] for col in meta.get("columns", [])]

        # template.filters is unvalidated JSON (any dict shape is accepted at save
        # time), so accept both the {col, op, val} and {field, operator, value}
        # namings here rather than crashing at export time on a raw KeyError.
        def _col(f):
            return f.get("col", f.get("field"))

        def _op(f):
            raw = f.get("op", f.get("operator"))
            return {"EQ": "=="}.get(raw, raw)  # "EQ" is a common symbolic alias for "=="

        def _val(f):
            return f.get("val", f.get("value"))

        # Superset's queries[].filters field expects plain {col, op, val} objects —
        # NOT the adhoc_filter shape (clause/subject/operator/comparator/expressionType).
        # It also has no native BETWEEN operator, so expand that into two AND-ed
        # filters (>= start, <= end) on the same column.
        query_filters = []
        for f in (filters or []):
            col, op, val = _col(f), _op(f), _val(f)
            if not col or not op:
                raise HTTPException(
                    status_code=400,
                    detail=f"Template filter missing required 'col'/'op' (or 'field'/'operator') keys: {f}",
                )
            if op == "BETWEEN":
                start, end = val
                query_filters.append({"col": col, "op": ">=", "val": start})
                query_filters.append({"col": col, "op": "<=", "val": end})
            else:
                query_filters.append({"col": col, "op": op, **({} if val is None else {"val": val})})

        def _do_query(auth_token: str, batch_limit: int, offset: int):
            query_payload = {
                "datasource": {"id": dataset_id, "type": "table"},
                "queries": [
                    {
                        "columns": columns,
                        "filters": query_filters,
                        "row_limit": batch_limit,
                        "row_offset": offset,
                    }
                ],
                "result_format": "json",
                "result_type": "full",
                "force": force,
            }
            try:
                return requests.post(
                    f"{base_url}/api/v1/chart/data",
                    headers={
                        "Authorization": f"Bearer {auth_token}",
                        "Content-Type": "application/json",
                    },
                    json=query_payload,
                    timeout=30,
                    verify=False,
                )
            except requests.RequestException as exc:
                raise HTTPException(
                    status_code=502, detail=f"Superset request failed: {exc}"
                ) from exc

        BATCH_SIZE = DEFAULT_SUPERSET_ROW_LIMIT
        all_rows: list[dict[str, Any]] = []
        offset = 0
        while True:
            batch_limit = min(BATCH_SIZE, row_limit - offset) if row_limit else BATCH_SIZE
            if row_limit and batch_limit <= 0:
                break

            resp = _do_query(token, batch_limit, offset)

            # token may have expired between cache and now — refresh once and retry
            if resp.status_code == 401:
                with self._token_lock:
                    self._token_cache.pop(base_url, None)
                token = self._superset_login(base_url)
                resp = _do_query(token, batch_limit, offset)

            if not resp.ok:
                try:
                    error_detail = resp.json()
                except ValueError:
                    error_detail = resp.text
                raise HTTPException(
                    status_code=502,
                    detail=f"Superset chart/data failed ({resp.status_code}): {error_detail}",
                )

            data = resp.json()
            try:
                batch_rows = data["result"][0]["data"]
            except (KeyError, IndexError):
                batch_rows = []

            all_rows.extend(batch_rows)
            if len(batch_rows) < batch_limit:
                break  # fewer rows than asked for — that was the last page
            offset += batch_limit

        # convert every epoch-ms value in every row — no metadata guessing
        return self._convert_rows(all_rows)

    def query_superset_dataset_metrics(
        self,
        dataset_id: int,
        dimensions: list[str] | None,
        metrics: list[dict[str, Any]] | None,
        sort: dict[str, Any] | None = None,
        filters: list[dict[str, Any]] | None = None,
        row_limit: int | None = None,
        force: bool = False,
    ) -> tuple[list[str], list[dict[str, Any]]]:
        """Run a grouped/aggregated query (dimensions + metrics) for a metrics-type
        template's export — mirrors the /metrics-query endpoint's Superset payload
        shape, and paginates past Superset's own per-request cap like the
        row-level query does. Returns (column_names, rows)."""
        dimensions = dimensions or []
        metrics = metrics or []
        columns_out = dimensions + [m.get("label", m.get("field")) for m in metrics]
        if not metrics:
            return columns_out, []

        if not settings.superset_base or not settings.superset_user or not settings.superset_pass:
            raise HTTPException(status_code=500, detail="Superset credentials are not configured")

        base_url = settings.superset_base.rstrip("/")
        token = self._superset_login(base_url)

        def _build_metric(spec: dict[str, Any]):
            field, aggregation = spec.get("field"), spec.get("aggregation")
            if field == "__order_count__" and aggregation == "COUNT":
                return "count"  # Superset's built-in row-count metric
            return {
                "expressionType": "SIMPLE",
                "column": {"column_name": field},
                "aggregate": aggregation,
                "label": spec.get("label", field),
            }

        superset_metrics = [_build_metric(m) for m in metrics]

        query_filters = []
        for f in (filters or []):
            col = f.get("col", f.get("field"))
            op = f.get("op", f.get("operator"))
            op = {"EQ": "=="}.get(op, op)
            val = f.get("val", f.get("value"))
            if op == "BETWEEN" and isinstance(val, (list, tuple)) and len(val) == 2:
                query_filters.append({"col": col, "op": ">=", "val": val[0]})
                query_filters.append({"col": col, "op": "<=", "val": val[1]})
            else:
                query_filters.append({"col": col, "op": op, **({} if val is None else {"val": val})})

        orderby = None
        if sort:
            sort_field = sort.get("field")
            valid_sort_fields = set(dimensions) | {m.get("label", m.get("field")) for m in metrics}
            if sort_field in valid_sort_fields:
                orderby = [[sort_field, sort.get("direction") != "desc"]]

        expanded_dimensions = [expand_dimension_column(d) for d in dimensions]

        def _do_query(auth_token: str, batch_limit: int, offset: int):
            query: dict[str, Any] = {
                "columns": expanded_dimensions,
                "metrics": superset_metrics,
                "groupby": expanded_dimensions,
                "filters": query_filters,
                "row_limit": batch_limit,
                "row_offset": offset,
            }
            if orderby:
                query["orderby"] = orderby
            query_payload = {
                "datasource": {"id": dataset_id, "type": "table"},
                "queries": [query],
                "result_format": "json",
                "result_type": "full",
                "force": force,
            }
            try:
                return requests.post(
                    f"{base_url}/api/v1/chart/data",
                    headers={"Authorization": f"Bearer {auth_token}", "Content-Type": "application/json"},
                    json=query_payload,
                    timeout=30,
                    verify=False,
                )
            except requests.RequestException as exc:
                raise HTTPException(status_code=502, detail=f"Superset request failed: {exc}") from exc

        BATCH_SIZE = DEFAULT_SUPERSET_ROW_LIMIT
        all_rows: list[dict[str, Any]] = []
        offset = 0
        while True:
            batch_limit = min(BATCH_SIZE, row_limit - offset) if row_limit else BATCH_SIZE
            if row_limit and batch_limit <= 0:
                break

            resp = _do_query(token, batch_limit, offset)

            if resp.status_code == 401:
                with self._token_lock:
                    self._token_cache.pop(base_url, None)
                token = self._superset_login(base_url)
                resp = _do_query(token, batch_limit, offset)

            if not resp.ok:
                try:
                    error_detail = resp.json()
                except ValueError:
                    error_detail = resp.text
                raise HTTPException(
                    status_code=502,
                    detail=f"Superset chart/data failed ({resp.status_code}): {error_detail}",
                )

            data = resp.json()
            try:
                batch_rows = data["result"][0]["data"]
            except (KeyError, IndexError):
                batch_rows = []

            all_rows.extend(batch_rows)
            if len(batch_rows) < batch_limit:
                break
            offset += batch_limit

        return columns_out, self._convert_rows(all_rows)

    def _run_grouped_metrics_query(
        self,
        dataset_id: int,
        groupby: list[str],
        metric_specs: list[dict[str, Any]],
        filters: list[dict[str, Any]] | None,
        sort: dict[str, Any] | None,
        force: bool,
    ) -> list[dict[str, Any]]:
        """Run one grouped/aggregated Superset query and fetch every matching row,
        paginated past Superset's own per-request cap. Used by the metrics-matrix
        Excel export to compute each rollup level's aggregate directly in the
        database — a level's subtotal is NEVER derived by summing/averaging
        another level's already-aggregated rows in Python, since that is
        mathematically wrong for AVG/MIN/MAX (and only accidentally right for
        SUM/COUNT when every child has equal weight)."""
        if not settings.superset_base or not settings.superset_user or not settings.superset_pass:
            raise HTTPException(status_code=500, detail="Superset credentials are not configured")

        base_url = settings.superset_base.rstrip("/")
        token = self._superset_login(base_url)

        def _build_metric(spec: dict[str, Any]):
            field, aggregation = spec.get("field"), spec.get("aggregation")
            if field == "__order_count__" and aggregation == "COUNT":
                return "count"
            return {
                "expressionType": "SIMPLE",
                "column": {"column_name": field},
                "aggregate": aggregation,
                "label": spec.get("label", field),
            }

        superset_metrics = [_build_metric(m) for m in metric_specs]
        metric_labels = {m.get("label", m.get("field")) for m in metric_specs}

        query_filters = []
        for f in (filters or []):
            col = f.get("col", f.get("field"))
            op = f.get("op", f.get("operator"))
            op = {"EQ": "=="}.get(op, op)
            val = f.get("val", f.get("value"))
            if op == "BETWEEN" and isinstance(val, (list, tuple)) and len(val) == 2:
                query_filters.append({"col": col, "op": ">=", "val": val[0]})
                query_filters.append({"col": col, "op": "<=", "val": val[1]})
            else:
                query_filters.append({"col": col, "op": op, **({} if val is None else {"val": val})})

        # groupby/orderby must reference the SAME column form Superset was
        # given in "columns"/"groupby" — for a derived dimension (e.g.
        # "order_date__year") that's the expanded adhoc SQL-column object, not
        # the plain dimension name; ordering by the bare string 400s with
        # "Unknown column used in orderby" because Superset has no real column
        # by that name, only the adhoc one. Compute the expansion first so
        # orderby can reuse each column's already-expanded form.
        expanded_groupby = [expand_dimension_column(c) for c in groupby]

        # Order by every groupby column ascending so sibling order lines up
        # consistently across every rollup level (needed to nest each level's
        # independent query results back into one hierarchy) — except the field
        # the user explicitly picked a sort for, which uses its chosen direction.
        # If the sort field is a metric rather than a dimension, sort by that
        # metric's value first, with groupby columns as a stable tie-breaker.
        sort_field = sort.get("field") if sort else None
        sort_desc = bool(sort and sort.get("direction") == "desc")
        if sort_field and sort_field not in groupby and sort_field in metric_labels:
            orderby = [[sort_field, not sort_desc]] + [[exp_col, True] for exp_col in expanded_groupby]
        else:
            orderby = [
                [exp_col, not (col == sort_field and sort_desc)]
                for col, exp_col in zip(groupby, expanded_groupby)
            ]

        def _do_query(auth_token: str, batch_limit: int, offset: int):
            query: dict[str, Any] = {
                "columns": expanded_groupby,
                "metrics": superset_metrics,
                "groupby": expanded_groupby,
                "filters": query_filters,
                "row_limit": batch_limit,
                "row_offset": offset,
            }
            if orderby:
                query["orderby"] = orderby
            query_payload = {
                "datasource": {"id": dataset_id, "type": "table"},
                "queries": [query],
                "result_format": "json",
                "result_type": "full",
                "force": force,
            }
            try:
                return requests.post(
                    f"{base_url}/api/v1/chart/data",
                    headers={"Authorization": f"Bearer {auth_token}", "Content-Type": "application/json"},
                    json=query_payload,
                    timeout=30,
                    verify=False,
                )
            except requests.RequestException as exc:
                raise HTTPException(status_code=502, detail=f"Superset request failed: {exc}") from exc

        BATCH_SIZE = DEFAULT_SUPERSET_ROW_LIMIT
        all_rows: list[dict[str, Any]] = []
        offset = 0
        while True:
            resp = _do_query(token, BATCH_SIZE, offset)
            if resp.status_code == 401:
                with self._token_lock:
                    self._token_cache.pop(base_url, None)
                token = self._superset_login(base_url)
                resp = _do_query(token, BATCH_SIZE, offset)
            if not resp.ok:
                try:
                    error_detail = resp.json()
                except ValueError:
                    error_detail = resp.text
                raise HTTPException(
                    status_code=502,
                    detail=f"Superset chart/data failed ({resp.status_code}): {error_detail}",
                )
            data = resp.json()
            try:
                batch_rows = data["result"][0]["data"]
            except (KeyError, IndexError):
                batch_rows = []
            all_rows.extend(batch_rows)
            if len(batch_rows) < BATCH_SIZE:
                break
            offset += BATCH_SIZE

        return self._convert_rows(all_rows)

    def _fetch_metrics_matrix(self, template, force: bool = False) -> dict[str, Any]:
        """Fetch every level of a metrics-matrix rollup — full-depth detail down
        to the grand total — for the Matrix-style Excel export. Returns a dict
        with one entry per rollup depth (0 = grand total, len(dims) = leaf),
        each holding that depth's own correctly-aggregated query result."""
        dims = template.dimensions or []
        metric_specs = template.metrics or []
        metric_labels = [m.get("label", m.get("field")) for m in metric_specs]
        # label -> currency code, for exports to render that metric's numeric
        # cells (leaf/subtotal/grand-total alike) as currency instead of a
        # plain number. Missing/unset "format" -> None -> plain number.
        metric_formats = {m.get("label", m.get("field")): m.get("format") for m in metric_specs}
        column_field = getattr(template, "column_field", None) or None
        filters = template.filters or []
        sort = template.sort

        result: dict[str, Any] = {
            "dims": dims,
            "metrics": metric_specs,
            "metric_labels": metric_labels,
            "metric_formats": metric_formats,
            "column_field": column_field,
            "column_values": [],
            "levels": {},
        }
        if not metric_specs:
            return result

        seen_values: list[Any] = []
        seen_set: set = set()
        levels: dict[int, dict[str, Any]] = {}

        for depth in range(len(dims), -1, -1):
            prefix = dims[:depth]
            spread_groupby = prefix + ([column_field] if column_field else [])
            spread_rows = self._run_grouped_metrics_query(
                template.dataset_id, spread_groupby, metric_specs, filters, sort, force,
            )

            spread: dict[tuple, dict] = {}
            order: list[tuple] = []
            for row in spread_rows:
                path = tuple(row.get(d) for d in prefix)
                if path not in spread:
                    spread[path] = {}
                    order.append(path)
                colval = row.get(column_field) if column_field else None
                if column_field and colval not in seen_set:
                    seen_set.add(colval)
                    seen_values.append(colval)
                spread[path][colval] = {lbl: row.get(lbl) for lbl in metric_labels}

            if column_field:
                total_rows = self._run_grouped_metrics_query(
                    template.dataset_id, prefix, metric_specs, filters, sort, force,
                )
                total = {
                    tuple(row.get(d) for d in prefix): {lbl: row.get(lbl) for lbl in metric_labels}
                    for row in total_rows
                }
            else:
                total = {path: vals.get(None, {}) for path, vals in spread.items()}

            levels[depth] = {"spread": spread, "total": total, "order": order}

        if column_field:
            seen_values.sort(key=_dimension_sort_key)
            if getattr(template, "column_sort_direction", "asc") == "desc":
                seen_values.reverse()

        result["column_values"] = seen_values
        result["levels"] = levels
        return result

    # ------------------------------------------------------------------ #
    # Export                                                               #
    # ------------------------------------------------------------------ #

    @classmethod
    def _get_watermark_reader(cls) -> ImageReader | None:
        """Lazily load and cache the app's fixed watermark logo (not a
        per-template asset). Returns None if it can't be read, so callers can
        just skip drawing it rather than fail the whole export."""
        if cls._watermark_reader is False:
            try:
                cls._watermark_reader = ImageReader(str(cls._WATERMARK_PATH))
            except Exception:
                logger.warning("Failed to load watermark logo from %s", cls._WATERMARK_PATH, exc_info=True)
                cls._watermark_reader = None
        return cls._watermark_reader

    def _draw_watermark(self, c, page_w: float, page_h: float) -> None:
        """Draw the app logo centered on the page as a faded watermark,
        behind everything else drawn on this page."""
        reader = self._get_watermark_reader()
        if reader is None:
            return
        img_w, img_h = reader.getSize()
        target_w = page_w * 0.5
        target_h = target_w * (img_h / img_w)
        c.saveState()
        c.setFillAlpha(0.14)
        c.setStrokeAlpha(0.14)
        c.drawImage(
            reader,
            (page_w - target_w) / 2, (page_h - target_h) / 2,
            width=target_w, height=target_h,
            preserveAspectRatio=True, mask="auto",
        )
        c.restoreState()

    def _make_pdf_page_decorator(self, template, title_text: str, subtitle_text: str):
        """Build the onPage callback for page 1 only — draws the report header
        (logo + title + metadata bar + divider + filters line). Later pages get
        a separate, blank-header callback (see build_pdf) so the branding block
        isn't repeated on every page; the page-number footer is unaffected,
        since that's drawn separately by _NumberedCanvas on every page.
        title_text is the main (bold) heading, subtitle_text the smaller line
        below it — the flat/transaction path passes "Daily Transaction Details"
        / template.name, the Matrix path passes "METRICS REPORT" / template.name."""
        logo_reader = None
        if template.logo_url:
            try:
                logo_reader = ImageReader(BytesIO(self._read_logo_bytes(template.logo_url)))
            except Exception:
                logger.warning("Failed to add logo to PDF export for template %r (logo_url=%r)",
                               template.name, template.logo_url, exc_info=True)

        def _draw(c, doc):
            page_w, page_h = letter
            margin = 40
            logo_w, logo_h = 90, 32
            title_y = page_h - 30

            self._draw_watermark(c, page_w, page_h)

            # Logo is always pinned to the left, regardless of template.logo_position;
            # the title is centered on the page rather than tucked beside it
            if logo_reader:
                c.drawImage(logo_reader, margin, page_h - 40, width=logo_w, height=logo_h,
                            preserveAspectRatio=True, mask="auto")

            c.setFont("Helvetica-Bold", 16)
            c.setFillColor(REPORT_TEAL)
            c.drawCentredString(page_w / 2, title_y, title_text)

            c.setFont("Helvetica", 10)
            c.setFillColor(colors.HexColor("#555555"))
            c.drawCentredString(page_w / 2, title_y - 15, subtitle_text)

            # Divider right under the logo/title, then the details below it
            divider_y = page_h - 105
            c.setStrokeColor(REPORT_TEAL)
            c.setLineWidth(1.5)
            c.line(margin, divider_y, page_w - margin, divider_y)

            # Metadata bar — one row of 3 columns: Confidentiality / Company / Contact.
            # No icon image assets exist, so a small filled dot stands in for an icon
            # instead of a real pictogram (calendar/person/etc.) next to each label.
            meta_top = divider_y - 20
            col_w = (page_w - 2 * margin) / 3
            meta_fields = [
                ("Confidentiality", REPORT_CONFIDENTIALITY),
                ("Company", REPORT_COMPANY),
                ("Contact", REPORT_CONTACT),
            ]
            for ci, (label, value) in enumerate(meta_fields):
                x = margin + ci * col_w
                c.setFillColor(REPORT_TEAL)
                c.circle(x + 2, meta_top + 3, 2.5, fill=1, stroke=0)
                c.setFont("Helvetica-Bold", 9)
                c.drawString(x + 10, meta_top, label.upper())
                c.setFont("Helvetica", 10)
                c.setFillColor(colors.black)
                c.drawString(x + 10, meta_top - 12, value)

            # Filters applied to this report, if any
            filters_summary = self._format_filters_summary(template.filters)
            if filters_summary:
                c.setFont("Helvetica-Bold", 8)
                c.setFillColor(REPORT_TEAL)
                c.drawString(margin, meta_top - 32, "FILTERS:")
                c.setFont("Helvetica", 8)
                c.setFillColor(colors.black)
                c.drawString(margin + 45, meta_top - 32, filters_summary)

        return _draw

    def build_pdf(self, template, force: bool = False) -> bytes:
        template_type = getattr(template, "template_type", "transaction")
        if template_type == "metrics":
            return self._build_metrics_pdf(template, force=force)
        if template_type == "heatmap":
            return self._build_metrics_pdf(template, force=force, heatmap=True)
        if template_type == "grouped":
            return self._build_grouped_pdf(template, force=force)

        import time as _time
        t0 = _time.perf_counter()
        rows = self.query_superset_dataset(
            template.dataset_id, template.columns, template.filters, force=force
        )
        headers = template.columns or (list(rows[0].keys()) if rows else [])
        logger.info("Superset data fetch: %.1fs (%d rows)", _time.perf_counter() - t0, len(rows))
        buffer = BytesIO()

        # The branded header (logo/title/metadata bar/filters) is only drawn on
        # page 1 — later pages use a shorter top margin and a blank onPage
        # callback so the block isn't repeated on every page. Page numbers are
        # unaffected: _NumberedCanvas draws those separately on every page.
        page_w, page_h = letter
        left_margin, right_margin, bottom_margin = 40, 40, 55
        first_top_margin, later_top_margin = 170, 45
        doc = BaseDocTemplate(
            buffer, pagesize=letter, title=template.name,
            leftMargin=left_margin, rightMargin=right_margin,
            topMargin=first_top_margin, bottomMargin=bottom_margin,
        )
        first_frame = Frame(
            left_margin, bottom_margin,
            page_w - left_margin - right_margin, page_h - first_top_margin - bottom_margin,
            id="first",
        )
        later_frame = Frame(
            left_margin, bottom_margin,
            page_w - left_margin - right_margin, page_h - later_top_margin - bottom_margin,
            id="later",
        )
        doc.addPageTemplates([
            PageTemplate(id="First", frames=[first_frame], onPage=self._make_pdf_page_decorator(
                template, title_text="Daily Transaction Details", subtitle_text=template.name,
            )),
            PageTemplate(id="Later", frames=[later_frame],
                         onPage=lambda c, d: self._draw_watermark(c, *letter)),
        ])

        story = [NextPageTemplate("Later")]
        display_headers = headers
        col_count = max(1, len(display_headers))

        # doc.width is page_width - leftMargin - rightMargin; subtract 12 for 6pt
        # frame padding on each side so the table never overflows the page edge
        usable_width = doc.width - 12
        col_widths = [usable_width / col_count] * col_count

        font_size = 7 if col_count > 6 else 8
        cell_style = ParagraphStyle(
            'TableCell',
            fontName='Helvetica',
            fontSize=font_size,
            leading=font_size + 2,
            wordWrap='LTR',
        )
        header_cell_style = ParagraphStyle(
            'TableHeader',
            fontName='Helvetica-Bold',
            fontSize=font_size,
            leading=font_size + 2,
            textColor=colors.whitesmoke,
            wordWrap='LTR',
        )
        total_cell_style = ParagraphStyle(
            'TableTotal',
            fontName='Helvetica-Bold',
            fontSize=font_size,
            leading=font_size + 2,
            textColor=colors.HexColor("#277777"),
            wordWrap='LTR',
        )

        style_commands = [
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#277777")),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("ALIGN", (0, 0), (-1, -1), "LEFT"),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.whitesmoke, colors.white]),
        ]

        column_formats = getattr(template, "column_formats", None) or {}
        table_data = [
            [Paragraph(h, header_cell_style) for h in display_headers]
        ] + [
            [
                Paragraph(self._format_pdf_cell(row.get(h, ""), column_formats.get(h)), cell_style)
                for h in display_headers
            ]
            for row in rows
        ]

        totals_row = self._compute_totals_row(rows, display_headers, template.total_columns)
        if totals_row:
            total_cells = []
            for i, h in enumerate(display_headers):
                if h in totals_row:
                    val = totals_row[h]
                    text = self._format_currency(val, column_formats.get(h))
                    if text is None:
                        text = f"{val:,.0f}" if float(val).is_integer() else f"{val:,.2f}"
                else:
                    text = "Total" if i == 0 else ""
                total_cells.append(Paragraph(text, total_cell_style))
            table_data.append(total_cells)

        if totals_row:
            style_commands += [
                ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#D9E8E8")),
                ("LINEABOVE", (0, -1), (-1, -1), 1, colors.HexColor("#277777")),
            ]

        table = Table(table_data, repeatRows=1, colWidths=col_widths)
        table.setStyle(TableStyle(style_commands))
        story.append(table)
        t1 = _time.perf_counter()
        doc.build(story, canvasmaker=_NumberedCanvas)
        logger.info("ReportLab render: %.1fs", _time.perf_counter() - t1)
        return buffer.getvalue()

    def _build_metrics_pdf(self, template, force: bool = False, heatmap: bool = False) -> bytes:
        """Render a metrics template as a real Power BI Matrix-style PDF —
        same row hierarchy / pivoted-column layout as _build_metrics_excel
        (built from the same _fetch_metrics_matrix/_build_matrix_rows shared
        helpers) — one row-header column PER dimension, each visually merged
        down its own aggregate row and every descendant row nested beneath it
        by blanking the repeat (NOT ReportLab's real SPAN — a span running
        longer than one page raises a "too large" LayoutError; blanking gives
        the same look while staying splittable at any row boundary, same
        technique _build_grouped_pdf already relies on) — with a
        "METRICS REPORT" header matching the Matrix Excel export's
        convention. No expand/collapse in a static PDF, but bold subtotal
        rows and a Grand Total row are still present. When `heatmap=True`
        (template_type="heatmap"), leaf-row value cells are shaded by a teal
        color scale instead of zebra-striped, and the header reads
        "VALUE DISTRIBUTION BY PERIOD REPORT"."""
        import time as _time
        t0 = _time.perf_counter()
        matrix = self._fetch_metrics_matrix(template, force=force)
        logger.info("Metrics matrix fetch: %.1fs (%d dims, column_field=%r)",
                    _time.perf_counter() - t0, len(matrix["dims"]), matrix["column_field"])

        metric_labels = matrix["metric_labels"]
        if not metric_labels:
            raise HTTPException(status_code=400, detail="This metrics template has no metrics configured")

        dims = matrix["dims"]
        column_field = matrix["column_field"]
        column_values = matrix["column_values"]
        value_keys = self._matrix_value_keys(matrix)
        matrix_rows = self._build_matrix_rows(matrix)
        label_col_count = max(1, len(dims))
        dim_headers = [_humanize_dimension_label(d) for d in dims] if dims else ["Total"]
        col_count = label_col_count + len(value_keys)

        buffer = BytesIO()
        page_w, page_h = letter
        left_margin, right_margin, bottom_margin = 40, 40, 55
        first_top_margin, later_top_margin = 170, 45
        doc = BaseDocTemplate(
            buffer, pagesize=letter, title=template.name,
            leftMargin=left_margin, rightMargin=right_margin,
            topMargin=first_top_margin, bottomMargin=bottom_margin,
        )
        first_frame = Frame(
            left_margin, bottom_margin,
            page_w - left_margin - right_margin, page_h - first_top_margin - bottom_margin,
            id="first",
        )
        later_frame = Frame(
            left_margin, bottom_margin,
            page_w - left_margin - right_margin, page_h - later_top_margin - bottom_margin,
            id="later",
        )
        page_decorator = self._make_pdf_page_decorator(
            template,
            title_text="VALUE DISTRIBUTION BY PERIOD REPORT" if heatmap else "METRICS REPORT",
            subtitle_text=template.name,
        )
        doc.addPageTemplates([
            PageTemplate(id="First", frames=[first_frame], onPage=page_decorator),
            PageTemplate(id="Later", frames=[later_frame],
                         onPage=lambda c, d: self._draw_watermark(c, *letter)),
        ])

        usable_width = doc.width - 12
        font_size = 7 if col_count > 6 else 8
        label_style = ParagraphStyle('MxLabel', fontName='Helvetica', fontSize=font_size,
                                      leading=font_size + 2, wordWrap='LTR')
        label_bold_style = ParagraphStyle('MxLabelBold', fontName='Helvetica-Bold', fontSize=font_size,
                                           leading=font_size + 2, textColor=colors.HexColor("#277777"), wordWrap='LTR')
        label_grand_style = ParagraphStyle('MxLabelGrand', fontName='Helvetica-Bold', fontSize=font_size,
                                            leading=font_size + 2, textColor=colors.whitesmoke, wordWrap='LTR')
        cell_style = ParagraphStyle('MxCell', fontName='Helvetica', fontSize=font_size,
                                     leading=font_size + 2, wordWrap='LTR', alignment=2)
        cell_bold_style = ParagraphStyle('MxCellBold', fontName='Helvetica-Bold', fontSize=font_size,
                                          leading=font_size + 2, textColor=colors.HexColor("#277777"),
                                          wordWrap='LTR', alignment=2)
        cell_grand_style = ParagraphStyle('MxCellGrand', fontName='Helvetica-Bold', fontSize=font_size,
                                           leading=font_size + 2, textColor=colors.whitesmoke,
                                           wordWrap='LTR', alignment=2)
        header_style = ParagraphStyle('MxHeader', fontName='Helvetica-Bold', fontSize=font_size,
                                       leading=font_size + 2, textColor=colors.whitesmoke,
                                       wordWrap='LTR', alignment=1)

        span_commands = []
        if column_field:
            n_metrics = len(metric_labels)
            row1 = [""] * col_count
            row2 = [""] * col_count
            row3 = list(dim_headers) + [lbl for _, lbl in value_keys]
            if column_values:
                row1[label_col_count] = _humanize_dimension_label(column_field)
                span_commands.append((
                    "SPAN", (label_col_count, 0),
                    (label_col_count - 1 + len(column_values) * n_metrics, 0),
                ))
            group_labels = [_format_dimension_value(column_field, v) for v in column_values] + ["Total"]
            for gi, gl in enumerate(group_labels):
                col = label_col_count + gi * n_metrics
                row2[col] = gl
                if n_metrics > 1:
                    span_commands.append(("SPAN", (col, 1), (col + n_metrics - 1, 1)))
            table_data = [
                [Paragraph(c, header_style) if c else "" for c in row1],
                [Paragraph(c, header_style) if c else "" for c in row2],
                [Paragraph(c, header_style) for c in row3],
            ]
            header_row_count = 3
        else:
            row = list(dim_headers) + [lbl for _, lbl in value_keys]
            table_data = [[Paragraph(c, header_style) for c in row]]
            header_row_count = 1

        metric_formats = matrix.get("metric_formats", {})

        def _fmt(v, currency_code=None):
            if v is None:
                return ""
            if isinstance(v, (int, float)):
                if currency_code:
                    text = self._format_currency(v, currency_code)
                    if text is not None:
                        return text
                return f"{v:,.0f}" if float(v).is_integer() else f"{v:,.2f}"
            return str(v)

        style_commands = [
            ("BACKGROUND", (0, 0), (-1, header_row_count - 1), colors.HexColor("#277777")),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ] + span_commands

        heatmap_vmin, heatmap_vmax = self._heatmap_leaf_range(matrix_rows, value_keys) if heatmap else (None, None)

        zebra_toggle = 0
        for ri, row in enumerate(matrix_rows, start=header_row_count):
            kind = row["kind"]
            depth = max(0, row["depth"])
            if kind == "leaf":
                lstyle, vstyle = label_style, cell_style
            elif kind == "subtotal":
                lstyle, vstyle = label_bold_style, cell_bold_style
            else:
                lstyle, vstyle = label_grand_style, cell_grand_style

            cells = [
                Paragraph(row["label"], lstyle) if ci == depth else ""
                for ci in range(label_col_count)
            ]
            for key in value_keys:
                cells.append(Paragraph(_fmt(row["values"].get(key), metric_formats.get(key[1])), vstyle))
            table_data.append(cells)

            if kind == "subtotal":
                style_commands.append(("BACKGROUND", (0, ri), (-1, ri), colors.HexColor("#D9E8E8")))
            elif kind == "grand":
                style_commands.append(("BACKGROUND", (0, ri), (-1, ri), colors.HexColor("#277777")))
            elif kind == "leaf" and heatmap:
                for ci, key in enumerate(value_keys, start=label_col_count):
                    cell_hex = self._heatmap_color(row["values"].get(key), heatmap_vmin, heatmap_vmax)
                    style_commands.append(("BACKGROUND", (ci, ri), (ci, ri), colors.HexColor(f"#{cell_hex}")))
            elif zebra_toggle % 2 == 1:
                style_commands.append(("BACKGROUND", (0, ri), (-1, ri), colors.HexColor("#D9E8E8")))
            if kind == "leaf":
                zebra_toggle += 1

        # Blank every row of a merged label run except the first — a real
        # SPAN command would make ReportLab treat the whole run as one
        # unsplittable flowable, which raises a "too large ... on page N"
        # LayoutError once a run is longer than fits on a single page (e.g.
        # one Category shared by hundreds of Subcategory/Year rows) — same
        # reasoning _build_grouped_pdf already documents for its own merges.
        if label_col_count > 1:
            merge_spans = self._matrix_label_merge_spans(matrix_rows, len(dims))
            for merge_depth, spans in merge_spans.items():
                for start_index, span_length in spans:
                    if span_length <= 1:
                        continue
                    top = header_row_count + start_index
                    bottom = top + span_length - 1
                    for r in range(top + 1, bottom + 1):
                        table_data[r][merge_depth] = Paragraph("", label_style)

        col_widths = [usable_width / col_count] * col_count
        table = Table(table_data, repeatRows=header_row_count, colWidths=col_widths)
        table.setStyle(TableStyle(style_commands))

        story = [NextPageTemplate("Later"), table]
        t1 = _time.perf_counter()
        doc.build(story, canvasmaker=_NumberedCanvas)
        logger.info("ReportLab matrix render: %.1fs", _time.perf_counter() - t1)
        return buffer.getvalue()

    def _build_grouped_pdf(self, template, force: bool = False) -> bytes:
        """Render a 'grouped' template as a row-level PivotTable-style PDF —
        every underlying row stays its own row (no aggregation), grouped by
        `dimensions` via ReportLab's SPAN style command (in place of
        openpyxl's merge_cells), with a single Grand Total row pinned
        directly under the header — built from the same
        _fetch_grouped_rows/_compute_merge_spans helpers as the Excel export."""
        import time as _time
        t0 = _time.perf_counter()
        dims = template.dimensions or []
        rows = self._fetch_grouped_rows(template, force=force)
        headers = template.columns or (list(rows[0].keys()) if rows else [])
        logger.info("Grouped data fetch: %.1fs (%d rows)", _time.perf_counter() - t0, len(rows))
        buffer = BytesIO()

        page_w, page_h = letter
        left_margin, right_margin, bottom_margin = 40, 40, 55
        first_top_margin, later_top_margin = 170, 45
        doc = BaseDocTemplate(
            buffer, pagesize=letter, title=template.name,
            leftMargin=left_margin, rightMargin=right_margin,
            topMargin=first_top_margin, bottomMargin=bottom_margin,
        )
        first_frame = Frame(
            left_margin, bottom_margin,
            page_w - left_margin - right_margin, page_h - first_top_margin - bottom_margin,
            id="first",
        )
        later_frame = Frame(
            left_margin, bottom_margin,
            page_w - left_margin - right_margin, page_h - later_top_margin - bottom_margin,
            id="later",
        )
        doc.addPageTemplates([
            PageTemplate(id="First", frames=[first_frame], onPage=self._make_pdf_page_decorator(
                template, title_text="MATRIX REPORT", subtitle_text=template.name,
            )),
            PageTemplate(id="Later", frames=[later_frame],
                         onPage=lambda c, d: self._draw_watermark(c, *letter)),
        ])

        story = [NextPageTemplate("Later")]
        col_count = max(1, len(headers))
        usable_width = doc.width - 12
        col_widths = [usable_width / col_count] * col_count

        font_size = 7 if col_count > 6 else 8
        cell_style = ParagraphStyle('GrpCell', fontName='Helvetica', fontSize=font_size,
                                     leading=font_size + 2, wordWrap='LTR')
        header_cell_style = ParagraphStyle('GrpHeader', fontName='Helvetica-Bold', fontSize=font_size,
                                            leading=font_size + 2, textColor=colors.whitesmoke, wordWrap='LTR')
        total_cell_style = ParagraphStyle('GrpTotal', fontName='Helvetica-Bold', fontSize=font_size,
                                           leading=font_size + 2, textColor=colors.HexColor("#277777"), wordWrap='LTR')

        table_data = [[Paragraph(h, header_cell_style) for h in headers]]
        style_commands = [
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#277777")),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("ALIGN", (0, 0), (-1, -1), "LEFT"),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]

        column_formats = getattr(template, "column_formats", None) or {}

        # Grand Total row pinned directly under the header — matches the
        # Excel export's layout (and Excel's own PivotTable default).
        totals_row = self._compute_totals_row(rows, headers, template.total_columns)
        detail_start_idx = 1
        if totals_row:
            total_cells = []
            for i, h in enumerate(headers):
                if h in totals_row:
                    val = totals_row[h]
                    text = self._format_currency(val, column_formats.get(h))
                    if text is None:
                        text = f"{val:,.0f}" if float(val).is_integer() else f"{val:,.2f}"
                else:
                    text = "Grand Total" if i == 0 else ""
                total_cells.append(Paragraph(text, total_cell_style))
            table_data.append(total_cells)
            style_commands.append(("BACKGROUND", (0, 1), (-1, 1), colors.HexColor("#D9E8E8")))
            style_commands.append(("LINEBELOW", (0, 1), (-1, 1), 1, colors.HexColor("#277777")))
            detail_start_idx = 2

        for ri, row in enumerate(rows):
            cells = [
                Paragraph(
                    self._format_pdf_cell(row.get(h), column_formats.get(h)) if row.get(h) is not None else "",
                    cell_style,
                )
                for h in headers
            ]
            table_data.append(cells)
            if ri % 2 == 1:
                table_row = detail_start_idx + ri
                style_commands.append(("BACKGROUND", (0, table_row), (-1, table_row), colors.HexColor("#D9E8E8")))

        # Blank every row of a merged span except the first — a real SPAN
        # style command (as used here previously) makes ReportLab treat the
        # whole spanned block as one unsplittable flowable, which blows up
        # with a "too large ... on page N" LayoutError as soon as a span runs
        # longer than fits on a single page (e.g. one dimension value shared
        # by hundreds/thousands of detail rows). Blanking without SPAN gives
        # the same merged look (no repeated label) while staying splittable
        # at any row boundary.
        merge_spans = self._compute_merge_spans(rows, dims)
        for dim in dims:
            if dim not in headers:
                continue
            ci = headers.index(dim)
            for start, length in merge_spans.get(dim, []):
                if length <= 1:
                    continue
                top = detail_start_idx + start
                bottom = top + length - 1
                for r in range(top + 1, bottom + 1):
                    table_data[r][ci] = Paragraph("", cell_style)

        table = Table(table_data, repeatRows=detail_start_idx, colWidths=col_widths)
        table.setStyle(TableStyle(style_commands))
        story.append(table)
        t1 = _time.perf_counter()
        doc.build(story, canvasmaker=_NumberedCanvas)
        logger.info("ReportLab grouped render: %.1fs", _time.perf_counter() - t1)
        return buffer.getvalue()

    def build_excel(self, template, force: bool = False) -> bytes:
        template_type = getattr(template, "template_type", "transaction")
        if template_type == "metrics":
            return self._build_metrics_excel(template, force=force)
        if template_type == "heatmap":
            return self._build_metrics_excel(template, force=force, heatmap=True)
        if template_type == "grouped":
            return self._build_grouped_excel(template, force=force)

        import time as _time
        t0 = _time.perf_counter()
        rows = self.query_superset_dataset(
            template.dataset_id, template.columns, template.filters, force=force
        )
        headers = template.columns or (list(rows[0].keys()) if rows else [])
        logger.info("Superset data fetch: %.1fs (%d rows)", _time.perf_counter() - t0, len(rows))
        workbook = Workbook()
        sheet = workbook.active
        sheet.title = template.name[:31]

        # Insert logo at top (if present) and choose anchor column based on position
        start_row = 1
        tmp_logo_path = None
        has_logo = False
        if template.logo_url:
            try:
                logo_bytes = self._read_logo_bytes(template.logo_url)
                logo_suffix = ".png"
                try:
                    parsed = urlparse(template.logo_url or "")
                    suffix = Path(parsed.path).suffix if parsed.path else ""
                    if not suffix:
                        suffix = Path(template.logo_url.lstrip("/")).suffix if template.logo_url else ""
                    logo_suffix = suffix or logo_suffix
                except Exception:
                    pass

                tmp = tempfile.NamedTemporaryFile(delete=False, suffix=logo_suffix)
                tmp.write(logo_bytes)
                tmp.flush()
                tmp.close()
                img = XLImage(tmp.name)
                # cap logo to a compact size suitable for a header area
                MAX_H, MAX_W = 60, 160
                try:
                    h = getattr(img, "height", None) or MAX_H
                    w = getattr(img, "width", None) or MAX_W
                    scale = min(MAX_H / h, MAX_W / w, 1.0)
                    img.height = int(h * scale)
                    img.width = int(w * scale)
                except Exception:
                    img.height, img.width = MAX_H, MAX_W

                # Logo is always pinned to the left (column A), regardless of
                # template.logo_position; the title is centered over the full
                # header width, not confined to the space after the logo
                sheet.add_image(img, "A1")
                tmp_logo_path = tmp.name
                has_logo = True

                img_h = getattr(img, "height", MAX_H)
                # Excel default row height ≈ 15pt; logo is 60px ≈ 45pt → ~3 rows + 1 gap
                rows_used = max(3, int(img_h / 15) + 1)
                start_row = rows_used + 2
            except Exception:
                logger.warning("Failed to add logo to Excel export for template %r (logo_url=%r)",
                               template.name, template.logo_url, exc_info=True)
                start_row = 1

        num_cols = max(1, len(headers))

        # Header chrome (title/divider/metadata) always matches the table's own
        # width exactly — never wider, even if that means a narrow table gives
        # the metadata bar less room and some long values wrap/clip.
        header_end_col = num_cols
        if has_logo:
            divider_row = start_row  # already reserved after the logo's row span
        else:
            divider_row = start_row + 3  # room for the 2-line merged title block + gap

        # Title — one single merged block spanning every row/column up to the
        # divider line (logo floats on top of it). Title + subtitle share this
        # one cell as two lines, since a merged cell can't mix two font sizes.
        title_cell = sheet.cell(row=1, column=1, value=f"Daily Transaction Details\n{template.name}")
        title_cell.font = Font(bold=True, size=14, color="277777")
        title_cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        title_cell.protection = UNLOCKED
        if divider_row > 1 or header_end_col > 1:
            sheet.merge_cells(start_row=1, start_column=1, end_row=divider_row - 1, end_column=header_end_col)

        # Divider right under the title/logo, then the details below it
        for ci in range(1, header_end_col + 1):
            divider_cell = sheet.cell(row=divider_row, column=ci)
            divider_cell.border = Border(top=Side(style="medium", color="277777"))
            divider_cell.protection = UNLOCKED

        # Metadata bar — one row of 3 side-by-side groups (label row + value row
        # per group), spread across header_end_col (not just num_cols) so a
        # narrow table still gives each field enough room. No icon image assets
        # exist, so a "•" bullet stands in for an icon next to each label.
        meta_label_font = Font(bold=True, size=9, color="277777")
        meta_value_font = Font(size=10, color="000000")
        meta_fields = [
            ("Confidentiality", REPORT_CONFIDENTIALITY),
            ("Company", REPORT_COMPANY),
            ("Contact", REPORT_CONTACT),
        ]
        meta_start_row = divider_row + 1
        # Only use a gap column between groups if there's actually room for one —
        # forcing a minimum group width regardless of header_end_col is exactly
        # what pushed the last group past the table's own width on narrow tables.
        GAP = 1 if header_end_col >= 3 * 2 + 2 else 0
        group_span = max(1, (header_end_col - 2 * GAP) // 3)
        col = 1
        for label, value in meta_fields:
            col_end = min(col + group_span - 1, header_end_col)
            label_cell = sheet.cell(row=meta_start_row, column=col, value=f"• {label.upper()}")
            label_cell.font = meta_label_font
            label_cell.protection = UNLOCKED
            value_cell = sheet.cell(row=meta_start_row + 1, column=col, value=value)
            value_cell.font = meta_value_font
            value_cell.protection = UNLOCKED
            if col_end > col:
                sheet.merge_cells(start_row=meta_start_row, start_column=col, end_row=meta_start_row, end_column=col_end)
                sheet.merge_cells(start_row=meta_start_row + 1, start_column=col, end_row=meta_start_row + 1, end_column=col_end)
            col = col_end + 1 + GAP
        sheet.row_dimensions[meta_start_row].height = 16
        sheet.row_dimensions[meta_start_row + 1].height = 16

        # Filters applied to this report, if any — skipped entirely (no blank
        # row wasted) when the template has no filters configured
        next_row = meta_start_row + 2
        filters_summary = self._format_filters_summary(template.filters)
        if filters_summary:
            filters_cell = sheet.cell(row=next_row, column=1, value=f"Filters: {filters_summary}")
            filters_cell.font = Font(size=8, color="000000")
            filters_cell.protection = UNLOCKED
            if header_end_col > 1:
                sheet.merge_cells(start_row=next_row, start_column=1, end_row=next_row, end_column=header_end_col)
            sheet.row_dimensions[next_row].height = 14
            next_row += 1

        start_row = next_row + 1

        # Footer — Excel only renders this in Print Preview / Page Layout view / when
        # printed, not in the normal grid view; &P/&N are Excel's page-number placeholders
        sheet.oddFooter.center.text = "Page &P of &N"

        header_fill = PatternFill(fill_type="solid", fgColor="277777")
        header_font = Font(bold=True, color="FFFFFF")
        header_align = Alignment(horizontal="center", vertical="center", wrap_text=True)
        zebra_fill = PatternFill(fill_type="solid", fgColor="D9E8E8")

        display_headers = headers
        # write headers and track max column width for auto-fit
        col_widths = {h: len(str(h)) for h in headers}

        for ci, h in enumerate(headers, start=1):
            cell = sheet.cell(row=start_row, column=ci, value=h)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_align
            cell.border = CELL_BORDER
            cell.protection = UNLOCKED

        # write data rows — keep numeric values numeric (right-aligned, summable
        # in Excel) instead of stringifying everything, and stripe alternate
        # rows for readability
        column_formats = getattr(template, "column_formats", None) or {}
        last_row = start_row
        for ri, row in enumerate(rows, start=start_row + 1):
            last_row = ri
            striped = (ri - start_row) % 2 == 0
            for ci, h in enumerate(headers, start=1):
                val = self._excel_cell_value(row.get(h, ""))
                cell = sheet.cell(row=ri, column=ci, value=val)
                cell.alignment = Alignment(
                    horizontal="right" if isinstance(val, (int, float)) else "left",
                    vertical="center", wrap_text=True,
                )
                cell.border = CELL_BORDER
                cell.protection = UNLOCKED
                self._apply_excel_currency_format(cell, val, column_formats.get(h))
                if striped:
                    cell.fill = zebra_fill
                col_widths[h] = max(col_widths[h], len(str(val)) if val is not None else 0)

        # Totals row — sums only the columns the user checked, "Total" label in column A
        totals_row = self._compute_totals_row(rows, headers, template.total_columns)
        if totals_row:
            total_row_idx = last_row + 1
            total_fill = PatternFill(fill_type="solid", fgColor="D9E8E8")
            total_font = Font(bold=True, color="277777")
            for ci, h in enumerate(headers, start=1):
                if h in totals_row:
                    cell_value = totals_row[h]
                else:
                    cell_value = "Total" if ci == 1 else ""
                cell = sheet.cell(row=total_row_idx, column=ci, value=cell_value)
                cell.font = total_font
                cell.fill = total_fill
                cell.border = CELL_BORDER
                cell.protection = UNLOCKED
                self._apply_excel_currency_format(cell, cell_value, column_formats.get(h))
                cell.alignment = Alignment(
                    horizontal="right" if isinstance(cell_value, (int, float)) else "left",
                    vertical="center", wrap_text=True,
                )
                col_widths[h] = max(col_widths[h], len(str(cell_value)))
            sheet.row_dimensions[total_row_idx].height = 20

        # auto-fit column widths (capped at 40 chars); +6 padding (vs +2) for extra column-to-column breathing room
        for ci, h in enumerate(display_headers, start=1):
            sheet.column_dimensions[get_column_letter(ci)].width = min(col_widths[h] + 6, 40)

        # set header row height, keep it visible while scrolling, with native Excel filter dropdowns
        sheet.row_dimensions[start_row].height = 20
        sheet.freeze_panes = sheet.cell(row=start_row + 1, column=1)
        if display_headers:
            sheet.auto_filter.ref = f"A{start_row}:{get_column_letter(len(display_headers))}{last_row}"

        if has_logo:
            _lock_logo_in_place(sheet)

        buffer = BytesIO()
        workbook.save(buffer)
        buffer.seek(0)
        # cleanup temporary logo file
        try:
            if tmp_logo_path:
                Path(tmp_logo_path).unlink(missing_ok=True)
        except Exception:
            pass
        return buffer.getvalue()

    # ------------------------------------------------------------------ #
    # Metrics matrix export (Excel only)                                   #
    # ------------------------------------------------------------------ #

    def _write_matrix_header_block(
        self, sheet, template, num_cols: int, title_text: str = "METRICS REPORT"
    ) -> tuple[int, str | None, bool]:
        """Write the branded header block for a Matrix-style worksheet — logo
        left, `title_text` centered with the template name as the subtitle
        (title/subtitle swapped vs. the flat export, per the Matrix worksheet
        spec), a teal divider, and the Confidentiality/Company/Contact bar.
        Shared by the legacy aggregated-pivot export ('METRICS REPORT',
        template_type="metrics", new creation now disabled — see
        TemplateService.create) and the grouped export ('MATRIX REPORT',
        template_type="grouped" — the user-facing "Matrix" template today) —
        same chrome, different title text. Returns
        (first free row below the block, temp logo file to clean up, whether a
        logo was placed — sheet-protection lock must be applied by the caller
        only AFTER every other cell is written, or those cells would be left
        locked by the sheet-wide protection flag the lock turns on)."""
        start_row = 1
        tmp_logo_path = None
        has_logo = False
        if template.logo_url:
            try:
                logo_bytes = self._read_logo_bytes(template.logo_url)
                logo_suffix = ".png"
                try:
                    parsed = urlparse(template.logo_url or "")
                    suffix = Path(parsed.path).suffix if parsed.path else ""
                    if not suffix:
                        suffix = Path(template.logo_url.lstrip("/")).suffix if template.logo_url else ""
                    logo_suffix = suffix or logo_suffix
                except Exception:
                    pass

                tmp = tempfile.NamedTemporaryFile(delete=False, suffix=logo_suffix)
                tmp.write(logo_bytes)
                tmp.flush()
                tmp.close()
                img = XLImage(tmp.name)
                MAX_H, MAX_W = 60, 160
                try:
                    h = getattr(img, "height", None) or MAX_H
                    w = getattr(img, "width", None) or MAX_W
                    scale = min(MAX_H / h, MAX_W / w, 1.0)
                    img.height = int(h * scale)
                    img.width = int(w * scale)
                except Exception:
                    img.height, img.width = MAX_H, MAX_W

                sheet.add_image(img, "A1")
                tmp_logo_path = tmp.name
                has_logo = True

                img_h = getattr(img, "height", MAX_H)
                rows_used = max(3, int(img_h / 15) + 1)
                start_row = rows_used + 2
            except Exception:
                logger.warning("Failed to add logo to Matrix Excel export for template %r (logo_url=%r)",
                               template.name, template.logo_url, exc_info=True)
                start_row = 1

        header_end_col = num_cols
        divider_row = start_row if has_logo else start_row + 3

        title_cell = sheet.cell(row=1, column=1, value=f"{title_text}\n{template.name}")
        title_cell.font = Font(bold=True, size=14, color="277777")
        title_cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        title_cell.protection = UNLOCKED
        if divider_row > 1 or header_end_col > 1:
            sheet.merge_cells(start_row=1, start_column=1, end_row=divider_row - 1, end_column=header_end_col)

        for ci in range(1, header_end_col + 1):
            divider_cell = sheet.cell(row=divider_row, column=ci)
            divider_cell.border = Border(top=Side(style="medium", color="277777"))
            divider_cell.protection = UNLOCKED

        meta_label_font = Font(bold=True, size=9, color="277777")
        meta_value_font = Font(size=10, color="000000")
        meta_fields = [
            ("Confidentiality", REPORT_CONFIDENTIALITY),
            ("Company", REPORT_COMPANY),
            ("Contact", REPORT_CONTACT),
        ]
        meta_start_row = divider_row + 1
        GAP = 1 if header_end_col >= 3 * 2 + 2 else 0
        group_span = max(1, (header_end_col - 2 * GAP) // 3)
        col = 1
        for label, value in meta_fields:
            col_end = min(col + group_span - 1, header_end_col)
            label_cell = sheet.cell(row=meta_start_row, column=col, value=f"• {label.upper()}")
            label_cell.font = meta_label_font
            label_cell.protection = UNLOCKED
            value_cell = sheet.cell(row=meta_start_row + 1, column=col, value=value)
            value_cell.font = meta_value_font
            value_cell.protection = UNLOCKED
            if col_end > col:
                sheet.merge_cells(start_row=meta_start_row, start_column=col, end_row=meta_start_row, end_column=col_end)
                sheet.merge_cells(start_row=meta_start_row + 1, start_column=col, end_row=meta_start_row + 1, end_column=col_end)
            col = col_end + 1 + GAP
        sheet.row_dimensions[meta_start_row].height = 16
        sheet.row_dimensions[meta_start_row + 1].height = 16

        next_row = meta_start_row + 2
        filters_summary = self._format_filters_summary(template.filters)
        if filters_summary:
            filters_cell = sheet.cell(row=next_row, column=1, value=f"Filters: {filters_summary}")
            filters_cell.font = Font(size=8, color="000000")
            filters_cell.protection = UNLOCKED
            if header_end_col > 1:
                sheet.merge_cells(start_row=next_row, start_column=1, end_row=next_row, end_column=header_end_col)
            sheet.row_dimensions[next_row].height = 14
            next_row += 1

        sheet.oddFooter.center.text = "Page &P of &N"

        return next_row + 1, tmp_logo_path, has_logo

    _HEATMAP_LOW = (0xD9, 0xE8, 0xE8)   # light teal — matches the app's existing zebra/subtotal shade
    _HEATMAP_HIGH = (0x27, 0x77, 0x77)  # dark teal — matches the app's existing header/grand-total shade

    @classmethod
    def _heatmap_leaf_range(cls, matrix_rows: list[dict[str, Any]], value_keys: list[tuple]) -> tuple[float | None, float | None]:
        """Min/max across every numeric leaf-row value — the color scale is
        computed once, globally, across all pivoted columns, so cell shade is
        comparable across the whole table rather than reset per row/column."""
        values = [
            v for row in matrix_rows if row["kind"] == "leaf"
            for v in (row["values"].get(key) for key in value_keys)
            if isinstance(v, (int, float))
        ]
        return (min(values), max(values)) if values else (None, None)

    @classmethod
    def _heatmap_color(cls, value: Any, vmin: float | None, vmax: float | None) -> str:
        """Hex color (no '#') interpolated between the light/dark teal
        endpoints by value's position in [vmin, vmax]. Falls back to the
        lightest shade when the value is missing or the range is degenerate."""
        if not isinstance(value, (int, float)) or vmin is None or vmax is None or vmax == vmin:
            return "".join(f"{c:02X}" for c in cls._HEATMAP_LOW)
        t = max(0.0, min(1.0, (value - vmin) / (vmax - vmin)))
        rgb = (
            round(cls._HEATMAP_LOW[i] + (cls._HEATMAP_HIGH[i] - cls._HEATMAP_LOW[i]) * t)
            for i in range(3)
        )
        return "".join(f"{c:02X}" for c in rgb)

    def _matrix_value_keys(self, matrix: dict[str, Any]) -> list[tuple[Any, str]]:
        """Ordered (pivot_value_or_None, metric_label) keys for every value
        column — pivot values first (each carrying every metric), then a
        trailing "Total" group (pivot_value=None) when a column pivot is
        configured; just the metrics themselves, keyed by None, otherwise."""
        column_field = matrix["column_field"]
        column_values = matrix["column_values"]
        metric_labels = matrix["metric_labels"]
        if column_field:
            return [(cv, lbl) for cv in column_values for lbl in metric_labels] + \
                   [(None, lbl) for lbl in metric_labels]
        return [(None, lbl) for lbl in metric_labels]

    def _build_matrix_rows(self, matrix: dict[str, Any]) -> list[dict[str, Any]]:
        """Flatten a fetched metrics matrix into a display-ready row list —
        one row per group (leaf or ancestor), each carrying its OWN aggregate
        values directly (a parent's own row IS its subtotal, matching how the
        live in-app preview already renders it — no separate blank header row
        or trailing "X Total" row), plus one final Grand Total row. Value keys
        match _matrix_value_keys: (pivot_value_or_None, metric_label)."""
        dims = matrix["dims"]
        metric_labels = matrix["metric_labels"]
        column_field = matrix["column_field"]
        column_values = matrix["column_values"]
        levels = matrix["levels"]
        num_dims = len(dims)

        def _values_for(path: tuple, depth: int) -> dict[tuple, Any]:
            level = levels[depth]
            spread = level["spread"].get(path, {})
            total = level["total"].get(path, {})
            out: dict[tuple, Any] = {}
            if column_field:
                for cv in column_values:
                    for lbl in metric_labels:
                        out[(cv, lbl)] = spread.get(cv, {}).get(lbl)
            for lbl in metric_labels:
                out[(None, lbl)] = total.get(lbl)
            return out

        if num_dims == 0:
            return [{"label": "Grand Total", "depth": 0, "kind": "grand",
                      "values": _values_for((), 0)}]

        rows: list[dict[str, Any]] = []

        def _emit(depth: int, path: tuple) -> None:
            kind = "leaf" if depth == num_dims else "subtotal"
            rows.append({
                "label": _format_dimension_value(dims[depth - 1], path[-1]),
                "depth": depth - 1, "kind": kind,
                "values": _values_for(path, depth),
            })
            if depth < num_dims:
                for child in levels[depth + 1]["order"]:
                    if child[:depth] == path:
                        _emit(depth + 1, child)

        for top in levels[1]["order"]:
            _emit(1, top)

        rows.append({"label": "Grand Total", "depth": 0, "kind": "grand",
                      "values": _values_for((), 0)})
        return rows

    @staticmethod
    def _matrix_label_merge_spans(matrix_rows: list[dict[str, Any]], num_dims: int) -> dict[int, list[tuple[int, int]]]:
        """One row-header column per dimension (matching the live in-app
        preview) needs each dimension's label cell to visually span its own
        aggregate row PLUS every descendant row underneath it — e.g. "Furniture"
        spans its own subtotal row and every Subcategory/Year row nested below,
        "Bookcases" spans just its own rows. `matrix_rows` is a depth-first
        preorder list (each node's row precedes its children's), so a span at
        depth `d` runs from a row with that depth up to (not including) the
        next row whose depth is <= d. The trailing Grand Total row (depth 0,
        kind "grand") is excluded — it's rendered as its own full-width row.
        Returns {depth: [(start_index, span_length), ...]} for every depth
        except the deepest (leaf values are one-per-row and never span)."""
        body_rows = [r for r in matrix_rows if r["kind"] != "grand"]
        n = len(body_rows)
        spans: dict[int, list[tuple[int, int]]] = {d: [] for d in range(max(0, num_dims - 1))}
        for d in spans:
            i = 0
            while i < n:
                if body_rows[i]["depth"] != d:
                    i += 1
                    continue
                j = i + 1
                while j < n and body_rows[j]["depth"] > d:
                    j += 1
                spans[d].append((i, j - i))
                i = j
        return spans

    def _build_metrics_excel(self, template, force: bool = False, heatmap: bool = False) -> bytes:
        """Render a metrics template as a real Power BI Matrix-style worksheet
        — one row-header column PER dimension (matching the live in-app
        preview), each merged vertically across its own aggregate row and
        every descendant row nested beneath it (e.g. "Furniture" spans its
        own subtotal row plus every Subcategory/Year row under it). If
        `column_field` is set, each metric becomes its own sub-column nested
        under every pivoted column value plus a trailing Total group;
        otherwise each metric is just its own column. When `heatmap=True`
        (template_type="heatmap"), leaf-row value cells are shaded by a teal
        color scale instead of zebra-striped, and the header reads
        "VALUE DISTRIBUTION BY PERIOD REPORT"."""
        import time as _time
        t0 = _time.perf_counter()
        matrix = self._fetch_metrics_matrix(template, force=force)
        logger.info("Metrics matrix fetch: %.1fs (%d dims, column_field=%r)",
                    _time.perf_counter() - t0, len(matrix["dims"]), matrix["column_field"])

        dims = matrix["dims"]
        metric_labels = matrix["metric_labels"]
        metric_formats = matrix.get("metric_formats", {})
        column_field = matrix["column_field"]
        column_values = matrix["column_values"]

        if not metric_labels:
            raise HTTPException(status_code=400, detail="This metrics template has no metrics configured")

        value_keys = self._matrix_value_keys(matrix)
        label_col_count = max(1, len(dims))
        dim_headers = [_humanize_dimension_label(d) for d in dims] if dims else ["Total"]
        value_col_start = label_col_count + 1
        num_cols = label_col_count + len(value_keys)
        header_row_count = 3 if column_field else 1

        workbook = Workbook()
        sheet = workbook.active
        sheet.title = template.name[:31]
        # A group's own row carries its aggregate and sits ABOVE its children
        # (not a trailing "X Total" row below them), so the outline summary
        # control belongs above the collapsible block, not below it.
        sheet.sheet_properties.outlinePr.summaryBelow = False

        start_row, tmp_logo_path, has_logo = self._write_matrix_header_block(
            sheet, template, num_cols,
            title_text="VALUE DISTRIBUTION BY PERIOD REPORT" if heatmap else "METRICS REPORT",
        )

        header_fill = PatternFill(fill_type="solid", fgColor="277777")
        header_font = Font(bold=True, color="FFFFFF")
        header_align = Alignment(horizontal="center", vertical="center", wrap_text=True)
        zebra_fill = PatternFill(fill_type="solid", fgColor="D9E8E8")
        subtotal_fill = PatternFill(fill_type="solid", fgColor="D9E8E8")
        subtotal_font = Font(bold=True, color="277777")
        grand_fill = PatternFill(fill_type="solid", fgColor="277777")
        grand_font = Font(bold=True, color="FFFFFF")

        def _header_cell(row, col, text):
            cell = sheet.cell(row=row, column=col, value=text)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_align
            cell.border = CELL_BORDER
            cell.protection = UNLOCKED
            return cell

        col_widths = {i: 0 for i in range(1, num_cols + 1)}
        for i, text in enumerate(dim_headers, start=1):
            col_widths[i] = len(str(text))

        if column_field:
            # Row 1: the pivot field's own name, spanning only the real pivot
            # value groups (not the trailing Total group). Row 2: each pivot
            # value (+ "Total"), spanning its metrics. Row 3: metric labels
            # alongside each dimension's own header.
            n_metrics = len(metric_labels)
            if column_values:
                _header_cell(start_row, value_col_start, _humanize_dimension_label(column_field))
                sheet.merge_cells(start_row=start_row, start_column=value_col_start,
                                   end_row=start_row, end_column=value_col_start - 1 + len(column_values) * n_metrics)
            for gi, cv in enumerate([_format_dimension_value(column_field, v) for v in column_values] + ["Total"]):
                col = value_col_start + gi * n_metrics
                _header_cell(start_row + 1, col, cv)
                if n_metrics > 1:
                    sheet.merge_cells(start_row=start_row + 1, start_column=col,
                                       end_row=start_row + 1, end_column=col + n_metrics - 1)
            for ci, (_, lbl) in enumerate(value_keys, start=value_col_start):
                _header_cell(start_row + 2, ci, lbl)
                col_widths[ci] = max(col_widths[ci], len(str(lbl)))
            for r in (start_row, start_row + 1):
                for ci in range(1, label_col_count + 1):
                    _header_cell(r, ci, "")
            for ci, text in enumerate(dim_headers, start=1):
                label_header_cell = _header_cell(start_row + 2, ci, text)
                label_header_cell.alignment = Alignment(horizontal="left", vertical="center")
            for r in (start_row, start_row + 1, start_row + 2):
                sheet.row_dimensions[r].height = 20
        else:
            for ci, (_, lbl) in enumerate(value_keys, start=value_col_start):
                _header_cell(start_row, ci, lbl)
                col_widths[ci] = max(col_widths[ci], len(str(lbl)))
            for ci, text in enumerate(dim_headers, start=1):
                label_header_cell = _header_cell(start_row, ci, text)
                label_header_cell.alignment = Alignment(horizontal="left", vertical="center")
            sheet.row_dimensions[start_row].height = 20

        data_start_row = start_row + header_row_count
        zebra_toggle = 0

        matrix_rows = self._build_matrix_rows(matrix)
        heatmap_vmin, heatmap_vmax = self._heatmap_leaf_range(matrix_rows, value_keys) if heatmap else (None, None)
        for ri, row in enumerate(matrix_rows, start=data_start_row):
            kind = row["kind"]
            depth = row["depth"]
            sheet.row_dimensions[ri].outlineLevel = max(0, depth)

            striped = False
            if kind == "leaf":
                striped = not heatmap and zebra_toggle % 2 == 1
                zebra_toggle += 1

            label_col = depth + 1
            for ci in range(1, label_col_count + 1):
                cell = sheet.cell(row=ri, column=ci, value=row["label"] if ci == label_col else None)
                cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
                cell.border = CELL_BORDER
                cell.protection = UNLOCKED
                if kind == "subtotal":
                    cell.font = subtotal_font
                    cell.fill = subtotal_fill
                elif kind == "grand":
                    cell.font = grand_font
                    cell.fill = grand_fill
                elif striped:
                    cell.fill = zebra_fill
            col_widths[label_col] = max(col_widths[label_col], len(str(row["label"])))

            for ci, key in enumerate(value_keys, start=value_col_start):
                val = self._excel_cell_value(row["values"].get(key))
                cell = sheet.cell(row=ri, column=ci, value=val)
                cell.border = CELL_BORDER
                cell.protection = UNLOCKED
                cell.alignment = Alignment(
                    horizontal="right" if isinstance(val, (int, float)) else "left", vertical="center",
                )
                self._apply_excel_currency_format(cell, val, metric_formats.get(key[1]))
                if kind == "subtotal":
                    cell.font = subtotal_font
                    cell.fill = subtotal_fill
                elif kind == "grand":
                    cell.font = grand_font
                    cell.fill = grand_fill
                elif kind == "leaf" and heatmap:
                    cell_hex = self._heatmap_color(row["values"].get(key), heatmap_vmin, heatmap_vmax)
                    cell.fill = PatternFill(fill_type="solid", fgColor=cell_hex)
                elif striped:
                    cell.fill = zebra_fill
                col_widths[ci] = max(col_widths[ci], len(str(val)) if val is not None else 0)

        # Merge each dimension's label cell vertically across its own row and
        # every descendant row nested beneath it, and let the Grand Total
        # label read as one block across the whole row-header area.
        if label_col_count > 1:
            merge_spans = self._matrix_label_merge_spans(matrix_rows, len(dims))
            for depth, spans in merge_spans.items():
                col = depth + 1
                for start_index, span_length in spans:
                    if span_length > 1:
                        top = data_start_row + start_index
                        bottom = top + span_length - 1
                        sheet.merge_cells(start_row=top, start_column=col, end_row=bottom, end_column=col)
            if matrix_rows and matrix_rows[-1]["kind"] == "grand":
                grand_row = data_start_row + len(matrix_rows) - 1
                sheet.merge_cells(start_row=grand_row, start_column=1, end_row=grand_row, end_column=label_col_count)

        last_row = data_start_row + len(matrix_rows) - 1
        for ci in range(1, num_cols + 1):
            sheet.column_dimensions[get_column_letter(ci)].width = min(col_widths[ci] + 6, 40)
        # Freeze the header rows only (no column freeze) — freezing column A
        # too would draw Excel's vertical freeze divider straight through the
        # merged logo/title block at the top, which looks like a stray line.
        sheet.freeze_panes = sheet.cell(row=data_start_row, column=1)
        sheet.auto_filter.ref = (
            f"A{start_row + header_row_count - 1}:{get_column_letter(num_cols)}{last_row}"
        )

        # Applied last (after every cell above got its own explicit UNLOCKED)
        # so sheet-wide protection only ever restricts moving/resizing the logo.
        if has_logo:
            _lock_logo_in_place(sheet)

        buffer = BytesIO()
        workbook.save(buffer)
        buffer.seek(0)
        try:
            if tmp_logo_path:
                Path(tmp_logo_path).unlink(missing_ok=True)
        except Exception:
            pass
        return buffer.getvalue()

    def _build_grouped_excel(self, template, force: bool = False) -> bytes:
        """Render a 'grouped' template as a row-level PivotTable-style
        worksheet — every underlying row stays its own row (no aggregation,
        unlike the Metrics Matrix export), grouped by `dimensions` via
        vertically merged cells on those leading columns, with a single
        Grand Total row (from `total_columns`) pinned directly under the
        header — matching Excel's own PivotTable 'Grand Total at top' layout."""
        import time as _time
        t0 = _time.perf_counter()
        dims = template.dimensions or []
        rows = self._fetch_grouped_rows(template, force=force)
        headers = template.columns or (list(rows[0].keys()) if rows else [])
        logger.info("Grouped data fetch: %.1fs (%d rows)", _time.perf_counter() - t0, len(rows))

        workbook = Workbook()
        sheet = workbook.active
        sheet.title = template.name[:31]

        num_cols = max(1, len(headers))
        start_row, tmp_logo_path, has_logo = self._write_matrix_header_block(
            sheet, template, num_cols, title_text="MATRIX REPORT"
        )

        header_fill = PatternFill(fill_type="solid", fgColor="277777")
        header_font = Font(bold=True, color="FFFFFF")
        header_align = Alignment(horizontal="center", vertical="center", wrap_text=True)
        zebra_fill = PatternFill(fill_type="solid", fgColor="D9E8E8")
        total_fill = PatternFill(fill_type="solid", fgColor="D9E8E8")
        total_font = Font(bold=True, color="277777")

        col_widths = {h: len(str(h)) for h in headers}

        for ci, h in enumerate(headers, start=1):
            cell = sheet.cell(row=start_row, column=ci, value=h)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_align
            cell.border = CELL_BORDER
            cell.protection = UNLOCKED
        sheet.row_dimensions[start_row].height = 20

        data_start_row = start_row + 1
        column_formats = getattr(template, "column_formats", None) or {}

        # Grand Total row pinned directly under the header (before the detail
        # rows) — matches Excel's own PivotTable default row-grand-total position.
        totals_row = self._compute_totals_row(rows, headers, template.total_columns)
        if totals_row:
            for ci, h in enumerate(headers, start=1):
                cell_value = totals_row[h] if h in totals_row else ("Grand Total" if ci == 1 else "")
                cell = sheet.cell(row=data_start_row, column=ci, value=cell_value)
                cell.font = total_font
                cell.fill = total_fill
                cell.border = CELL_BORDER
                cell.protection = UNLOCKED
                self._apply_excel_currency_format(cell, cell_value, column_formats.get(h))
                cell.alignment = Alignment(
                    horizontal="right" if isinstance(cell_value, (int, float)) else "left",
                    vertical="center", wrap_text=True,
                )
                col_widths[h] = max(col_widths[h], len(str(cell_value)))
            sheet.row_dimensions[data_start_row].height = 20
            data_start_row += 1

        zebra_toggle = 0
        for ri_offset, row in enumerate(rows):
            ri = data_start_row + ri_offset
            striped = zebra_toggle % 2 == 1
            zebra_toggle += 1
            for ci, h in enumerate(headers, start=1):
                val = self._excel_cell_value(row.get(h, ""))
                cell = sheet.cell(row=ri, column=ci, value=val)
                cell.border = CELL_BORDER
                cell.protection = UNLOCKED
                cell.alignment = Alignment(
                    horizontal="right" if isinstance(val, (int, float)) else "left",
                    vertical="center", wrap_text=True,
                )
                self._apply_excel_currency_format(cell, val, column_formats.get(h))
                if striped:
                    cell.fill = zebra_fill
                col_widths[h] = max(col_widths[h], len(str(val)) if val is not None else 0)

        # Merge each dimension column's runs — only the group columns are
        # merged; detail columns (Billgo Payment Id, dollar amounts, etc.)
        # stay per-row, matching the screenshot's layout.
        merge_spans = self._compute_merge_spans(rows, dims)
        for dim in dims:
            if dim not in headers:
                continue
            ci = headers.index(dim) + 1
            for start, length in merge_spans.get(dim, []):
                if length <= 1:
                    continue
                top_row = data_start_row + start
                bottom_row = top_row + length - 1
                sheet.merge_cells(start_row=top_row, start_column=ci, end_row=bottom_row, end_column=ci)
                sheet.cell(row=top_row, column=ci).alignment = Alignment(
                    horizontal="left", vertical="center", wrap_text=True,
                )

        last_row = data_start_row + len(rows) - 1 if rows else data_start_row - 1

        for ci, h in enumerate(headers, start=1):
            sheet.column_dimensions[get_column_letter(ci)].width = min(col_widths[h] + 6, 40)

        # Freeze the header AND the Grand Total row so both stay visible while
        # scrolling through the merged detail rows below.
        sheet.freeze_panes = sheet.cell(row=data_start_row, column=1)
        if headers:
            sheet.auto_filter.ref = f"A{start_row}:{get_column_letter(len(headers))}{last_row}"

        if has_logo:
            _lock_logo_in_place(sheet)

        buffer = BytesIO()
        workbook.save(buffer)
        buffer.seek(0)
        try:
            if tmp_logo_path:
                Path(tmp_logo_path).unlink(missing_ok=True)
        except Exception:
            pass
        return buffer.getvalue()

    # ------------------------------------------------------------------ #
    # Logo reader                                                          #
    # ------------------------------------------------------------------ #

    def _read_default_dashboard_logo_bytes(self) -> bytes | None:
        try:
            return DEFAULT_DASHBOARD_LOGO_PATH.read_bytes()
        except Exception:
            logger.warning("Default dashboard logo not found at %s", DEFAULT_DASHBOARD_LOGO_PATH)
            return None

    def _read_logo_bytes(self, logo_url: str) -> bytes:
        if not logo_url:
            raise FileNotFoundError("No logo URL was provided")

        candidate = self._resolve_logo_path(logo_url)
        if candidate and candidate.exists():
            return candidate.read_bytes()

        if logo_url.startswith(("http://", "https://")):
            response = requests.get(logo_url, timeout=20)
            response.raise_for_status()
            return response.content

        raise FileNotFoundError(f"Logo file not found: {logo_url}")

    def _resolve_logo_path(self, logo_url: str) -> Path | None:
        if not logo_url:
            return None

        parsed = urlparse(logo_url)
        if parsed.scheme in {"http", "https"}:
            candidate = Path(parsed.path.lstrip("/"))
            if candidate.is_absolute() and candidate.exists():
                return candidate
            local_upload = UPLOADS_DIR / candidate.name
            if local_upload.exists():
                return local_upload
            return None

        candidate = Path(logo_url.lstrip("/"))
        if candidate.is_absolute():
            return candidate if candidate.exists() else None
        if candidate.exists():
            return candidate

        local_upload = UPLOADS_DIR / candidate.name
        if local_upload.exists():
            return local_upload
        return None

    # ------------------------------------------------------------------ #
    # Dashboard export                                                     #
    # ------------------------------------------------------------------ #

    @classmethod
    def _resolve_dashboard_id(cls, base_url: str, token: str, dashboard_uuid: str) -> tuple[int, str]:
        """
        Return (numeric_id, dashboard_title) for a dashboard UUID.

        Three strategies tried in order, result cached after first success:
          1. Direct path lookup GET /api/v1/dashboard/{uuid}  (Superset ≥ 1.4)
          2. List with explicit uuid column select             (avoids default field omission)
          3. List IDs, fetch each individually by numeric ID  (guaranteed but N+1 requests)
        """
        if dashboard_uuid in cls._dashboard_id_cache:
            return cls._dashboard_id_cache[dashboard_uuid]

        headers = {"Authorization": f"Bearer {token}"}
        page_size = 100

        def _cache_and_return(numeric_id: int, title: str) -> tuple[int, str]:
            result = (numeric_id, title)
            cls._dashboard_id_cache[dashboard_uuid] = result
            logger.info("Resolved dashboard UUID %s → id=%d", dashboard_uuid, numeric_id)
            return result

        # ── Strategy 1: direct path lookup ──────────────────────────────────
        resp = requests.get(
            f"{base_url}/api/v1/dashboard/{dashboard_uuid}",
            headers=headers, timeout=15, verify=False,
        )
        if resp.ok:
            meta = resp.json().get("result", {})
            return _cache_and_return(meta["id"], meta.get("dashboard_title", "Dashboard"))

        # ── Strategy 2: list with explicit select_columns for uuid ───────────
        # Superset omits the uuid field from the default list response;
        # requesting it explicitly works on most versions.
        page = 0
        while True:
            q = f"(page:{page},page_size:{page_size},select_columns:!(id,dashboard_title,uuid))"
            resp = requests.get(
                f"{base_url}/api/v1/dashboard/",
                headers=headers, params={"q": q}, timeout=15, verify=False,
            )
            if not resp.ok:
                logger.warning("Dashboard list (strategy 2) page %d → %s", page, resp.status_code)
                break
            items = resp.json().get("result", [])
            for item in items:
                if item.get("uuid") == dashboard_uuid:
                    return _cache_and_return(item["id"], item.get("dashboard_title", "Dashboard"))
            if len(items) < page_size:
                break
            page += 1

        # ── Strategy 3: list numeric IDs, fetch each individually ────────────
        # Slower (one request per dashboard) but doesn't depend on uuid being
        # returned by the list endpoint.
        page = 0
        while True:
            resp = requests.get(
                f"{base_url}/api/v1/dashboard/",
                headers=headers,
                params={"q": f"(page:{page},page_size:{page_size})"},
                timeout=15, verify=False,
            )
            if not resp.ok:
                logger.warning("Dashboard list (strategy 3) page %d → %s", page, resp.status_code)
                break
            items = resp.json().get("result", [])
            for item in items:
                dash_id = item.get("id")
                if not dash_id:
                    continue
                try:
                    detail = requests.get(
                        f"{base_url}/api/v1/dashboard/{dash_id}",
                        headers=headers, timeout=10, verify=False,
                    )
                    if detail.ok:
                        meta = detail.json().get("result", {})
                        if meta.get("uuid") == dashboard_uuid:
                            return _cache_and_return(dash_id, meta.get("dashboard_title", "Dashboard"))
                except requests.RequestException:
                    continue
            if len(items) < page_size:
                break
            page += 1

        raise HTTPException(
            status_code=502,
            detail=(
                f"Dashboard UUID '{dashboard_uuid}' not found after exhausting all lookup "
                "strategies. Check that the Superset admin account has 'can_read on Dashboard' "
                "permission and the UUID belongs to an existing, accessible dashboard."
            ),
        )

    def _create_guest_token(self, base_url: str, admin_token: str, dashboard_uuid: str) -> str:
        """
        Create a short-lived guest token scoped to a specific dashboard.
        The admin account may not have general 'can_read on Dashboard' permission,
        but it can create guest tokens — and a guest token grants full read access
        to the dashboard it is scoped to.
        """
        resp = requests.post(
            f"{base_url}/api/v1/security/guest_token/",
            headers={
                "Authorization": f"Bearer {admin_token}",
                "Content-Type": "application/json",
            },
            json={
                "resources": [{"type": "dashboard", "id": dashboard_uuid}],
                "rls": [],
                "user": {
                    "username": "export_service",
                    "first_name": "Export",
                    "last_name": "Service",
                },
            },
            timeout=15, verify=False,
        )
        if not resp.ok:
            raise HTTPException(
                status_code=502,
                detail=f"Failed to create guest token for dashboard {dashboard_uuid} "
                       f"({resp.status_code}): {resp.text[:200]}",
            )
        token = resp.json().get("token")
        if not token:
            raise HTTPException(status_code=502, detail="Guest token missing from Superset response")
        return token

    def _resolve_id_via_guest(
        self,
        base_url: str,
        admin_headers: dict,
        guest_headers: dict,
        dashboard_uuid: str,
    ) -> tuple[int, str]:
        """
        Resolve a dashboard UUID to (numeric_id, title).

        Strategies tried in order:
          0. Embedded-dashboard API  GET /api/v1/embedded/dashboard/{uuid}
             → returns {dashboard_id: N}.  This is the correct path when the UUID
               comes from Superset's "Embed" dialog (embedded_dashboards.uuid,
               which differs from dashboards.uuid).
          1. Direct path with admin token  (works if admin has can_read on Dashboard)
          2. Direct path with guest token  (works on Superset >= 3.0)
          3. List with guest token, Python UUID match
          4. List with admin token, Python UUID match
        """
        # ── Strategy 0: embedded-dashboard API ──────────────────────────────────
        # The UUID shown in Superset's "Embed" dialog is the embedded_dashboards.uuid.
        # GET /api/v1/embedded/dashboard/{uuid} maps it directly to the numeric ID.
        for label, hdrs in [("admin", admin_headers), ("guest", guest_headers)]:
            try:
                resp = requests.get(
                    f"{base_url}/api/v1/embedded/dashboard/{dashboard_uuid}",
                    headers=hdrs, timeout=15, verify=False,
                )
            except requests.RequestException:
                continue
            if resp.ok:
                num_id = resp.json().get("result", {}).get("dashboard_id")
                if num_id:
                    # Fetch title with guest token using the numeric ID
                    title = "Dashboard"
                    try:
                        t = requests.get(
                            f"{base_url}/api/v1/dashboard/{num_id}",
                            headers=guest_headers, timeout=15, verify=False,
                        )
                        if t.ok:
                            title = (
                                t.json().get("result", {})
                                .get("dashboard_title", "Dashboard")
                            )
                    except requests.RequestException:
                        pass
                    logger.info(
                        "Resolved embed UUID %s → dashboard_id=%d via embedded API (%s token)",
                        dashboard_uuid, num_id, label,
                    )
                    return num_id, title

        # ── Strategies 1 & 2: direct path (dashboard UUID as path param) ────────
        for label, hdrs in [("admin", admin_headers), ("guest", guest_headers)]:
            try:
                resp = requests.get(
                    f"{base_url}/api/v1/dashboard/{dashboard_uuid}",
                    headers=hdrs, timeout=15, verify=False,
                )
            except requests.RequestException:
                continue
            if resp.ok:
                meta = resp.json().get("result", {})
                logger.info(
                    "Resolved dashboard UUID %s via %s token (direct)", dashboard_uuid, label
                )
                return meta["id"], meta.get("dashboard_title", "Dashboard")

        # ── Strategies 3 & 4: paginated list, match UUID in Python ──────────────
        for label, hdrs in [("guest", guest_headers), ("admin", admin_headers)]:
            page, page_size = 0, 100
            while True:
                try:
                    resp = requests.get(
                        f"{base_url}/api/v1/dashboard/",
                        headers=hdrs,
                        params={"q": f"(page:{page},page_size:{page_size})"},
                        timeout=15, verify=False,
                    )
                except requests.RequestException:
                    break
                if not resp.ok:
                    logger.debug(
                        "Dashboard list with %s token page %d → %s",
                        label, page, resp.status_code,
                    )
                    break
                items = resp.json().get("result", [])
                for item in items:
                    if item.get("uuid") == dashboard_uuid:
                        logger.info(
                            "Resolved dashboard UUID %s via %s token (list scan)",
                            dashboard_uuid, label,
                        )
                        return item["id"], item.get("dashboard_title", "Dashboard")
                if len(items) < page_size:
                    break
                page += 1

        raise HTTPException(
            status_code=502,
            detail=(
                f"Dashboard UUID '{dashboard_uuid}' not found. "
                "Grant 'can_read on Dashboard' to the Superset admin account, "
                "or verify the UUID is correct."
            ),
        )

    def _find_charts_via_chart_api(
        self,
        base_url: str,
        admin_token: str,
        guest_token: str,
        dashboard_uuid: str,
        dashboard_numeric_id: int | None = None,
    ) -> tuple[list[dict], str]:
        """
        Scan the chart API to find charts that belong to the given dashboard.
        Accepts an optional numeric ID for faster/more reliable matching.
        Returns (chart_list, dashboard_title).
        """
        dashboard_title = "Dashboard"

        for label, token in [("admin", admin_token), ("guest", guest_token)]:
            headers = {"Authorization": f"Bearer {token}"}

            # ── Fast path: RelatedManyMany filter by numeric ID ───────────────
            if dashboard_numeric_id:
                try:
                    resp = requests.get(
                        f"{base_url}/api/v1/chart/",
                        headers=headers,
                        params={
                            "q": (
                                f"(filters:!((col:dashboards,opr:RelatedManyMany,"
                                f"val:!({dashboard_numeric_id}))),page_size:100)"
                            )
                        },
                        timeout=15, verify=False,
                    )
                    if resp.ok:
                        items = resp.json().get("result", [])
                        if items:
                            for item in items:
                                for dash in item.get("dashboards", []):
                                    if dash.get("id") == dashboard_numeric_id:
                                        dashboard_title = dash.get(
                                            "dashboard_title", dashboard_title
                                        )
                                        break
                            logger.info(
                                "Found %d charts for dashboard %s via RelatedManyMany (%s token)",
                                len(items), dashboard_uuid, label,
                            )
                            return items, dashboard_title
                except requests.RequestException:
                    pass

            # ── Filter by dashboard UUID (some Superset versions) ─────────────
            try:
                resp = requests.get(
                    f"{base_url}/api/v1/chart/",
                    headers=headers,
                    params={
                        "q": (
                            f"(filters:!((col:dashboards.uuid,opr:eq,"
                            f"val:'{dashboard_uuid}')),page_size:100)"
                        )
                    },
                    timeout=15, verify=False,
                )
                if resp.ok:
                    items = resp.json().get("result", [])
                    if items:
                        logger.info(
                            "Found %d charts for %s via uuid filter (%s token)",
                            len(items), dashboard_uuid, label,
                        )
                        return items, dashboard_title
            except requests.RequestException:
                pass

            # ── Full scan: page through all charts, match by id OR uuid ───────
            page, page_size = 0, 100
            matching: list[dict] = []
            while True:
                try:
                    resp = requests.get(
                        f"{base_url}/api/v1/chart/",
                        headers=headers,
                        params={"q": f"(page:{page},page_size:{page_size})"},
                        timeout=20, verify=False,
                    )
                except requests.RequestException:
                    break
                if not resp.ok:
                    logger.debug(
                        "Chart list (%s token) page %d → %s", label, page, resp.status_code
                    )
                    break
                items = resp.json().get("result", [])
                for item in items:
                    for dash in item.get("dashboards", []):
                        matched = (
                            dash.get("uuid") == dashboard_uuid
                            or (dashboard_numeric_id and dash.get("id") == dashboard_numeric_id)
                        )
                        if matched:
                            matching.append(item)
                            if dashboard_title == "Dashboard":
                                dashboard_title = dash.get("dashboard_title", dashboard_title)
                            break
                if len(items) < page_size:
                    break
                page += 1

            if matching:
                logger.info(
                    "Found %d charts for %s via full chart scan (%s token)",
                    len(matching), dashboard_uuid, label,
                )
                return matching, dashboard_title

        return [], dashboard_title

    def get_dashboard_charts_data(self, dashboard_uuid: str) -> tuple[str, list[dict]]:
        """
        Fetch data for every chart in a dashboard.
        Returns (dashboard_title, list of {title, headers, rows}).

        Resolution order:
          1. Resolve UUID → numeric ID (embedded API, direct path, list scan).
             If found, call GET /api/v1/dashboard/{id}/charts.
          2. If step 1 yields no charts, fall back to scanning the chart API
             (uses RelatedManyMany filter by numeric ID when available, then
             UUID filter, then full scan matching by id OR uuid).
        """
        base_url = settings.superset_base.rstrip("/")
        admin_token = self._superset_login(base_url)
        guest_token = self._create_guest_token(base_url, admin_token, dashboard_uuid)
        guest_headers = {"Authorization": f"Bearer {guest_token}"}
        admin_headers = {"Authorization": f"Bearer {admin_token}"}

        charts: list[dict] = []
        dashboard_title = "Dashboard"
        dashboard_numeric_id: int | None = None

        # ── Step 1: resolve numeric ID ────────────────────────────────────────
        if dashboard_uuid in self._dashboard_id_cache:
            dashboard_numeric_id, dashboard_title = self._dashboard_id_cache[dashboard_uuid]
        else:
            try:
                dashboard_numeric_id, dashboard_title = self._resolve_id_via_guest(
                    base_url, admin_headers, guest_headers, dashboard_uuid
                )
                self._dashboard_id_cache[dashboard_uuid] = (dashboard_numeric_id, dashboard_title)
            except HTTPException:
                logger.warning(
                    "Dashboard UUID resolution failed for %s — will rely on chart-API scan",
                    dashboard_uuid,
                )

        # ── Step 2: get chart list via dashboard endpoint (fastest) ───────────
        if dashboard_numeric_id:
            for hdrs in [guest_headers, admin_headers]:
                try:
                    r = requests.get(
                        f"{base_url}/api/v1/dashboard/{dashboard_numeric_id}/charts",
                        headers=hdrs, timeout=15, verify=False,
                    )
                    if r.ok:
                        charts = r.json().get("result", [])
                        if charts:
                            break
                except requests.RequestException:
                    pass

        # ── Step 3: chart-API scan (no dashboard permission required) ─────────
        if not charts:
            charts, dashboard_title = self._find_charts_via_chart_api(
                base_url, admin_token, guest_token,
                dashboard_uuid, dashboard_numeric_id,
            )

        if not charts:
            raise HTTPException(
                status_code=502,
                detail=(
                    f"No charts found for dashboard '{dashboard_uuid}'. "
                    "Grant 'can_read on Dashboard' to the Superset admin account, "
                    "or verify the UUID is correct."
                ),
            )

        # ── Step 4: fetch data per chart ──────────────────────────────────────
        charts_data = []
        for chart in charts:
            chart_id = chart.get("id")
            chart_title = chart.get("slice_name") or f"Chart {chart_id}"
            rows = self._fetch_chart_data(base_url, admin_token, chart_id)
            if rows:
                charts_data.append({
                    "title": chart_title,
                    "headers": list(rows[0].keys()),
                    "rows": rows,
                })

        logger.info(
            "Dashboard %s ('%s'): %d charts, %d with data",
            dashboard_uuid, dashboard_title, len(charts), len(charts_data),
        )
        return dashboard_title, charts_data

    def _fetch_chart_data(self, base_url: str, token: str, chart_id: int) -> list[dict]:
        """
        Get data for one chart.
        Primary: use the chart's saved query_context (preserves aggregations).
        Fallback: query the underlying datasource for raw rows.
        """
        import json as _json

        try:
            resp = requests.get(
                f"{base_url}/api/v1/chart/{chart_id}",
                headers={"Authorization": f"Bearer {token}"},
                timeout=15, verify=False,
            )
            if not resp.ok:
                return []
            chart_meta = resp.json().get("result", {})
        except requests.RequestException as exc:
            logger.warning("Chart %s metadata fetch failed: %s", chart_id, exc)
            return []

        # Primary: use query_context so we get exactly what the chart shows
        query_context_str = chart_meta.get("query_context")
        if query_context_str:
            try:
                query_context = _json.loads(query_context_str)
                query_context["result_format"] = "json"
                query_context["result_type"] = "full"
                resp = requests.post(
                    f"{base_url}/api/v1/chart/data",
                    headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                    json=query_context,
                    timeout=30, verify=False,
                )
                if resp.ok:
                    result = resp.json().get("result") or []
                    rows = result[0].get("data", []) if result else []
                    return self._convert_rows(rows)
            except Exception as exc:
                logger.warning("Chart %s query_context failed, falling back: %s", chart_id, exc)

        # Fallback: raw datasource query
        datasource_id = chart_meta.get("datasource_id")
        if not datasource_id:
            return []
        try:
            return self.query_superset_dataset(datasource_id)
        except Exception as exc:
            logger.warning("Chart %s datasource fallback failed: %s", chart_id, exc)
            return []

    def build_dashboard_pdf(self, dashboard_uuid: str) -> bytes:
        import time as _time
        t0 = _time.perf_counter()
        dashboard_title, charts_data = self.get_dashboard_charts_data(dashboard_uuid)
        logger.info("Dashboard data fetch: %.1fs (%d charts)", _time.perf_counter() - t0, len(charts_data))

        buffer = BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter, title=dashboard_title)
        styles = getSampleStyleSheet()
        story = []

        logo_bytes = self._read_default_dashboard_logo_bytes()
        if logo_bytes:
            try:
                logo_image = Image(BytesIO(logo_bytes), width=2.5 * inch, height=1.25 * inch)
                logo_image.hAlign = "CENTER"
                story.append(logo_image)
                story.append(Spacer(1, 0.2 * inch))
            except Exception:
                logger.warning("Failed to render default dashboard logo", exc_info=True)

        story.append(Paragraph(dashboard_title, styles["Title"]))
        story.append(Spacer(1, 0.3 * inch))

        if not charts_data:
            story.append(Paragraph("No data available for this dashboard.", styles["BodyText"]))
        else:
            for chart in charts_data:
                story.append(Paragraph(chart["title"], styles["Heading2"]))
                story.append(Spacer(1, 0.1 * inch))

                headers = chart["headers"]
                rows = chart["rows"]
                col_count = max(1, len(headers))
                usable_width = doc.width - 12
                col_widths = [usable_width / col_count] * col_count
                font_size = 7 if col_count > 6 else 8

                cell_style = ParagraphStyle(
                    f"DashCell_{chart['title'][:20]}",
                    fontName="Helvetica", fontSize=font_size, leading=font_size + 2,
                )
                header_style = ParagraphStyle(
                    f"DashHdr_{chart['title'][:20]}",
                    fontName="Helvetica-Bold", fontSize=font_size, leading=font_size + 2,
                    textColor=colors.whitesmoke,
                )

                table_data = [[Paragraph(h, header_style) for h in headers]]
                for row in rows:
                    table_data.append([Paragraph(str(row.get(h, "")), cell_style) for h in headers])

                table = Table(table_data, repeatRows=1, colWidths=col_widths)
                table.setStyle(TableStyle([
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#277777")),
                    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                    ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                    ("TOPPADDING", (0, 0), (-1, -1), 3),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.whitesmoke, colors.white]),
                ]))
                story.append(table)
                story.append(Spacer(1, 0.3 * inch))

        t1 = _time.perf_counter()
        watermark_page = lambda c, d: self._draw_watermark(c, *letter)
        doc.build(story, onFirstPage=watermark_page, onLaterPages=watermark_page)
        logger.info("Dashboard PDF render: %.1fs", _time.perf_counter() - t1)
        return buffer.getvalue()

    def build_dashboard_excel(self, dashboard_uuid: str) -> bytes:
        import time as _time
        t0 = _time.perf_counter()
        dashboard_title, charts_data = self.get_dashboard_charts_data(dashboard_uuid)
        logger.info("Dashboard data fetch: %.1fs (%d charts)", _time.perf_counter() - t0, len(charts_data))

        workbook = Workbook()
        ws = workbook.active
        ws.title = dashboard_title[:31]

        header_fill = PatternFill(fill_type="solid", fgColor="277777")
        header_font = Font(bold=True, color="FFFFFF")
        title_font = Font(bold=True, size=13)
        title_fill = PatternFill(fill_type="solid", fgColor="D9E8E8")
        zebra_fill = PatternFill(fill_type="solid", fgColor="D9E8E8")

        # Figure out how wide the KPI-row-then-tables layout actually ends up
        # (KPI charts side by side; everything else wraps to that same width),
        # BEFORE placing the logo, so centering uses the real layout width
        # instead of a single chart's own (much narrower) column count.
        GAP_COLS = 1
        kpi_charts, other_charts = [], []
        for chart in charts_data:
            target = kpi_charts if len(chart["headers"]) == 1 and len(chart["rows"]) <= 1 else other_charts
            target.append(chart)

        layout_total_cols = 0
        _col = 1
        for chart in kpi_charts:
            w = max(1, len(chart["headers"]))
            layout_total_cols = _col + w - 1
            _col += w + GAP_COLS
        if not layout_total_cols:
            layout_total_cols = max((len(c["headers"]) for c in charts_data), default=1)

        start_row = 1
        has_logo = False
        if DEFAULT_DASHBOARD_LOGO_PATH.exists():
            try:
                img = XLImage(str(DEFAULT_DASHBOARD_LOGO_PATH))
                MAX_H, MAX_W = 90, 260
                try:
                    h = getattr(img, "height", None) or MAX_H
                    w = getattr(img, "width", None) or MAX_W
                    scale = min(MAX_H / h, MAX_W / w, 1.0)
                    img.height = int(h * scale)
                    img.width = int(w * scale)
                except Exception:
                    img.height, img.width = MAX_H, MAX_W

                # Center the logo over the actual layout width. A fixed
                # average column pixel width is used rather than estimating
                # from content, since columns no longer line up 1:1 across
                # charts now that several sit side by side per row.
                AVG_COL_PX = 90
                total_px = layout_total_cols * AVG_COL_PX
                img_w = getattr(img, "width", MAX_W)
                left_px = max(0, (total_px - img_w) // 2)
                col_idx = min(layout_total_cols, max(1, left_px // AVG_COL_PX + 1))
                anchor = f"{get_column_letter(col_idx)}1"
                ws.add_image(img, anchor)
                has_logo = True

                img_h = getattr(img, "height", MAX_H)
                rows_used = max(3, int(img_h / 15) + 1)
                start_row = rows_used + 2
            except Exception:
                logger.warning("Failed to add default dashboard logo to Excel export", exc_info=True)
                start_row = 1

        if not charts_data:
            ws.cell(row=start_row, column=1, value="No data available for this dashboard.").protection = UNLOCKED
        else:
            def render_chart_table(chart, row_start, col_start):
                """Render one chart's title/header/data block at (row_start, col_start).
                Returns how many rows it used."""
                headers = chart["headers"]
                rows = chart["rows"]
                num_cols = max(1, len(headers))
                row = row_start

                # Chart title row (merged across this table's own columns)
                title_cell = ws.cell(row=row, column=col_start, value=chart["title"])
                title_cell.font = title_font
                title_cell.fill = title_fill
                title_cell.alignment = Alignment(horizontal="left", vertical="center")
                title_cell.border = CELL_BORDER
                title_cell.protection = UNLOCKED
                if num_cols > 1:
                    for ci in range(col_start + 1, col_start + num_cols):
                        extra_cell = ws.cell(row=row, column=ci)
                        extra_cell.border = CELL_BORDER
                        extra_cell.protection = UNLOCKED
                    ws.merge_cells(
                        start_row=row, start_column=col_start,
                        end_row=row, end_column=col_start + num_cols - 1,
                    )
                ws.row_dimensions[row].height = 20
                row += 1

                # Header row
                col_max_widths = {}
                for ci, h in enumerate(headers):
                    actual_col = col_start + ci
                    cell = ws.cell(row=row, column=actual_col, value=h)
                    cell.fill = header_fill
                    cell.font = header_font
                    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
                    cell.border = CELL_BORDER
                    cell.protection = UNLOCKED
                    col_max_widths[actual_col] = len(str(h))
                ws.row_dimensions[row].height = 18
                row += 1

                # Data rows — numeric values stay numeric (right-aligned, summable),
                # alternate rows get a light stripe for readability
                for ri, r in enumerate(rows):
                    striped = ri % 2 == 1
                    for ci, h in enumerate(headers):
                        actual_col = col_start + ci
                        val = self._excel_cell_value(r.get(h, ""))
                        cell = ws.cell(row=row, column=actual_col, value=val)
                        cell.alignment = Alignment(
                            horizontal="right" if isinstance(val, (int, float)) else "left",
                            vertical="center", wrap_text=True,
                        )
                        cell.border = CELL_BORDER
                        cell.protection = UNLOCKED
                        if striped:
                            cell.fill = zebra_fill
                        col_max_widths[actual_col] = max(
                            col_max_widths[actual_col], len(str(val)) if val is not None else 0
                        )
                    row += 1

                # Auto-fit column widths; +6 padding (vs +2) for extra column-to-column breathing room
                for actual_col, max_w in col_max_widths.items():
                    ws.column_dimensions[get_column_letter(actual_col)].width = min(max_w + 6, 40)

                return row - row_start

            # Single-value metrics (Total Revenue, Total Profit, ...) share one row,
            # laid out side by side (kpi_charts/other_charts/GAP_COLS computed
            # earlier alongside layout_total_cols, before the logo was placed).
            # Every other chart then flows left-to-right below that, packing as
            # many tables per row as fit within the same total width the KPI
            # row spans — wrapping to a new row once the next table would
            # overshoot that width — instead of one narrow table per row
            # leaving all the space up to the KPI row's edge empty.
            current_row = start_row
            if kpi_charts:
                col_start = 1
                rows_used = 0
                for chart in kpi_charts:
                    rows_used = max(rows_used, render_chart_table(chart, current_row, col_start))
                    col_start += max(1, len(chart["headers"])) + GAP_COLS
                current_row += rows_used + 1

            if not kpi_charts:
                # No KPI row to align to — fall back to one table per row.
                for chart in other_charts:
                    current_row += render_chart_table(chart, current_row, 1) + 1
            else:
                row_col = 1
                row_start = current_row
                row_height = 0
                for chart in other_charts:
                    chart_width = max(1, len(chart["headers"]))
                    if row_col > 1 and (row_col + chart_width - 1) > layout_total_cols:
                        current_row = row_start + row_height + 1
                        row_start = current_row
                        row_col = 1
                        row_height = 0
                    row_height = max(row_height, render_chart_table(chart, row_start, row_col))
                    row_col += chart_width + GAP_COLS
                current_row = row_start + row_height + 1

        if has_logo:
            _lock_logo_in_place(ws)

        buffer = BytesIO()
        workbook.save(buffer)
        return buffer.getvalue()

    def build_dashboard_image(self, dashboard_uuid: str, dashboard_id: int | None = None) -> bytes:
        """Return a full-page PNG screenshot of the dashboard (charts + layout),
        rendered by a headless browser we drive ourselves — a real rendered
        image of the dashboard as it looks in Superset, unlike
        build_dashboard_pdf/excel which re-render the underlying chart data
        into our own layout.

        Pass `dashboard_id` (the numeric ID) when already known, to skip
        UUID resolution entirely — useful when the admin lacks 'can_read
        on Dashboard'."""
        import time as _time
        t0 = _time.perf_counter()
        base = settings.superset_base.rstrip("/")
        token = self._superset_login(base)
        if dashboard_id is not None:
            numeric_id = dashboard_id
        else:
            numeric_id, _title = self._resolve_dashboard_id(base, token, dashboard_uuid)
        png_bytes = capture_dashboard_screenshot(base, token, numeric_id)
        logger.info(
            "Dashboard screenshot capture: %.1fs (id=%d, %d bytes)",
            _time.perf_counter() - t0, numeric_id, len(png_bytes),
        )
        return png_bytes