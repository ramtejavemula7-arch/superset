import json
import logging
import time
from typing import Any

import httpx
from fastapi import HTTPException
from google import genai
from google.genai import errors as genai_errors
from google.genai import types
from pydantic import ValidationError

from app.core.config import settings
from app.schemas.page_chat import AgentType, PageChatResponse
from app.services.vertex_ai_client import build_vertex_ai_client

logger = logging.getLogger(__name__)

_RATE_LIMIT_RETRIES = 3
_RATE_LIMIT_BACKOFF_SECONDS = 2

# Tool-calling round trips per _call_model invocation (each round is one
# generate_content call). Bounds a runaway loop if the model keeps calling
# tools without ever settling on a final answer. Needs real headroom, not
# just enough for the "happy path" — a round spent on an exploratory/dead-end
# tool call (e.g. a LIKE filter that matched nothing) still counts against
# this budget, and the model needs one round AFTER its last tool call just
# to write the final answer. Confirmed directly: 4 was too tight and caused
# real failures where the model got the correct number but ran out of
# rounds before it could report it.
_MAX_TOOL_ROUNDS = 8
_MAX_SAMPLE_ROWS = 5
_MAX_FILTER_ROWS = 50
_MAX_DISTINCT_VALUES = 50

_FILTER_OPS = {"==", "!=", ">", "<", ">=", "<=", "IN", "LIKE"}
_AGG_OPS = {"SUM", "AVG", "COUNT", "MIN", "MAX"}

_PAGE_CONFIG: dict[str, dict[str, str]] = {
    "dashboard": {"name": "Dashboard", "api_source": "this dashboard's own data API"},
    "reports": {"name": "Reports", "api_source": "the Reports page's own data API"},
    "transactions": {"name": "Transaction Search", "api_source": "the Transaction Search page's own data API"},
    "users": {"name": "Users", "api_source": "this page's own users API"},
    "roles": {"name": "Roles", "api_source": "this page's own roles API"},
}


class _MalformedPageChatResponse(Exception):
    pass


def _normalize_row(row: Any, columns: list[str] | None) -> Any:
    if not isinstance(row, dict):
        return row
    if columns:
        return [row.get(col) for col in columns]
    return list(row.values())


def _normalize_table_rows(payload: dict) -> dict:
    """Coerce object-shaped table rows (e.g. {"profit": 1200}) into the
    list[list[Any]] shape PageChatBlock requires, using "columns" for
    ordering when present. Models occasionally emit rows as objects despite
    instructions; this avoids failing the whole response over it.
    """
    for block in payload.get("blocks") or []:
        if not isinstance(block, dict) or block.get("type") != "table":
            continue
        rows = block.get("rows")
        if not isinstance(rows, list):
            continue
        columns = block.get("columns")
        block["rows"] = [_normalize_row(row, columns) for row in rows]
    return payload


def _charts_from_page_data(page_data: dict) -> dict[str, list[dict]] | None:
    """Return {chart_title: rows} for every table this service knows how to
    hand to the aggregate/list_distinct/filter_rows tools, else None (caller
    falls back to embedding page_data as raw JSON text unchanged — this
    service's exact behavior before these tools existed).

    Two shapes are recognized:
    - The real dashboard page shape: {"chartData": {"charts": [{"title":
      ..., "rows": [...]}]}} — a dashboard can have more than one chart/table,
      each independently queryable by its title.
    - A flat {"rows": [...]} shape (used by e.g. this module's own tests, and
      possibly simpler single-table pages) — treated as one unnamed table.
    """
    if not isinstance(page_data, dict):
        return None

    chart_data = page_data.get("chartData")
    charts = chart_data.get("charts") if isinstance(chart_data, dict) else None
    if isinstance(charts, list) and charts:
        result: dict[str, list[dict]] = {}
        for i, chart in enumerate(charts):
            if not isinstance(chart, dict):
                continue
            rows = chart.get("rows")
            if isinstance(rows, list) and (not rows or isinstance(rows[0], dict)):
                result[chart.get("title") or f"chart_{i}"] = rows
        if result:
            return result

    rows = page_data.get("rows")
    if isinstance(rows, list) and (not rows or isinstance(rows[0], dict)):
        return {"this page": rows}

    return None


def _resolve_chart_rows(charts: dict[str, list[dict]], chart: str | None = None) -> tuple[list[dict], str | None]:
    """Pick which chart's rows a tool call should operate on. Returns
    (rows, error_message) — rows is [] when error_message is set."""
    if chart:
        if chart in charts:
            return charts[chart], None
        for title, rows in charts.items():
            if title.lower() == chart.lower():
                return rows, None
        return [], f"unknown chart {chart!r}; available charts: {list(charts.keys())}"
    if len(charts) == 1:
        return next(iter(charts.values())), None
    return [], f"'chart' is required when there is more than one table on this page; available charts: {list(charts.keys())}"


def _row_matches(row: dict, col: str, op: str, val: Any) -> bool:
    cell = row.get(col)
    if op == "LIKE":
        # Models reach for SQL-style %wildcard% syntax (e.g. "%New York%")
        # even though this filter language has no wildcard grammar — strip
        # leading/trailing "%" rather than literal-matching them, or every
        # such call returns zero rows (confirmed directly: this caused a
        # real production failure where the model retried 3 more times
        # after an empty %New York% result, exhausting the tool-call limit
        # before ever reaching a final answer).
        if not isinstance(cell, str):
            return False
        pattern = str(val).strip("%")
        return pattern.lower() in cell.lower()
    if op == "IN":
        vals = val if isinstance(val, (list, tuple)) else [val]
        return any(_row_matches(row, col, "==", v) for v in vals)
    if isinstance(cell, str) and isinstance(val, str) and op in ("==", "!="):
        equal = cell.lower() == val.lower()
        return equal if op == "==" else not equal
    if op == "==":
        return cell == val
    if op == "!=":
        return cell != val
    if cell is None:
        return False
    try:
        cell_f, val_f = float(cell), float(val)
    except (TypeError, ValueError):
        return False
    if op == ">":
        return cell_f > val_f
    if op == "<":
        return cell_f < val_f
    if op == ">=":
        return cell_f >= val_f
    if op == "<=":
        return cell_f <= val_f
    return False


def _apply_filters(rows: list[dict], filters: list[dict] | None) -> list[dict]:
    """Filter `rows` by a small col/op/val mini-language — same vocabulary as
    Superset's dataset-query filters (app/api/routes/superset.py's
    ColumnFilter), so it's a shape the model is more likely to produce
    consistently. Unknown/malformed filter entries are skipped rather than
    erroring the whole tool call."""
    if not filters:
        return rows
    result = rows
    for f in filters:
        if not isinstance(f, dict):
            continue
        col, op, val = f.get("col"), f.get("op"), f.get("val")
        if not col or op not in _FILTER_OPS:
            continue
        result = [r for r in result if _row_matches(r, col, op, val)]
    return result


def _aggregate(
    charts: dict[str, list[dict]],
    operation: str,
    column: str | None = None,
    chart: str | None = None,
    filters: list[dict] | None = None,
) -> dict[str, Any]:
    """Deterministic SUM/AVG/COUNT/MIN/MAX over one chart's rows — computed
    in Python instead of asking the model to manually add up JSON text, which
    is both slow (latency scales with how many rows match) and unreliable
    (LLM arithmetic over many numbers is not guaranteed correct)."""
    rows, error = _resolve_chart_rows(charts, chart)
    if error:
        return {"error": error}
    matched = _apply_filters(rows, filters)
    op = (operation or "").upper()
    if op == "COUNT":
        return {"result": len(matched), "matched_rows": len(matched)}
    if op not in _AGG_OPS:
        return {"error": f"unsupported operation {operation!r}"}
    if not column:
        return {"error": "column is required for SUM/AVG/MIN/MAX"}

    raw_values = [r.get(column) for r in matched if r.get(column) not in (None, "")]
    numeric_values = []
    for v in raw_values:
        try:
            numeric_values.append(float(v))
        except (TypeError, ValueError):
            pass

    if op in ("SUM", "AVG"):
        if not numeric_values:
            return {
                "result": None,
                "matched_rows": len(matched),
                "note": f"no numeric values found for column {column!r} after filtering",
            }
        result = sum(numeric_values) if op == "SUM" else sum(numeric_values) / len(numeric_values)
    else:
        # MIN/MAX: numeric comparison when the column is numeric, otherwise
        # lexicographic — correctly handles ISO date strings (e.g.
        # order_date) and general text, not just numbers.
        if numeric_values:
            result = min(numeric_values) if op == "MIN" else max(numeric_values)
        elif raw_values:
            result = min(raw_values, key=str) if op == "MIN" else max(raw_values, key=str)
        else:
            return {
                "result": None,
                "matched_rows": len(matched),
                "note": f"no values found for column {column!r} after filtering",
            }

    if isinstance(result, float) and result.is_integer():
        result = int(result)
    return {"result": result, "matched_rows": len(matched)}


def _list_distinct(
    charts: dict[str, list[dict]],
    column: str,
    chart: str | None = None,
    filters: list[dict] | None = None,
) -> dict[str, Any]:
    """Deduplicated distinct values of `column` — guaranteed-correct dedup,
    rather than relying on the model to notice and remove duplicates itself.
    "count" is always the TRUE total even when "values" is capped/truncated,
    so "how many distinct X" stays exact regardless of column cardinality —
    only the returned sample list shrinks, keeping the function-response
    payload small for high-cardinality columns."""
    rows, error = _resolve_chart_rows(charts, chart)
    if error:
        return {"error": error}
    matched = _apply_filters(rows, filters)
    seen: set = set()
    values = []
    for r in matched:
        v = r.get(column)
        key = str(v)
        if key not in seen:
            seen.add(key)
            values.append(v)
    total = len(values)
    return {
        "values": values[:_MAX_DISTINCT_VALUES],
        "count": total,
        "truncated": total > _MAX_DISTINCT_VALUES,
    }


def _filter_rows_tool(
    charts: dict[str, list[dict]],
    chart: str | None = None,
    filters: list[dict] | None = None,
    limit: int | None = None,
) -> dict[str, Any]:
    """Matching rows (capped) — lets the model build a supporting `blocks`
    table without needing the full dataset in its own context."""
    rows, error = _resolve_chart_rows(charts, chart)
    if error:
        return {"error": error}
    matched = _apply_filters(rows, filters)
    capped_limit = min(int(limit) if limit else _MAX_FILTER_ROWS, _MAX_FILTER_ROWS)
    return {
        "rows": matched[:capped_limit],
        "total_matched": len(matched),
        "truncated": len(matched) > capped_limit,
    }


_TOOL_FUNCS = {
    "aggregate": _aggregate,
    "list_distinct": _list_distinct,
    "filter_rows": _filter_rows_tool,
}

_FILTER_SCHEMA = {
    "type": "object",
    "properties": {
        "col": {"type": "string"},
        "op": {"type": "string", "enum": sorted(_FILTER_OPS)},
        "val": {"description": "value to compare against; a list when op is IN"},
    },
    "required": ["col", "op", "val"],
}

_CHART_PARAM = {
    "type": "string",
    "description": (
        "Which table on this page to query, by its exact title. Optional when there is "
        "only one table on the page; required when there is more than one."
    ),
}

_TOOLS = [
    types.Tool(
        function_declarations=[
            types.FunctionDeclaration(
                name="aggregate",
                description=(
                    "Compute SUM/AVG/COUNT/MIN/MAX over ALL matching rows (not just the "
                    "sample shown in DATA_CONTEXT). ALWAYS use this for any counting/"
                    "summing/averaging/min/max question instead of reading rows yourself."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "operation": {"type": "string", "enum": sorted(_AGG_OPS)},
                        "column": {
                            "type": "string",
                            "description": "Column to aggregate; not needed for COUNT",
                        },
                        "chart": _CHART_PARAM,
                        "filters": {"type": "array", "items": _FILTER_SCHEMA},
                    },
                    "required": ["operation"],
                },
            ),
            types.FunctionDeclaration(
                name="list_distinct",
                description=(
                    "Distinct values of a column, already deduplicated. ALWAYS use this "
                    "for 'list the distinct X'/'how many distinct X' questions instead of "
                    "deduplicating the sample rows yourself. 'count' is always the exact "
                    "total number of distinct values. 'values' is capped at 50 entries — "
                    "if 'truncated' is true, 'values' is only a sample, so say e.g. '531 "
                    "distinct cities, including: ...' rather than implying 'values' is "
                    "the complete list."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "column": {"type": "string"},
                        "chart": _CHART_PARAM,
                        "filters": {"type": "array", "items": _FILTER_SCHEMA},
                    },
                    "required": ["column"],
                },
            ),
            types.FunctionDeclaration(
                name="filter_rows",
                description="Rows matching filters (capped), to build a supporting table block.",
                parameters={
                    "type": "object",
                    "properties": {
                        "chart": _CHART_PARAM,
                        "filters": {"type": "array", "items": _FILTER_SCHEMA},
                        "limit": {"type": "integer"},
                    },
                },
            ),
        ]
    )
]


def _build_system_prompt(agent_type: str, page_data: dict) -> str:
    config = _PAGE_CONFIG[agent_type]
    page_name = config["name"]
    api_source = config["api_source"]

    charts = _charts_from_page_data(page_data)
    if charts is not None:
        sections = []
        for title, rows in charts.items():
            columns = sorted({k for row in rows[:50] for k in row.keys()})
            sample = json.dumps(rows[:_MAX_SAMPLE_ROWS], default=str)
            sections.append(
                f'- "{title}": {len(rows)} total row(s). Columns: {", ".join(columns) or "(none)"}.\n'
                f"  Sample (shape/context ONLY, NOT the full dataset): {sample}"
            )
        chart_names = list(charts.keys())
        chart_hint = (
            f"passing chart={chart_names[0]!r}"
            if len(chart_names) == 1
            else f"passing chart as one of {chart_names}"
        )
        data_context = (
            f"This page has {len(charts)} table(s):\n" + "\n".join(sections) + "\n\n"
            "NEVER compute a count, sum, average, min/max, or distinct-values list by "
            "reading a sample above; each is truncated and manual arithmetic over it will "
            f"be wrong. Always call the aggregate/list_distinct/filter_rows tools instead "
            f"({chart_hint} — they run over every row of that table, not just its sample)."
        )
    else:
        data_context = json.dumps(page_data, default=str)

    return f"""CONTEXT
- You are the assistant embedded on the {page_name} page of this application.
- Your only source of truth is the DATA_CONTEXT block at the end of this prompt,
  which is the live response from this page's own API ({api_source}).
- You have no access to BigQuery, other pages' data, or any other data source, and
  no general knowledge about this company's actual numbers beyond DATA_CONTEXT.
- DATA_CONTEXT is row-level data: the same value (e.g. a city or country) can
  legitimately repeat across many rows.

CLARITY — what to do
- For greetings or small talk (e.g. "hi", "hello", "thanks") that contain no real
  question, reply with a short greeting only (e.g. "Hi! How can I help?") — do not
  describe your capabilities or the page's data unless actually asked.
- Answer the user's question using only facts present in DATA_CONTEXT.
- When asked to list the distinct values of a field (e.g. "list the cities",
  "what countries are there"), use the list_distinct tool if available — it is
  already deduplicated; otherwise deduplicate yourself so each distinct value
  appears exactly once in your answer, never once per row.
- Do not compute, estimate, or infer numbers beyond what DATA_CONTEXT directly
  supports (no averaging/extrapolating past what's actually shown) — use the
  aggregate tool if available for any count/sum/average/min/max question.
- Never mention SQL, databases, tools, or how the data was retrieved — to the
  user this is just "what's on the page."

CONSTRAINTS — hard rules
- If the answer is not present in DATA_CONTEXT, "message" must be exactly:
  "I can only answer questions about what's shown on this {page_name} page, and
  I don't see that here. Try asking the BigQuery assistant in the side nav for
  broader data." and "found_in_page_data" must be false.
- Output must be a single JSON object and nothing else — no markdown fences, no
  text before or after it — in exactly this shape:
  {{
    "message": "natural language answer",
    "found_in_page_data": true or false,
    "blocks": [ {{ "type": "text" or "table", "content": "...", "columns": [...], "rows": [...] }} ]
  }}
- "message" must always contain the full natural-language answer on its own.
- "blocks" is OPTIONAL and must contain ONLY content genuinely supplementary to
  "message" (e.g. a table backing up a claim already made in "message"). Never
  repeat "message"'s text inside a block; if nothing supplementary applies,
  "blocks" must be an empty array.
- For a "table" block, "rows" MUST be an array of arrays — one inner array per
  row, with cell values in the same order as "columns". NEVER an array of
  objects. Example for columns ["region", "profit"]:
  "rows": [["North", 1200], ["South", 900]] — NOT
  "rows": [{{"region": "North", "profit": 1200}}].
- A single aggregate value (e.g. a total) belongs in "message" as prose, not in
  a "blocks" table — use a table only for multi-row/multi-column data.
- Once every tool result you need has come back, your very next reply must be
  the final JSON object described above — never a further tool call, and
  never anything other than that one JSON object.

CALIBRATION — verify before you answer
- Every fact in "message" traces back to a specific value in DATA_CONTEXT (or
  a tool result computed from it).
- Any "list distinct values" answer contains no duplicate entries.
- The response is valid JSON matching the exact shape above, nothing else.

DATA_CONTEXT:
{data_context}
"""


class PageChatService:
    """Answers questions using ONLY the JSON data the calling page already
    fetched to render itself (page_data) — no BigQuery, no other data
    source. The model has nothing else in its context to draw on, so a
    question outside page_data is structurally unanswerable, not just
    discouraged by instruction. Single-turn/stateless from the caller's POV;
    internally may involve a few tool-call round trips (see _call_model).
    """

    def __init__(self) -> None:
        self._client: genai.Client | None = None

    def _get_client(self) -> genai.Client:
        if self._client is None:
            self._client = build_vertex_ai_client()
        return self._client

    def _call_model(
        self, system_instruction: str, question: str, charts: dict[str, list[dict]] | None = None
    ) -> PageChatResponse:
        client = self._get_client()
        # Tools are only offered when page_data matches a shape the compute
        # helpers above understand (_charts_from_page_data) — any other shape
        # falls back to exactly this service's pre-tools behavior (full JSON
        # embed, no tools, forced JSON response mode).
        tools = _TOOLS if charts is not None else None
        contents: list = [types.Content(role="user", parts=[types.Part(text=question)])]
        response = None

        for _round in range(_MAX_TOOL_ROUNDS):
            for attempt in range(_RATE_LIMIT_RETRIES + 1):
                try:
                    response = client.models.generate_content(
                        model=settings.gemini_chat_model,
                        contents=contents,
                        config=types.GenerateContentConfig(
                            system_instruction=system_instruction,
                            # Forcing JSON mime type silently disables function
                            # calling (verified directly against the live API) —
                            # only set it on the no-tools fallback path; the
                            # tool-enabled path relies on the prompt's own
                            # JSON-shape instructions for the final turn.
                            response_mime_type="application/json" if not tools else None,
                            tools=tools,
                            # Without an explicit timeout this call can hang indefinitely on a
                            # large page_data payload — the request thread blocks forever and the
                            # connection eventually just drops with no HTTP response at all rather
                            # than a clean error. HttpOptions.timeout is milliseconds.
                            http_options=types.HttpOptions(
                                timeout=int(settings.gemini_chat_timeout_seconds * 1000)
                            ),
                        ),
                    )
                    break
                except genai_errors.ClientError as exc:
                    if exc.code == 429 and attempt < _RATE_LIMIT_RETRIES:
                        delay = _RATE_LIMIT_BACKOFF_SECONDS * (2 ** attempt)
                        logger.warning(
                            "Gemini rate-limited (attempt %d/%d), retrying in %ds",
                            attempt + 1, _RATE_LIMIT_RETRIES, delay,
                        )
                        time.sleep(delay)
                        continue
                    status = 429 if exc.code == 429 else 502
                    raise HTTPException(status_code=status, detail=f"Page chat request failed: {exc}") from exc
                except httpx.TimeoutException as exc:
                    logger.error("Page chat request timed out after %.0fs", settings.gemini_chat_timeout_seconds)
                    raise HTTPException(
                        status_code=504,
                        detail=f"Page chat request timed out after {settings.gemini_chat_timeout_seconds:.0f}s",
                    ) from exc
                except Exception as exc:
                    raise HTTPException(status_code=502, detail=f"Page chat request failed: {exc}") from exc

            function_calls = getattr(response, "function_calls", None) or []
            if not function_calls:
                break

            contents.append(response.candidates[0].content)
            # The model can request several tools in one turn (e.g. "first and
            # last order date" -> MIN + MAX together, parallel function
            # calling) — the API requires every one of those function
            # responses to come back as PARTS of a SINGLE Content turn, not as
            # separate turns, or it 400s with "the number of function
            # response parts is equal to the number of function call parts"
            # (reproduced directly against the live API before this fix).
            response_parts = []
            for fc in function_calls:
                func = _TOOL_FUNCS.get(fc.name)
                if func is None:
                    result: dict[str, Any] = {"error": f"unknown tool {fc.name!r}"}
                else:
                    try:
                        result = func(charts, **(fc.args or {}))
                    except Exception as exc:
                        result = {"error": str(exc)}
                response_parts.append(types.Part.from_function_response(name=fc.name, response=result))
            contents.append(types.Content(role="user", parts=response_parts))
        else:
            raise HTTPException(
                status_code=502,
                detail="Page chat agent did not produce a final answer within the tool-call limit",
            )

        text = response.text
        if not text:
            raise HTTPException(status_code=502, detail="Page chat agent returned no answer")

        try:
            payload = json.loads(text)
        except json.JSONDecodeError as exc:
            raise _MalformedPageChatResponse(str(exc)) from exc

        if isinstance(payload, dict):
            payload = _normalize_table_rows(payload)

        try:
            return PageChatResponse.model_validate(payload)
        except ValidationError as exc:
            raise _MalformedPageChatResponse(str(exc)) from exc

    def ask(self, agent_type: AgentType, page_data: dict, question: str) -> PageChatResponse:
        if agent_type not in _PAGE_CONFIG:
            raise HTTPException(status_code=400, detail=f"Unknown agentType: {agent_type}")

        charts = _charts_from_page_data(page_data)
        prompt = _build_system_prompt(agent_type, page_data)

        try:
            return self._call_model(prompt, question, charts)
        except _MalformedPageChatResponse as exc:
            logger.warning("Page chat response failed schema validation, retrying once: %s", exc)

        retry_prompt = (
            prompt
            + "\n\nIMPORTANT: your previous response did not match the required JSON schema "
            "exactly. Respond again with ONLY a single valid JSON object in the exact shape "
            "specified above — no markdown, no extra text."
        )
        try:
            return self._call_model(retry_prompt, question, charts)
        except _MalformedPageChatResponse as exc:
            raise HTTPException(
                status_code=502,
                detail=f"Page chat agent returned malformed output after retry: {exc}",
            ) from exc
