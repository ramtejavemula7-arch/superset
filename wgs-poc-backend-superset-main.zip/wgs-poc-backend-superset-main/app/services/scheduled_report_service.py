import logging
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.models.scheduled_report import ScheduledReport
from app.schemas.scheduled_report import ScheduledReportCreate, ScheduledReportUpdate
from app.services.template_service import TemplateService
from app.utils.mailer import send_report_email

logger = logging.getLogger(__name__)


class ScheduledReportService:
    def __init__(self):
        self._template_service = TemplateService()

    # ------------------------------------------------------------------ #
    # CRUD                                                                 #
    # ------------------------------------------------------------------ #

    def get_all(self, db: Session) -> list[ScheduledReport]:
        return db.query(ScheduledReport).order_by(ScheduledReport.created_at.desc()).all()

    def get_by_id(self, db: Session, schedule_id: int) -> ScheduledReport | None:
        return db.query(ScheduledReport).filter(ScheduledReport.id == schedule_id).first()

    def create(self, db: Session, payload: ScheduledReportCreate) -> ScheduledReport:
        schedule = ScheduledReport(**payload.model_dump())
        db.add(schedule)
        db.commit()
        db.refresh(schedule)
        return schedule

    def update(self, db: Session, schedule_id: int, payload: ScheduledReportUpdate) -> ScheduledReport | None:
        schedule = self.get_by_id(db, schedule_id)
        if not schedule:
            return None
        for field, value in payload.model_dump(exclude_unset=True).items():
            setattr(schedule, field, value)
        db.commit()
        db.refresh(schedule)
        return schedule

    def delete(self, db: Session, schedule_id: int) -> bool:
        schedule = self.get_by_id(db, schedule_id)
        if not schedule:
            return False
        db.delete(schedule)
        db.commit()
        return True

    # ------------------------------------------------------------------ #
    # Sending                                                              #
    # ------------------------------------------------------------------ #

    def send_report(self, db: Session, schedule: ScheduledReport) -> None:
        """Build the template's PDF+Excel and email both to every recipient."""
        template = self._template_service.get_by_id(db, schedule.template_id)
        if not template:
            schedule.last_error = f"Template {schedule.template_id} not found"
            db.commit()
            return

        try:
            # force=True bypasses Superset's query cache so scheduled emails
            # always reflect the latest data, not a stale cached result.
            pdf_bytes = self._template_service.build_pdf(template, force=True)
            excel_bytes = self._template_service.build_excel(template, force=True)
        except Exception as exc:
            logger.exception("Scheduled report %s: failed to build attachments", schedule.id)
            schedule.last_error = f"Failed to build report: {exc}"
            db.commit()
            return

        filename_base = template.name.replace(" ", "_")
        attachments = [
            (pdf_bytes, f"{filename_base}.pdf", "application", "pdf"),
            (
                excel_bytes,
                f"{filename_base}.xlsx",
                "application",
                "vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ),
        ]

        subject = f"Scheduled report: {template.name}"
        body = f"Hi,\n\nPlease find the attached report of {template.name}."

        failed_recipients = []
        for recipient in schedule.recipients or []:
            if not send_report_email(recipient, subject, body, attachments):
                failed_recipients.append(recipient)

        schedule.last_sent_at = datetime.now(timezone.utc)
        schedule.last_error = f"Failed to send to: {', '.join(failed_recipients)}" if failed_recipients else None
        db.commit()

    def send_all_due(self, db: Session) -> None:
        """Send every active scheduled report — called once daily by the scheduler."""
        schedules = db.query(ScheduledReport).filter(ScheduledReport.is_active.is_(True)).all()
        logger.info("Scheduled report run: %d active schedule(s)", len(schedules))
        for schedule in schedules:
            self.send_report(db, schedule)
