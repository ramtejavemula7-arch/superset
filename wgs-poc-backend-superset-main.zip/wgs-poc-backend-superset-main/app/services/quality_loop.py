"""Synthesis quality loop — draft, critique, and refine the synthesized
answer before returning it, catching hallucinated citations and incomplete
answers. Ported from Tensor's `agents/synthesis_quality_loop.py`.

Gated by settings.quality_loop_enabled — assistant_service falls back to a
single direct synthesis call when it's off, or if anything here fails.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from pydantic import BaseModel

from app.core.config import settings
from app.services.synthesis_service import _SYNTHESIS_INSTRUCTION, synthesize_answer
from app.services.vertex_ai_client import build_vertex_ai_client

logger = logging.getLogger(__name__)


class CritiqueResult(BaseModel):
    passes: bool = False
    quality_score: float = 0.7
    citation_issues: list[str] = []
    completeness_issues: list[str] = []
    hallucination_issues: list[str] = []
    suggestions: list[str] = []


_CRITIC_INSTRUCTION = """You are an answer quality critic for an enterprise AI assistant.
Validate the answer against the provided source data.

CHECK EACH OF THESE:
1. Every 📊 citation must reference actual SQL data in the provided results. If the answer
   claims a number that doesn't appear in the data → FAIL.
2. Every 📎 citation must reference actual text from the provided document chunks. If a policy
   is quoted but not in the chunks → FAIL.
3. No hallucinated claims — every factual statement must be traceable to a source.
4. Answer must be complete — it should address all parts of the user's question.
5. Formatting must be clean (proper markdown, headers, bullet points).

Output JSON only:
{
  "passes": true/false,
  "citation_issues": ["list of specific citation problems"],
  "completeness_issues": ["list of missing parts"],
  "hallucination_issues": ["list of ungrounded claims"],
  "suggestions": ["specific improvements to make"],
  "quality_score": 0.0-1.0
}"""


def _build_critique_prompt(
    question: str,
    answer: str,
    sql_result: dict[str, Any] | None,
    rag_result: dict[str, Any] | None,
) -> str:
    parts = [f"## User Question\n{question}\n", f"## Answer to Validate\n{answer}\n"]
    if sql_result:
        parts.append("## SQL Source Data")
        if sql_result.get("answer"):
            parts.append(f"Answer: {sql_result['answer']}")
        if sql_result.get("sql"):
            parts.append(f"SQL: {sql_result['sql']}")
        if sql_result.get("rows"):
            parts.append(f"Rows: {json.dumps(sql_result['rows'][:10], default=str)}")
        parts.append("")
    if rag_result and rag_result.get("chunks"):
        parts.append("## Document Source Data")
        for i, chunk in enumerate(rag_result["chunks"][:5]):
            parts.append(f"Chunk {i + 1} (Score: {chunk.get('score', 0):.3f}, Source: {chunk.get('source', 'Unknown')})")
            parts.append(chunk.get("text", "")[:500])
        parts.append("")
    parts.append("Validate the answer against the source data above.")
    return "\n".join(parts)


def _build_refinement_prompt(
    question: str,
    answer: str,
    issues: list[str],
    suggestions: list[str],
    sql_result: dict[str, Any] | None,
    rag_result: dict[str, Any] | None,
) -> str:
    parts = [
        f"## User Question\n{question}\n",
        f"## Previous Answer (needs improvement)\n{answer}\n",
        "## Issues Found",
    ]
    parts.extend(f"- {issue}" for issue in issues)
    parts.append("\n## Suggestions")
    parts.extend(f"- {s}" for s in suggestions)
    if sql_result and sql_result.get("rows"):
        parts.append(f"\n## SQL Data\n{json.dumps(sql_result['rows'][:10], default=str)}")
    elif sql_result and sql_result.get("answer"):
        parts.append(f"\n## Query Summary\n{sql_result['answer']}")
    if rag_result and rag_result.get("chunks"):
        parts.append("\n## Document Chunks")
        for chunk in rag_result["chunks"][:3]:
            parts.append(f"- [{chunk.get('source', '')}]: {chunk.get('text', '')[:300]}")
    parts.append(
        "\n## Instructions\nGenerate an improved answer that fixes all the issues above. "
        "Ensure all citations are grounded in the actual source data."
    )
    return "\n".join(parts)


def synthesize_with_quality_loop(
    question: str,
    intent: str,
    sql_result: dict[str, Any] | None,
    rag_result: dict[str, Any] | None,
    conversation_context: str = "",
) -> tuple[str, float]:
    """Draft an answer with synthesis_service.synthesize_answer, then
    critique + refine it up to settings.quality_loop_max_iterations times.

    Returns (answer_text, quality_score). answer_text still carries the
    trailing FOLLOW_UPS/CONFIDENCE markers — callers should still run it
    through clean_synthesis/extract_confidence/extract_follow_ups as usual.
    """
    answer = synthesize_answer(question, intent, sql_result, rag_result, conversation_context)

    if not settings.quality_loop_enabled or settings.quality_loop_max_iterations < 1 or not answer:
        return answer, 0.7

    try:
        client = build_vertex_ai_client()
    except Exception as exc:
        logger.warning("Quality loop unavailable, skipping critique: %s", exc)
        return answer, 0.7

    from google.genai import types

    quality_score = 0.7
    for iteration in range(settings.quality_loop_max_iterations):
        try:
            critique_response = client.models.generate_content(
                model=settings.gemini_chat_model,
                contents=_build_critique_prompt(question, answer, sql_result, rag_result),
                config=types.GenerateContentConfig(
                    system_instruction=_CRITIC_INSTRUCTION,
                    temperature=0.0,
                    max_output_tokens=512,
                    response_mime_type="application/json",
                    response_schema=CritiqueResult,
                ),
            )
            critique = json.loads(critique_response.text or "{}")
        except Exception as exc:
            logger.warning("Synthesis critique failed on iteration %d: %s", iteration + 1, exc)
            break

        quality_score = critique.get("quality_score", quality_score)
        if critique.get("passes", False):
            return answer, quality_score

        issues = (
            critique.get("citation_issues", [])
            + critique.get("completeness_issues", [])
            + critique.get("hallucination_issues", [])
        )
        suggestions = critique.get("suggestions", [])
        if not issues and not suggestions:
            return answer, quality_score

        try:
            refine_response = client.models.generate_content(
                model=settings.gemini_chat_model,
                contents=_build_refinement_prompt(question, answer, issues, suggestions, sql_result, rag_result),
                config=types.GenerateContentConfig(
                    system_instruction=_SYNTHESIS_INSTRUCTION.format(conversation_context=""),
                    temperature=0.2,
                    max_output_tokens=1024,
                ),
            )
            if refine_response.text:
                answer = refine_response.text
        except Exception as exc:
            logger.warning("Synthesis refinement failed on iteration %d: %s", iteration + 1, exc)
            break

    return answer, quality_score
