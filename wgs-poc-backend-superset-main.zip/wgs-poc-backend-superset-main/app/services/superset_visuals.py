import logging

import requests
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
from playwright.sync_api import sync_playwright

from app.core.config import settings

logger = logging.getLogger(__name__)

_VIEWPORT = {"width": 1600, "height": 900}
_POST_LOAD_WAIT_MS = 5000  # let charts finish rendering after the page settles


def capture_dashboard_screenshot(
    base_url: str,
    token: str,
    dashboard_id: int,
    timeout_seconds: int = 240,
) -> bytes:
    """Take a full-page PNG screenshot of a Superset dashboard using Playwright.

    Logs into Superset's own web UI (a real Flask-AppBuilder form login,
    using the same admin credentials already configured for REST API
    access) so the headless browser gets a real session cookie, then
    navigates to the dashboard in standalone mode and captures the entire
    scrollable page.

    This intentionally bypasses Superset's server-side cache_dashboard_screenshot/
    Celery rendering path — that path clips at Superset's own configured
    WEBDRIVER_WINDOW viewport height, which is shorter than some dashboards'
    actual rendered height. Rendering here ourselves lets us capture the
    full page regardless of that server-side config.
    """
    if not settings.superset_user or not settings.superset_pass:
        raise RuntimeError("SUPERSET_USER/SUPERSET_PASS must be set to screenshot via Playwright")

    base_url = base_url.rstrip("/")
    timeout_ms = timeout_seconds * 1000

    resp = requests.get(
        f"{base_url}/api/v1/dashboard/{dashboard_id}",
        headers={"Authorization": f"Bearer {token}"},
        timeout=15,
        verify=False,
    )
    resp.raise_for_status()
    result = resp.json().get("result", {})
    slug = result.get("slug") or str(dashboard_id)
    dashboard_url = f"{base_url}/superset/dashboard/{slug}/?standalone=true"

    logger.info("Taking full-page screenshot of: %s", dashboard_url)

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(
                headless=True,
                args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu"],
            )
            try:
                context = browser.new_context(viewport=_VIEWPORT, ignore_https_errors=True)
                page = context.new_page()

                # Real form login (not a faked cookie) — Superset's dashboard
                # view checks the Flask-AppBuilder session, not the JWT bearer
                # token used for REST API calls above. Submit via Enter
                # rather than clicking the submit control directly — its
                # markup (input/button/themed component) varies by Superset
                # theme, but pressing Enter in the password field triggers
                # the same submit handlers regardless of markup.
                page.goto(f"{base_url}/login/", wait_until="networkidle", timeout=timeout_ms)
                page.fill("#username", settings.superset_user)
                page.fill("#password", settings.superset_pass)
                page.press("#password", "Enter")
                page.wait_for_load_state("networkidle", timeout=timeout_ms)

                if "/login" in page.url:
                    raise RuntimeError(
                        "Superset login did not redirect away from /login/ — "
                        "check SUPERSET_USER/SUPERSET_PASS credentials"
                    )

                page.goto(dashboard_url, wait_until="networkidle", timeout=timeout_ms)
                page.wait_for_timeout(_POST_LOAD_WAIT_MS)

                png_bytes = page.screenshot(full_page=True)
            finally:
                browser.close()
    except PlaywrightTimeoutError as exc:
        # The dashboard's own charts (e.g. BigQuery-backed ones) are still
        # loading when this fires — it's their query taking too long, not a
        # bug in the capture itself, so the message should read that way to
        # whoever ends up seeing job.error via the download endpoint's 500.
        raise TimeoutError(
            f"This dashboard is taking longer than usual to load (a chart's data source, e.g. "
            f"BigQuery, may be slow right now) and didn't finish within {timeout_seconds}s. "
            "Please try the export again in a moment."
        ) from exc

    logger.info(
        "Full-page screenshot captured for dashboard id=%d (%d bytes)", dashboard_id, len(png_bytes)
    )
    return png_bytes
