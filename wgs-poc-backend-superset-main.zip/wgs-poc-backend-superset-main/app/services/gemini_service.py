import logging
import re
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Any

from fastapi import HTTPException
from google.api_core.client_options import ClientOptions
from google.api_core.exceptions import DeadlineExceeded
from google.cloud import geminidataanalytics_v1 as gda
from google.oauth2 import service_account
from google.protobuf.json_format import MessageToDict
from pydantic import BaseModel

from app.core.config import settings
from app.services.chat_cache import get_tool_cache
from app.services.vertex_ai_client import build_vertex_ai_client

logger = logging.getLogger(__name__)

# {"project.dataset": (cached_at, table_context_str)} — avoids re-querying
# BigQuery's INFORMATION_SCHEMA on every single chat message.
_schema_cache: dict[str, tuple[float, str]] = {}

# (cached_at, agent_options) — avoids re-listing Data Agents across all 3
# regions (see DATA_AGENT_LOCATIONS) on every single Chat Assistant page load.
_data_agent_list_cache: tuple[float, list["DataAgentOption"]] | None = None


def _describe_exception(exc: Exception) -> str:
    """Build a detailed error string, surfacing whatever extra reason/
    permission/metadata a Google API error carries (e.g. exactly which IAM
    permission or resource is missing) instead of just the generic top-level
    message, which is often unhelpfully vague (e.g. "403 User does not have
    permission to chat")."""
    parts = [str(exc)]

    reason = getattr(exc, "reason", None)
    if reason:
        parts.append(f"reason={reason}")

    domain = getattr(exc, "domain", None)
    if domain:
        parts.append(f"domain={domain}")

    metadata = getattr(exc, "metadata", None)
    if metadata:
        parts.append(f"metadata={metadata}")

    details_fn = getattr(exc, "details", None)
    if callable(details_fn):
        try:
            extra_details = details_fn()
            if extra_details:
                parts.append(f"details={extra_details}")
        except Exception:
            pass

    return " | ".join(parts)


def _extract_table(data_block: dict) -> dict[str, Any] | None:
    """Pull a retrieved-data result (DataMessage.result) into a plain
    {columns, rows} shape the frontend can render as a table. Prefers
    `formattedData` (source-formatted strings, e.g. "$1,234.56") over raw
    `data`, matching what the Conversational Analytics API's own UI shows."""
    result = data_block.get("result")
    if not result:
        return None

    rows_source = result.get("formattedData") or result.get("data") or []
    fields = result.get("schema", {}).get("fields", [])
    if fields:
        columns = [f.get("name", "") for f in fields]
    elif rows_source:
        columns = list(rows_source[0].keys())
    else:
        return None

    rows = [[row.get(col) for col in columns] for row in rows_source]
    return {"columns": columns, "rows": rows}


def _parse_chat_chunks(
    chunks: list[Any],
) -> tuple[str, str | None, dict[str, Any] | None, dict[str, Any] | None]:
    """Extract the final answer text, generated SQL, retrieved data table,
    and chart spec from a Gemini Data Analytics chat response stream. Pure
    function, kept separate from the network call so it can be unit-tested
    with hand-built fake chunks. Returns (answer, sql, table, chart) — table
    is {"columns": [...], "rows": [[...], ...]} and chart is the Agent's raw
    Vega config, or None for either if the Agent didn't produce one."""
    answer_parts: list[str] = []
    sql_query: str | None = None
    table: dict[str, Any] | None = None
    chart: dict[str, Any] | None = None

    for chunk in chunks:
        chunk_dict = MessageToDict(chunk._pb) if hasattr(chunk, "_pb") else chunk
        sys_msg = chunk_dict.get("systemMessage", {})

        text_block = sys_msg.get("text", {})
        if text_block.get("textType") == "FINAL_RESPONSE":
            answer_parts.extend(text_block.get("parts", []))

        data_block = sys_msg.get("data", {})
        if "generatedSql" in data_block:
            sql_query = data_block["generatedSql"]
        extracted_table = _extract_table(data_block)
        if extracted_table:
            table = extracted_table

        vega_config = sys_msg.get("chart", {}).get("result", {}).get("vegaConfig")
        if vega_config:
            chart = vega_config

    return " ".join(answer_parts).strip(), sql_query, table, chart


def _detect_chart_type(columns: list[str], rows: list[dict[str, Any]]) -> dict[str, Any] | None:
    """Auto-detect a simple Vega-Lite chart spec from a SQL result's schema.
    Returns None when the shape doesn't suggest an obvious chart (frontend
    then just renders the `table`)."""
    if not rows:
        return None

    sample = rows[0]
    numeric_cols: list[str] = []
    string_cols: list[str] = []
    date_cols: list[str] = []

    for col in columns:
        val = sample.get(col)
        if isinstance(val, (int, float)) and not isinstance(val, bool):
            numeric_cols.append(col)
        elif isinstance(val, str):
            try:
                float(val)
                numeric_cols.append(col)
                continue
            except (ValueError, TypeError):
                pass
            if any(kw in col.lower() for kw in ("date", "time", "day", "month", "year", "quarter")):
                date_cols.append(col)
            else:
                string_cols.append(col)

    if not numeric_cols:
        return None

    data = {"values": rows}
    if date_cols:
        mark, x_field = "line", date_cols[0]
    elif string_cols and len(rows) <= 7:
        return {"mark": "arc", "encoding": {"theta": {"field": numeric_cols[0]}, "color": {"field": string_cols[0]}}, "data": data}
    elif string_cols:
        mark, x_field = "bar", string_cols[0]
    else:
        return None

    return {"mark": mark, "encoding": {"x": {"field": x_field}, "y": {"field": numeric_cols[0]}}, "data": data}


def _discover_dataset_schema(project_id: str, dataset_id: str) -> str:
    """Query BigQuery's own INFORMATION_SCHEMA for every table/column in
    this dataset and build a description string automatically — no manual
    column lists to keep in sync as tables change."""
    query = f"""
        SELECT table_name, column_name, data_type
        FROM `{project_id}.{dataset_id}.INFORMATION_SCHEMA.COLUMNS`
        ORDER BY table_name, ordinal_position
    """
    rows = _bigquery_client().query(query).result()

    tables: dict[str, list[str]] = {}
    for row in rows:
        tables.setdefault(row.table_name, []).append(f"{row.column_name} ({row.data_type})")

    return "\n".join(
        f"- `{project_id}.{dataset_id}.{table_name}`: columns: {', '.join(columns)}"
        for table_name, columns in tables.items()
    )


def _build_bigquery_table_context() -> str:
    """Table/column descriptions for the SQL generator and intent router —
    the schema is auto-discovered from each configured dataset's real
    BigQuery INFORMATION_SCHEMA (cached for
    settings.bigquery_schema_cache_ttl_seconds), plus any hand-written
    per-table notes from settings.bigquery_datasets_list."""
    now = time.time()
    sections = []
    for ds in settings.bigquery_datasets_list:
        project_id = ds.get("project_id", settings.google_cloud_project)
        dataset_id = ds.get("dataset_id", "")
        if not dataset_id:
            continue

        cache_key = f"{project_id}.{dataset_id}"
        cached = _schema_cache.get(cache_key)
        if cached and now - cached[0] < settings.bigquery_schema_cache_ttl_seconds:
            table_context = cached[1]
        else:
            try:
                table_context = _discover_dataset_schema(project_id, dataset_id)
                _schema_cache[cache_key] = (now, table_context)
            except Exception as exc:
                logger.error("BigQuery schema discovery failed for %s: %s", cache_key, exc)
                table_context = cached[1] if cached else ""

        if table_context:
            sections.append(table_context)

        for table_id, note in ds.get("table_notes", {}).items():
            sections.append(f"  Note on `{project_id}.{dataset_id}.{table_id}`: {note}")

    return "\n".join(sections)


def _bigquery_client():
    from google.cloud import bigquery

    if settings.google_application_credentials:
        credentials = service_account.Credentials.from_service_account_file(
            settings.google_application_credentials
        )
        return bigquery.Client(project=settings.google_cloud_project, credentials=credentials)
    return bigquery.Client(project=settings.google_cloud_project)


class DataAgentOption(BaseModel):
    name: str
    display_name: str


# GCP auto-provisions these into every project as demos ("Made by Google" in
# the Conversational Analytics console) — they carry this label and aren't
# anyone's actual data agent, so they're excluded from the picker.
_SAMPLE_AGENT_LABEL = "sample-agent-signature"

# The Conversational Analytics API buckets Data Agents into these locations
# — an agent created via the console can land in any one of them, and the
# API 403s if you query a non-global location through the global endpoint,
# so every location must be listed through its own regional endpoint.
DATA_AGENT_LOCATIONS = ["global", "us", "eu"]


def _data_agent_api_endpoint(location: str) -> str:
    if location == "global":
        return "geminidataanalytics.googleapis.com"
    if "-" in location:
        return f"geminidataanalytics-{location}.googleapis.com"
    return f"geminidataanalytics.{location}.rep.googleapis.com"


def _data_agent_credentials() -> service_account.Credentials | None:
    if settings.google_application_credentials:
        return service_account.Credentials.from_service_account_file(
            settings.google_application_credentials
        )
    return None


def _list_data_agents_for_location(
    location: str, credentials: service_account.Credentials | None
) -> list[DataAgentOption]:
    options: list[DataAgentOption] = []
    try:
        opts = ClientOptions(api_endpoint=_data_agent_api_endpoint(location))
        client = (
            gda.DataAgentServiceClient(credentials=credentials, client_options=opts)
            if credentials
            else gda.DataAgentServiceClient(client_options=opts)
        )
        parent = f"projects/{settings.google_cloud_project}/locations/{location}"
        for agent in client.list_data_agents(parent=parent):
            if _SAMPLE_AGENT_LABEL in agent.labels and not settings.data_agent_picker_include_samples:
                continue
            display_name = getattr(agent, "display_name", "") or agent.name.split("/")[-1]
            options.append(DataAgentOption(name=agent.name, display_name=display_name))
    except Exception as exc:
        logger.warning("Failed to list BigQuery Data Agents in location %s: %s", location, exc)
    return options


def _list_data_agents_uncached() -> list[DataAgentOption]:
    """Live call to GCP — lists every published BigQuery Data Agent that
    exists in this project across every known Data Agent location
    (excluding Google's built-in sample agents), so the Chat Assistant's
    per-question agent picker doesn't need anything hand-maintained. Never
    raises — a misconfigured/unreachable location is skipped rather than
    breaking the whole picker. Each location is its own regional API call
    (see DATA_AGENT_LOCATIONS), so they're run in parallel — sequentially
    this took several seconds, which is why the Chat Assistant's agent
    picker used to only appear well after the page had already loaded."""
    credentials = _data_agent_credentials()
    with ThreadPoolExecutor(max_workers=len(DATA_AGENT_LOCATIONS)) as pool:
        results = pool.map(
            lambda location: _list_data_agents_for_location(location, credentials),
            DATA_AGENT_LOCATIONS,
        )
        return [option for location_options in results for option in location_options]


def _list_data_agents() -> list[DataAgentOption]:
    """Cached wrapper around _list_data_agents_uncached — Data Agents are
    created/published rarely, so repeat calls within
    settings.data_agent_list_cache_ttl_seconds reuse the last result instead
    of re-hitting GCP across 3 regions."""
    global _data_agent_list_cache

    now = time.time()
    if _data_agent_list_cache and now - _data_agent_list_cache[0] < settings.data_agent_list_cache_ttl_seconds:
        return _data_agent_list_cache[1]

    options = _list_data_agents_uncached()
    _data_agent_list_cache = (now, options)
    return options


class GeminiService:
    """Answers natural-language questions against BigQuery.

    Tries a published BigQuery Data Agent (Conversational Analytics API)
    FIRST if one is configured — see _resolve_data_agent for how the active
    agent is resolved (an explicit per-call agent_name, e.g. from the Chat
    Assistant's picker, then static env vars). If no agent is configured, or
    the Agent call fails for any reason, falls back to asking Gemini to
    write SQL directly — grounded in schema
    auto-discovered from each dataset in settings.bigquery_datasets_list
    (see _build_bigquery_table_context) — then running that SQL directly
    against BigQuery with google-cloud-bigquery.

    Stateless — no conversation history is kept between calls.
    """

    def __init__(self) -> None:
        # Cached per Data Agent location — the Conversational Analytics API
        # 403s if a non-global location is queried through the global
        # endpoint, so each location needs its own client pointed at its
        # own regional endpoint (see _data_agent_api_endpoint).
        self._clients: dict[str, gda.DataChatServiceClient] = {}

    def _get_client(self, location: str) -> gda.DataChatServiceClient:
        # Built lazily so a missing/invalid credential doesn't crash app
        # startup or take down unrelated endpoints — only /api/chat fails.
        if location not in self._clients:
            try:
                credentials = _data_agent_credentials()
            except (OSError, ValueError) as exc:
                raise HTTPException(
                    status_code=502,
                    detail=f"Failed to load Gemini service-account credentials: {exc}",
                ) from exc
            opts = ClientOptions(api_endpoint=_data_agent_api_endpoint(location))
            if credentials:
                self._clients[location] = gda.DataChatServiceClient(credentials=credentials, client_options=opts)
            else:
                self._clients[location] = gda.DataChatServiceClient(client_options=opts)
        return self._clients[location]

    def _resolve_data_agent(self, agent_name: str | None) -> str | None:
        """Returns the full Data Agent resource name to use, or None if
        none is configured. `agent_name` is whatever the caller explicitly
        asked for (e.g. the Chat Assistant's per-question agent picker) and
        takes precedence; falls back to the static
        GEMINI_DATA_AGENT_ID/LOCATION env vars when not provided."""
        if agent_name:
            return agent_name

        if settings.gemini_data_agent_id and settings.gemini_data_agent_location:
            return (
                f"projects/{settings.google_cloud_project}"
                f"/locations/{settings.gemini_data_agent_location}"
                f"/dataAgents/{settings.gemini_data_agent_id}"
            )
        return None

    def _location_from_agent_name(self, agent_name: str) -> str:
        # agent_name is "projects/P/locations/L/dataAgents/A" either way
        # (constructed from env vars, or the resource name GCP itself
        # returned from list_data_agents() via the Chat Assistant's
        # per-question picker) — pull the location back out of it.
        parts = agent_name.split("/")
        return parts[3] if len(parts) >= 4 and parts[2] == "locations" else settings.gemini_chat_location

    def _build_request(self, question: str, agent_name: str) -> gda.ChatRequest:
        location = self._location_from_agent_name(agent_name)
        return gda.ChatRequest(
            parent=f"projects/{settings.google_cloud_project}/locations/{location}",
            messages=[gda.Message(user_message=gda.UserMessage(text=question))],
            data_agent_context=gda.DataAgentContext(data_agent=agent_name),
        )

    def ask(
        self, question: str, agent_name: str | None = None
    ) -> tuple[str, str | None, dict[str, Any] | None, dict[str, Any] | None]:
        """Returns (answer, sql, table, chart). Pass `agent_name` (a Data
        Agent resource name, e.g. from the Chat Assistant's per-question
        picker) to try that Data Agent first; omit it (or leave no static
        env-var agent configured either) to go straight to direct BigQuery
        SQL generation. Raises HTTPException(502) only if every available
        path fails."""
        tool_cache = get_tool_cache() if settings.chat_cache_enabled else None
        if tool_cache:
            cached = tool_cache.get_sql(question)
            if cached:
                return cached["answer"], cached["sql"], cached["table"], cached["chart"]

        agent_name = self._resolve_data_agent(agent_name)
        result = None
        if agent_name:
            try:
                result = self._ask_data_agent(question, agent_name)
            except Exception as exc:
                logger.error("Data Agent call failed, falling back to direct BigQuery: %s", exc)

        if result is None:
            try:
                result = self._query_bigquery(question)
            except Exception as exc:
                logger.error("BigQuery query failed: %s", exc)
                raise HTTPException(status_code=502, detail=f"BigQuery query failed: {exc}") from exc

        if tool_cache:
            answer, sql, table, chart = result
            tool_cache.set_sql(question, {"answer": answer, "sql": sql, "table": table, "chart": chart})
        return result

    def _ask_data_agent(
        self, question: str, agent_name: str
    ) -> tuple[str, str | None, dict[str, Any] | None, dict[str, Any] | None]:
        """Calls the published BigQuery Data Agent. Raises on any failure
        (API error, timeout, empty answer) — ask() catches this and falls
        back to direct-query generation."""
        client = self._get_client(self._location_from_agent_name(agent_name))
        request = self._build_request(question, agent_name)

        try:
            chunks = list(client.chat(request=request, timeout=settings.gemini_chat_timeout_seconds))
        except DeadlineExceeded as exc:
            logger.error("Gemini Data Analytics request timed out after %.0fs", settings.gemini_chat_timeout_seconds)
            raise HTTPException(
                status_code=504,
                detail=f"Gemini Data Analytics request timed out after {settings.gemini_chat_timeout_seconds:.0f}s",
            ) from exc
        except Exception as exc:
            logger.error("Gemini Data Analytics request failed: %s", _describe_exception(exc))
            raise HTTPException(
                status_code=502,
                detail=f"Gemini Data Analytics request failed: {_describe_exception(exc)}",
            ) from exc

        answer, sql, table, chart = _parse_chat_chunks(chunks)
        if not answer:
            raise HTTPException(status_code=502, detail="Gemini returned no final answer")

        return answer, sql, table, chart

    def _query_bigquery(
        self, question: str
    ) -> tuple[str, str | None, dict[str, Any] | None, dict[str, Any] | None]:
        """Generate SQL for `question` with Gemini, then run it on BigQuery."""
        from google.genai import types

        table_context = _build_bigquery_table_context()
        sql_prompt = (
            f"Generate a BigQuery SQL query to answer this question: {question}\n\n"
            f"Available tables:\n{table_context or '(none configured)'}\n\n"
            "Return ONLY the SQL query, no explanation. Use backticks for "
            "table/column names. Limit results to 100 rows maximum."
        )

        client = build_vertex_ai_client()
        response = client.models.generate_content(
            model=settings.gemini_chat_model,
            contents=sql_prompt,
            config=types.GenerateContentConfig(
                temperature=0.1,
                max_output_tokens=1024,
                # This model "thinks" before answering by default, and thinking
                # tokens count against max_output_tokens — for a small,
                # deterministic task like writing one SQL query, that ate the
                # whole budget and truncated the query mid-clause. Disabled
                # here since this task doesn't benefit from extended reasoning.
                thinking_config=types.ThinkingConfig(thinking_budget=0),
            ),
        )
        sql_text = (response.text or "").strip()
        sql_text = re.sub(r"^```sql\s*|^```\s*|```\s*$", "", sql_text).strip()
        if not sql_text:
            raise ValueError("Gemini did not return a SQL query")

        rows_iter = _bigquery_client().query(sql_text).result()
        columns = [field.name for field in rows_iter.schema]
        rows: list[dict[str, Any]] = []
        for row in rows_iter:
            row_dict: dict[str, Any] = {}
            for col in columns:
                val = row[col]
                row_dict[col] = val.isoformat() if hasattr(val, "isoformat") else val
            rows.append(row_dict)

        table = {"columns": columns, "rows": [[r.get(c) for c in columns] for r in rows]} if columns else None
        chart = _detect_chart_type(columns, rows)
        answer = f"Query executed against BigQuery. Found {len(rows)} result(s)."
        return answer, sql_text, table, chart
