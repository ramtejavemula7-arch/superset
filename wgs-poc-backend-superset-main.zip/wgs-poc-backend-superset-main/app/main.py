import logging
import time
from pathlib import Path

from fastapi import FastAPI, APIRouter, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import text
from sqlalchemy.exc import OperationalError
from uvicorn.middleware.proxy_headers import ProxyHeadersMiddleware

from app.api.routes import (
    auth, users, superset, roles, templates, scheduled_reports, chat, page_chat, endpoint_registrations,
)
from app.core.config import settings
from app.core.endpoints import API_PREFIX, AuthRoutes, UserRoutes, RoleRoutes
from app.core.logging_config import setup_logging
from app.core.scheduler import start_scheduler
from app.middleware.auth_middleware import AuthMiddleware
from app.services.vertex_ai_client import build_vertex_ai_client

setup_logging(debug=settings.debug)
logger = logging.getLogger(__name__)


def _migrate_superset_embeds(max_retries: int = 5, base_delay: float = 2.0) -> None:
    """Add superset_dashboard_id column if it doesn't exist yet (safe no-op
    otherwise). Retries on a transient DB connection failure at startup —
    e.g. a cold start racing the DB not being ready yet — rather than
    failing immediately on the first blip."""
    from app.core.database import engine

    for attempt in range(1, max_retries + 1):
        try:
            with engine.connect() as conn:
                try:
                    conn.execute(
                        text(
                            "ALTER TABLE superset_embeds "
                            "ADD COLUMN IF NOT EXISTS superset_dashboard_id INTEGER"
                        )
                    )
                    conn.commit()
                except Exception:
                    conn.rollback()
            return
        except OperationalError as exc:
            if attempt == max_retries:
                raise
            delay = base_delay * attempt
            logger.warning(
                "DB connection attempt %d/%d failed during startup migration, retrying in %.0fs: %s",
                attempt, max_retries, delay, exc,
            )
            time.sleep(delay)


app = FastAPI(
    title=settings.app_name,
    debug=settings.debug,
    docs_url="/docs" if settings.debug else None,
    redoc_url="/redoc" if settings.debug else None,
)

# ------------------------------------------------------------------ #
# Middleware                                                           #
# ------------------------------------------------------------------ #

app.add_middleware(AuthMiddleware)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "Accept"],
    # Without this, browsers hide Content-Disposition from JS on cross-origin
    # responses, so the FE can never read the server-provided export filename.
    expose_headers=["Content-Disposition"],
)

# Cloud Run terminates TLS at its edge and forwards to the container over
# plain HTTP, so without this the app thinks every request is http — making
# any redirect (e.g. Starlette's trailing-slash redirect) build a Location
# header as http://..., which browsers block as mixed content. Added last so
# it's the outermost middleware and corrects the scheme before anything else
# (including routing) sees the request.
app.add_middleware(ProxyHeadersMiddleware, trusted_hosts="*")

# ------------------------------------------------------------------ #
# Static files                                                        #
# ------------------------------------------------------------------ #

Path("uploads").mkdir(exist_ok=True)
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

# ------------------------------------------------------------------ #
# Global error handlers                                               #
# ------------------------------------------------------------------ #

@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    logger.exception("Unhandled error on %s %s", request.method, request.url.path)
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error"},
    )

# ------------------------------------------------------------------ #
# Routers                                                             #
# ------------------------------------------------------------------ #

app.include_router(auth.router, prefix=AuthRoutes.PREFIX, tags=["auth"])
app.include_router(users.router, prefix=UserRoutes.PREFIX, tags=["users"])
app.include_router(roles.router, prefix=RoleRoutes.PREFIX, tags=["roles"])
app.include_router(superset.router, prefix=API_PREFIX, tags=["superset"])
app.include_router(templates.router, prefix=API_PREFIX, tags=["templates"])
app.include_router(scheduled_reports.router, prefix=API_PREFIX, tags=["scheduled-reports"])
app.include_router(chat.router, prefix=API_PREFIX, tags=["chat"])
app.include_router(page_chat.router, prefix=API_PREFIX, tags=["page-chat"])
app.include_router(endpoint_registrations.router, prefix=API_PREFIX, tags=["endpoint-registrations"])

@app.on_event("startup")
def on_startup():
    # Neither of these is critical-path for serving requests — a DB outage
    # at boot shouldn't take down the whole app. Log and continue; requests
    # that actually need the DB will fail on their own with a clear error.
    try:
        _migrate_superset_embeds()
    except Exception:
        logger.exception("Startup migration failed after retries — continuing without it")

    try:
        start_scheduler()
    except Exception:
        logger.exception("Scheduler failed to start — continuing without it")

    try:
        # Building the Vertex AI client involves a credential exchange that
        # costs a few seconds — do it once at boot so the first user chat
        # message isn't the one paying for it.
        warm_client = build_vertex_ai_client()
        chat.service._client = warm_client
        page_chat.service._client = warm_client
    except Exception:
        logger.exception("Vertex AI client warm-up failed — continuing without it")


# ------------------------------------------------------------------ #
# Health check                                                        #
# ------------------------------------------------------------------ #

@app.get("/health", tags=["health"])
def health_check():
    return {"status": "ok", "app": settings.app_name}


@app.get("/")
def root():
    return {"message": f"Welcome to {settings.app_name} API"}
